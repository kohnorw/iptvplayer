# 📺 IPTV Player — Lightweight Docker Browser App

A zero-transcoding, browser-based IPTV player with Xtream Codes support.
Streams are **proxied** through the container — no GPU, no FFmpeg, no system load.

## Features
- Xtream Codes login (host, username, password)
- Live TV — browse by category, instant channel switching
- EPG / TV Guide — programme info strip + full guide view
- Favourites — saved persistently in Docker volume
- Search — filter channels or guide in real time
- Settings — change credentials and stream format, saved between sessions
- HLS + TS support — uses HLS.js for M3U8; native for TS
- Lightweight — 128 MB RAM cap, 0.5 CPU, zero transcoding

## Quick Start

### Docker Compose (recommended)
```bash
docker compose up -d
```
Then open http://localhost:8080

### Docker run
```bash
docker build -t iptv-player .
docker run -d -p 8080:8080 -v iptv-data:/app/data --name iptv-player --memory 128m iptv-player
```

### Node.js (no Docker)
```bash
npm install && npm start
```

## Setup
1. Open http://localhost:8080
2. Enter Xtream Codes credentials (server URL, username, password)
3. Click Connect — settings are saved automatically

## Data Persistence
Saved in Docker volume at /app/data:
- settings.json — server credentials
- favourites.json — favourite channels

## Stream Formats
- TS (default) — most servers, lower latency
- HLS (m3u8) — better browser compatibility

Change in Settings → Player → Stream format

## Security
Intended for personal/home LAN use. For public exposure add nginx + htpasswd.
