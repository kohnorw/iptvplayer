"use strict";
const express = require("express");
const http    = require("http");
const https   = require("https");
const path    = require("path");
const fs      = require("fs");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
// UPSTREAM overrides the host for all backend calls (use local IP to bypass allowlist)
const UPSTREAM = (process.env.UPSTREAM_HOST || "").replace(/\/+$/, "");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
const FAV_DIR = path.join(DATA_DIR, "favourites");
if (!fs.existsSync(FAV_DIR)) fs.mkdirSync(FAV_DIR, { recursive: true });

app.use(express.json({ limit: "50mb" }));
app.use(express.static(path.join(__dirname, "../static")));

// ── Helpers ───────────────────────────────────────────────────────
function xcFetch(url, timeout = 25000) {
  return new Promise((resolve, reject) => {
    let parsed;
    try { parsed = new URL(url); } catch(e) { return reject(e); }
    const lib  = parsed.protocol === "https:" ? https : http;
    const opts = {
      hostname: parsed.hostname,
      port:     parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path:     parsed.pathname + parsed.search,
      method:   "GET",
      headers:  { "User-Agent": "Mozilla/5.0" },
    };
    const req = lib.request(opts, res => {
      const chunks = [];
      res.on("data", c => chunks.push(c));
      res.on("end", () => {
        const body = Buffer.concat(chunks).toString();
        try { resolve(JSON.parse(body)); }
        catch(_) { reject(new Error(`Non-JSON (HTTP ${res.statusCode}): ${body.slice(0,120)}`)); }
      });
    });
    req.on("error", reject);
    req.setTimeout(timeout, () => { req.destroy(); reject(new Error("Request timed out")); });
    req.end();
  });
}

function apiHost(host) {
  // Always use UPSTREAM if set (internal IP bypasses allowlist)
  if (UPSTREAM) return UPSTREAM;
  return host;
}

function xcUrl(host, username, password, action, extra = {}) {
  const base = apiHost(host);
  const u = new URL(`${base}/player_api.php`);
  u.searchParams.set("username", username);
  u.searchParams.set("password", password);
  if (action) u.searchParams.set("action", action);
  for (const [k, v] of Object.entries(extra)) u.searchParams.set(k, String(v));
  return u.toString();
}

async function discoverHost(input, username, password) {
  const bare = input.replace(/^https?:\/\//i, "").replace(/\/+$/, "").trim();
  // If UPSTREAM set, just verify creds against it
  if (UPSTREAM) {
    const url = `${UPSTREAM}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`;
    const data = await xcFetch(url, 10000);
    if (data.user_info && data.user_info.auth == 1) return { host: input, user_info: data.user_info };
    throw new Error("Invalid credentials");
  }
  // Otherwise try candidates
  const seen = new Set();
  const candidates = [
    `http://${bare}`, `https://${bare}`,
    `http://${bare}:3000`, `http://${bare}:8080`, `http://${bare}:80`,
  ].filter(c => { if(seen.has(c)) return false; seen.add(c); return true; });

  for (const host of candidates) {
    try {
      const data = await xcFetch(`${host}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`, 8000);
      if (data.user_info && data.user_info.auth == 1) {
        const si = data.server_info;
        let canonical = host;
        if (si && si.url) {
          const proto = si.server_protocol || "http";
          const port  = proto === "https" ? si.https_port : si.port;
          canonical = (port && port !== "80" && port !== "443") ? `${proto}://${si.url}:${port}` : `${proto}://${si.url}`;
        }
        return { host: canonical, user_info: data.user_info };
      }
    } catch(_) {}
  }
  throw new Error("Could not connect. Check your server address and credentials.");
}

// ── Favourites — keyed by username, no passwords stored ──────────
function favFile(username) { return path.join(FAV_DIR, `${username.replace(/[^a-z0-9]/gi,"_")}.json`); }
function loadFavs(username) { try { return JSON.parse(fs.readFileSync(favFile(username))); } catch(_){ return []; } }
function saveFavs(username, data) { fs.writeFileSync(favFile(username), JSON.stringify(data)); }

// ── Login — validates creds, returns session token (host encoded) ─
// No passwords stored server-side. Each request carries creds.
app.post("/api/login", async (req, res) => {
  const { host, username, password } = req.body || {};
  if (!host || !username || !password)
    return res.status(400).json({ error: "host, username, password required" });
  try {
    const { host: canonical, user_info } = await discoverHost(host, username, password);
    res.json({ ok: true, host: canonical, user_info });
  } catch(e) {
    res.status(401).json({ error: e.message });
  }
});

// ── All subsequent requests carry creds in headers ────────────────
function getCreds(req) {
  const host     = req.headers["x-xc-host"]     || "";
  const username = req.headers["x-xc-username"] || "";
  const password = req.headers["x-xc-password"] || "";
  if (!host || !username || !password) return null;
  return { host, username, password };
}

// ── SSE: load channels with progress ─────────────────────────────
app.get("/api/load-channels", async (req, res) => {
  const host     = req.query.host;
  const username = req.query.username;
  const password = req.query.password;
  if (!host || !username || !password)
    return res.status(400).json({ error: "Missing credentials" });

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  const send = (type, data) => res.write(`data: ${JSON.stringify({type,...data})}\n\n`);

  try {
    send("progress", { msg: "Fetching categories…", pct: 10 });
    const categories = await xcFetch(xcUrl(host, username, password, "get_live_categories"));

    send("progress", { msg: `Got ${categories.length} categories. Fetching channels…`, pct: 30 });
    const channels = await xcFetch(xcUrl(host, username, password, "get_live_streams"));

    send("progress", { msg: `Loaded ${channels.length} channels!`, pct: 95 });
    send("done", { categories, channels });
  } catch(e) {
    send("error", { msg: e.message });
  }
  res.end();
});

// ── Favourites API ────────────────────────────────────────────────
app.get("/api/favourites", (req, res) => {
  const creds = getCreds(req);
  if (!creds) return res.json([]);
  res.json(loadFavs(creds.username));
});

app.post("/api/favourites", (req, res) => {
  const creds = getCreds(req);
  if (!creds) return res.status(401).json({ error: "No credentials" });
  saveFavs(creds.username, req.body);
  res.json({ ok: true });
});

// ── EPG ───────────────────────────────────────────────────────────
app.get("/api/epg/:id", async (req, res) => {
  const creds = getCreds(req);
  if (!creds) return res.json({ epg_listings: [] });
  try {
    const data = await xcFetch(xcUrl(creds.host, creds.username, creds.password, "get_short_epg", { stream_id: req.params.id, limit: 6 }));
    res.json(data);
  } catch(_) { res.json({ epg_listings: [] }); }
});

// ── Stream proxy ──────────────────────────────────────────────────
app.get("/proxy/stream/:type/:streamId", (req, res) => {
  const host     = req.query.host;
  const username = req.query.username;
  const password = req.query.password;
  const ext      = req.query.ext || "m3u8";
  if (!host || !username || !password) return res.status(401).send("Missing credentials");

  const { type, streamId } = req.params;
  const base = apiHost(host);
  const streamUrl = `${base}/${type}/${username}/${password}/${streamId}.${ext}`;
  pipeStream(streamUrl, req, res);
});

function pipeStream(targetUrl, req, res) {
  let parsed;
  try { parsed = new URL(targetUrl); } catch(_) { return res.status(400).send("Bad URL"); }
  const lib  = parsed.protocol === "https:" ? https : http;
  const opts = {
    hostname: parsed.hostname,
    port:     parsed.port || (parsed.protocol === "https:" ? 443 : 80),
    path:     parsed.pathname + parsed.search,
    method:   "GET",
    headers:  { "User-Agent": "Mozilla/5.0", Range: req.headers.range || "" },
  };
  const up = lib.request(opts, uRes => {
    const hdrs = { "Access-Control-Allow-Origin": "*" };
    ["content-type","content-length","content-range","accept-ranges","cache-control"]
      .forEach(h => { if (uRes.headers[h]) hdrs[h] = uRes.headers[h]; });
    res.writeHead(uRes.statusCode, hdrs);
    uRes.pipe(res, { end: true });
  });
  up.on("error", err => { if (!res.headersSent) res.status(502).send(err.message); });
  req.on("close", () => up.destroy());
  up.end();
}

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../static/index.html")));
app.listen(PORT, () => console.log(`IPTV Player on :${PORT}  upstream=${UPSTREAM||"auto"}`));
