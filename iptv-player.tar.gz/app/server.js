"use strict";

const express  = require("express");
const http     = require("http");
const https    = require("https");
const path     = require("path");
const fs       = require("fs");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
const UPSTREAM = (process.env.UPSTREAM_HOST || "").replace(/\/+$/, "");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const SETTINGS_FILE   = path.join(DATA_DIR, "settings.json");
const FAVOURITES_FILE = path.join(DATA_DIR, "favourites.json");
const CACHE_FILE      = path.join(DATA_DIR, "cache.json");

app.use(express.json({ limit: "50mb" }));
app.use(express.static(path.join(__dirname, "../static")));

function load(f)    { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch(_){ return null; } }
function save(f, d) { fs.writeFileSync(f, JSON.stringify(d)); }
function getSettings() { return load(SETTINGS_FILE) || {}; }

async function xcFetch(url, timeout = 20000) {
  return new Promise((resolve, reject) => {
    let parsed;
    try { parsed = new URL(url); } catch(e) { return reject(e); }
    const lib  = parsed.protocol === "https:" ? https : http;
    const opts = {
      hostname: parsed.hostname,
      port:     parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path:     parsed.pathname + parsed.search,
      method:   "GET",
      headers:  { "User-Agent": "Mozilla/5.0" },
    };
    const req = lib.request(opts, res => {
      let body = "";
      res.on("data", c => body += c);
      res.on("end", () => {
        try { resolve(JSON.parse(body)); }
        catch(_) { reject(new Error(`Non-JSON (HTTP ${res.statusCode}): ${body.slice(0,100)}`)); }
      });
    });
    req.on("error", err => reject(err));
    req.setTimeout(timeout, () => { req.destroy(); reject(new Error("Timed out")); });
    req.end();
  });
}

function xcUrl(s, action, extra = {}) {
  const host = UPSTREAM || s.host;
  const u = new URL(`${host}/player_api.php`);
  u.searchParams.set("username", s.username);
  u.searchParams.set("password", s.password);
  if (action) u.searchParams.set("action", action);
  for (const [k, v] of Object.entries(extra)) u.searchParams.set(k, v);
  return u.toString();
}

async function discoverHost(input, username, password) {
  const bare = input.replace(/^https?:\/\//i, "").replace(/\/+$/, "");
  const seen = new Set();
  const candidates = [`http://${bare}`, `https://${bare}`, `http://${bare}:3000`, `http://${bare}:8080`]
    .filter(c => { if (seen.has(c)) return false; seen.add(c); return true; });

  for (const host of candidates) {
    try {
      const url = `${host}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`;
      const data = await xcFetch(url, 8000);
      if (data.user_info && data.user_info.auth == 1) {
        const si = data.server_info;
        if (si && si.url) {
          const proto = si.server_protocol || "http";
          const port  = proto === "https" ? si.https_port : si.port;
          const canonical = (port && port !== "80" && port !== "443")
            ? `${proto}://${si.url}:${port}`
            : `${proto}://${si.url}`;
          return { host: canonical, user_info: data.user_info };
        }
        return { host, user_info: data.user_info };
      }
    } catch(_) {}
  }
  throw new Error("Could not connect. Check your server address and credentials.");
}

// ── SSE progress endpoint for channel loading ─────────────────────
app.get("/api/load-channels", async (req, res) => {
  const s = getSettings();
  if (!s.host) return res.status(401).json({ error: "Not configured" });

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  function send(type, data) {
    res.write(`data: ${JSON.stringify({ type, ...data })}\n\n`);
  }

  try {
    send("progress", { msg: "Fetching categories…", pct: 5 });
    const categories = await xcFetch(xcUrl(s, "get_live_categories"));

    send("progress", { msg: `Found ${categories.length} categories. Fetching channels…`, pct: 20 });
    const channels = await xcFetch(xcUrl(s, "get_live_streams"));

    send("progress", { msg: `Got ${channels.length} channels. Fetching EPG…`, pct: 60 });

    // Save to cache
    const cache = { categories, channels, ts: Date.now() };
    save(CACHE_FILE, cache);

    send("progress", { msg: "Building channel list…", pct: 90 });
    send("done", { categories, channels });

  } catch(e) {
    send("error", { msg: e.message });
  }

  res.end();
});

// ── Cached data endpoint ──────────────────────────────────────────
app.get("/api/cache", (req, res) => {
  const cache = load(CACHE_FILE);
  if (!cache) return res.status(404).json({ error: "No cache" });
  res.json(cache);
});

// ── Settings / Login ──────────────────────────────────────────────
app.get("/api/settings", (req, res) => res.json(getSettings()));

app.post("/api/login", async (req, res) => {
  const { host, username, password } = req.body || {};
  if (!host || !username || !password)
    return res.status(400).json({ error: "host, username, password required" });
  try {
    const { host: canonical, user_info } = await discoverHost(host, username, password);
    save(SETTINGS_FILE, { host: canonical, username: username.trim(), password: password.trim() });
    res.json({ ok: true, host: canonical, user_info });
  } catch(e) {
    res.status(401).json({ error: e.message });
  }
});

app.post("/api/settings", (req, res) => {
  let { host, username, password } = req.body || {};
  if (!host || !username || !password)
    return res.status(400).json({ error: "required" });
  save(SETTINGS_FILE, { host: host.trim().replace(/\/+$/,""), username: username.trim(), password: password.trim() });
  res.json({ ok: true });
});

// ── Favourites ────────────────────────────────────────────────────
app.get("/api/favourites",  (req, res) => res.json(load(FAVOURITES_FILE) || []));
app.post("/api/favourites", (req, res) => { save(FAVOURITES_FILE, req.body); res.json({ ok: true }); });

// ── Auth test ─────────────────────────────────────────────────────
app.get("/api/test", async (req, res) => {
  const s = getSettings();
  if (!s.host) return res.status(401).json({ error: "Not configured" });
  try {
    const d = await xcFetch(xcUrl(s, null));
    if (d.user_info) {
      res.json({ ok:true, status:d.user_info.status, expiry:d.user_info.exp_date,
        connections:`${d.user_info.active_cons}/${d.user_info.max_connections}` });
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  } catch(e) { res.status(502).json({ error: e.message }); }
});

// ── XC API proxy ──────────────────────────────────────────────────
const ALLOWED = new Set([
  "get_live_categories","get_live_streams","get_vod_categories",
  "get_vod_streams","get_series_categories","get_series","get_short_epg","get_epg",
]);

app.get("/api/xtream/:action", async (req, res) => {
  const s = getSettings();
  if (!s.host) return res.status(401).json({ error: "Not configured" });
  const { action } = req.params;
  if (!ALLOWED.has(action)) return res.status(403).json({ error: "Not allowed" });
  const extra = {};
  for (const [k, v] of Object.entries(req.query)) if (k !== "_") extra[k] = v;
  try { res.json(await xcFetch(xcUrl(s, action, extra))); }
  catch(e) { res.status(502).json({ error: e.message }); }
});

// ── EPG ───────────────────────────────────────────────────────────
app.get("/api/epg/:id", async (req, res) => {
  const s = getSettings();
  if (!s.host) return res.status(401).json({ error: "Not configured" });
  try { res.json(await xcFetch(xcUrl(s, "get_short_epg", { stream_id: req.params.id, limit: 6 }))); }
  catch(_) { res.json({ epg_listings: [] }); }
});

// ── Stream proxy ──────────────────────────────────────────────────
app.get("/proxy/stream/:type/:id", (req, res) => {
  const s = getSettings();
  if (!s.host) return res.status(401).send("Not configured");
  const { type, id } = req.params;
  const dot = id.lastIndexOf(".");
  const streamId = dot > 0 ? id.slice(0, dot) : id;
  const ext      = dot > 0 ? id.slice(dot + 1) : "ts";
  pipeStream(`${UPSTREAM || s.host}/${type}/${s.username}/${s.password}/${streamId}.${ext}`, req, res);
});

function pipeStream(targetUrl, req, res) {
  let parsed;
  try { parsed = new URL(targetUrl); } catch(_) { return res.status(400).send("Bad URL"); }
  const lib  = parsed.protocol === "https:" ? https : http;
  const opts = {
    hostname: parsed.hostname,
    port:     parsed.port || (parsed.protocol === "https:" ? 443 : 80),
    path:     parsed.pathname + parsed.search,
    method:   "GET",
    headers:  { "User-Agent": "Mozilla/5.0", Range: req.headers.range || "" },
  };
  const up = lib.request(opts, uRes => {
    const hdrs = { "Access-Control-Allow-Origin": "*" };
    ["content-type","content-length","content-range","accept-ranges","cache-control"]
      .forEach(h => { if (uRes.headers[h]) hdrs[h] = uRes.headers[h]; });
    res.writeHead(uRes.statusCode, hdrs);
    uRes.pipe(res, { end: true });
  });
  up.on("error", err => { if (!res.headersSent) res.status(502).send(err.message); });
  req.on("close", () => up.destroy());
  up.end();
}

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../static/index.html")));
app.listen(PORT, () => console.log(`IPTV Player on :${PORT}`));
