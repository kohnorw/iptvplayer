// build: CLEAN_REWRITE
"use strict";

const express              = require("express");
const path                 = require("path");
const fs                   = require("fs");
const http                 = require("http");
const https                = require("https");
const { spawn, spawnSync } = require("child_process");
const os                   = require("os");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
const XC_HOST  = (process.env.XC_HOST || "http://192.168.1.124:3000").replace(/\/+$/, "");
const HLS_DIR  = path.join(os.tmpdir(), "iptv-hls");

[DATA_DIR, HLS_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });
app.use(express.json({ limit: "10mb" }));

// ── Config ────────────────────────────────────────────────────────
const UA_MAP = {
  chrome:   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
  vlc:      "VLC/3.0.20 LibVLC/3.0.20",
  tivimate: "TiviMate/4.7.0",
};

let CFG = {
  ua: UA_MAP.chrome,
  // Server HLS
  segSecs: 2, prebuf: 2, window: 60, idle: 20000,
  stallRestart: 10000, maxRestarts: 5,
  // Browser buffer
  hlsBuf: 30, backBuf: 0, liveSync: 6, stallDelay: 8, snapLive: true,
  // Safari
  safariTranscode: true, safariProfile: "baseline", safariPreset: "ultrafast", safariVbr: 0,
  // Audio
  forceAac: false, audioBr: 192, audioSr: 48000, audioPrebuf: 4, aresample: true,
  // FFmpeg input
  ffmpegInput: [], probeSize: 1000000, analyzeDur: 1500000, threadQueue: 8192,
  // FFmpeg output
  ffmpegExtra: [], discardCorrupt: true, genpts: true, ignoreErr: false, noBuffer: false,
  // Reconnect
  reconnect: true, reconnectNet: true, reconnectDelay: 5, rwTimeout: 15000000,
};

// ── Helpers ───────────────────────────────────────────────────────
const userFile = (u, t) => path.join(DATA_DIR, `${t}_${u.replace(/[^a-zA-Z0-9_\-\.]/g,"_")}.json`);
const readUser = (u, t, def) => { try { return JSON.parse(fs.readFileSync(userFile(u,t),"utf8")); } catch(_) { return def; } };
const writeUser = (u, t, d) => fs.writeFileSync(userFile(u,t), JSON.stringify(d));

async function xcFetch(url, ms=15000) {
  return new Promise((resolve, reject) => {
    const p = new URL(url);
    const lib = p.protocol === "https:" ? https : http;
    const req = lib.request({
      hostname: p.hostname, port: p.port || (p.protocol === "https:" ? 443 : 80),
      path: p.pathname + p.search, method: "GET", headers: { "User-Agent": "Mozilla/5.0" },
    }, res => {
      let body = "";
      res.on("data", c => body += c);
      res.on("end", () => { try { resolve(JSON.parse(body)); } catch(_) { reject(new Error(`Non-JSON ${res.statusCode}`)); } });
    });
    req.on("error", reject);
    req.setTimeout(ms, () => { req.destroy(); reject(new Error("Timeout")); });
    req.end();
  });
}

function xcUrl(u, p, action, extra={}) {
  const url = new URL(`${XC_HOST}/player_api.php`);
  url.searchParams.set("username", u); url.searchParams.set("password", p);
  if (action) url.searchParams.set("action", action);
  for (const [k,v] of Object.entries(extra)) url.searchParams.set(k, v);
  return url.toString();
}

function buildFflags() {
  const f = [];
  if (CFG.genpts)        f.push("genpts");
  if (CFG.discardCorrupt)f.push("discardcorrupt");
  if (CFG.noBuffer)      f.push("nobuffer");
  return f.length ? "+" + f.join("+") : "+genpts";
}

function buildInputArgs() {
  const a = [];
  if (CFG.reconnect)    { a.push("-reconnect","1","-reconnect_streamed","1","-reconnect_delay_max",String(CFG.reconnectDelay)); }
  if (CFG.reconnectNet) { a.push("-reconnect_on_network_error","1"); }
  if (CFG.rwTimeout>0)  { a.push("-rw_timeout",String(CFG.rwTimeout)); }
  if (CFG.ignoreErr)    { a.push("-err_detect","ignore_err"); }
  a.push("-probesize",String(CFG.probeSize),"-analyzeduration",String(CFG.analyzeDur),"-thread_queue_size",String(CFG.threadQueue));
  return a;
}

function buildHlsArgs(dir, m3u8, startNum) {
  return [
    "-f","hls",
    "-hls_time",String(CFG.segSecs),
    "-hls_list_size",String(CFG.window),
    "-hls_flags","delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_segment_type","mpegts",
    "-hls_segment_filename",path.join(dir,"seg%06d.ts"),
    "-start_number",String(startNum||0),
    m3u8,
  ];
}

// ── Custom command ────────────────────────────────────────────────
const DEFAULT_CMD = path.join(__dirname, "ffmpeg-default.txt");
const CUSTOM_CMD  = path.join(DATA_DIR,  "ffmpeg-custom.txt");
let CFG_CUSTOM_CMD = null;

function readCustomCmd() {
  try { return fs.readFileSync(CUSTOM_CMD, "utf8"); } catch(_) {}
  try { return fs.readFileSync(DEFAULT_CMD, "utf8"); } catch(_) { return ""; }
}

function parseCustomCmd(template, vars) {
  let cmd = template.replace(/\{(\w+)\}/g, (_, k) => vars[k] !== undefined ? vars[k] : "{"+k+"}");
  cmd = cmd.replace(/^\s*ffmpeg\s*/,"");
  const lines = cmd.split("\n");
  const joined = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.trimEnd().endsWith("\\")) joined.push(line.trimEnd().slice(0,-1)+" ");
    else joined.push(line+" ");
  }
  cmd = joined.join("").trim();
  const args = [];
  let pos = 0;
  while (pos < cmd.length) {
    while (pos < cmd.length && cmd[pos] === " ") pos++;
    if (pos >= cmd.length) break;
    if (cmd[pos] === "#") break;
    if (cmd[pos] === '"') {
      const end = cmd.indexOf('"', pos+1);
      args.push(cmd.slice(pos+1, end === -1 ? cmd.length : end));
      pos = (end === -1 ? cmd.length : end) + 1;
    } else {
      const end = cmd.indexOf(" ", pos);
      args.push(cmd.slice(pos, end === -1 ? cmd.length : end));
      pos = end === -1 ? cmd.length : end;
    }
  }
  return args.filter(a => a.length > 0);
}

// ── FFmpeg spawn ──────────────────────────────────────────────────
function spawnFfmpeg(streamUrl, audioOnly, safari, dir, m3u8, startNum) {
  startNum = startNum || 0;

  // Custom command
  if (CFG_CUSTOM_CMD) {
    const vars = {
      STREAM_URL: streamUrl, ua: CFG.ua,
      audioBr: CFG.audioBr+"k", audioSr: String(CFG.audioSr),
      safariProfile: CFG.safariProfile, safariPreset: CFG.safariPreset,
      segSecs: String(CFG.segSecs), window: String(CFG.window),
    };
    let args = parseCustomCmd(CFG_CUSTOM_CMD, vars).map(a => {
      if (a === "./seg%06d.ts" || a.endsWith("/seg%06d.ts")) return path.join(dir,"seg%06d.ts");
      if (a === "./index.m3u8" || a === "index.m3u8") return m3u8;
      if (a === "<STREAM_URL>") return streamUrl;
      return a;
    });
    if (!args.includes("-start_number") && startNum) {
      const i = args.lastIndexOf(m3u8);
      if (i > -1) args.splice(i, 0, "-start_number", String(startNum));
    }
    const si = args.indexOf("-hls_segment_filename");
    if (si > -1 && args[si+1] && !path.isAbsolute(args[si+1])) args[si+1] = path.join(dir,"seg%06d.ts");
    console.log("[ff custom]", args.slice(0,5).join(" ")+"…");
    return spawn("ffmpeg", args);
  }

  // Safari transcode
  if (safari && CFG.safariTranscode) {
    const vbr = CFG.safariVbr > 0 ? ["-b:v", CFG.safariVbr+"k"] : [];
    return spawn("ffmpeg", [
      "-loglevel","error",
      ...buildInputArgs(),
      "-user_agent",CFG.ua,
      "-i",streamUrl,
      "-map","0:v?","-map","0:a?",
      "-c:v","libx264","-profile:v",CFG.safariProfile,
      "-level",CFG.safariProfile==="baseline"?"3.1":"4.0",
      "-preset",CFG.safariPreset,"-tune","zerolatency",...vbr,
      "-c:a","aac","-b:a",CFG.audioBr+"k","-ar",String(CFG.audioSr),"-ac","2",
      "-fflags",buildFflags(),...CFG.ffmpegExtra,
      ...buildHlsArgs(dir,m3u8,startNum),
    ]);
  }

  // Standard: copy video, transcode audio
  const audioFilter = CFG.aresample ? ["-af","aresample=async=1:first_pts=0"] : [];
  return spawn("ffmpeg", [
    "-loglevel","error",
    ...buildInputArgs(),
    "-user_agent",CFG.ua,
    "-i",streamUrl,
    "-map","0:v?","-map","0:a?",
    "-c:v","copy",
    "-c:a","aac","-b:a",CFG.audioBr+"k","-ar",String(CFG.audioSr),"-ac","2",
    ...audioFilter,
    "-fflags",buildFflags(),...CFG.ffmpegExtra,
    ...buildHlsArgs(dir,m3u8,startNum),
  ]);
}

// ── Sessions ──────────────────────────────────────────────────────
const sessions = new Map();

const segCount = dir => { try { return fs.readdirSync(dir).filter(f=>f.endsWith(".ts")).length; } catch(_) { return 0; } };

function killSession(sid) {
  const s = sessions.get(sid); if (!s) return;
  s.dead = true;
  clearTimeout(s.idleTimer); clearInterval(s.watchdog);
  try { s.ff.kill("SIGKILL"); } catch(_) {}
  try {
    if (fs.existsSync(s.dir)) {
      fs.readdirSync(s.dir).forEach(f => { try { fs.unlinkSync(path.join(s.dir,f)); } catch(_) {} });
      fs.rmdirSync(s.dir);
    }
  } catch(_) {}
  sessions.delete(sid);
}

function resetIdle(sid) {
  const s = sessions.get(sid); if (!s) return;
  clearTimeout(s.idleTimer);
  s.idleTimer = setTimeout(() => killSession(sid), CFG.idle);
}

// ── Routes ────────────────────────────────────────────────────────
app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "username and password required" });
  try {
    const d = await xcFetch(xcUrl(username, password, null));
    if (d.user_info && d.user_info.auth == 1) {
      res.json({ ok:true, status:d.user_info.status, expiry:d.user_info.exp_date,
        connections:`${d.user_info.active_cons}/${d.user_info.max_connections}` });
    } else { res.status(401).json({ error: "Invalid username or password" }); }
  } catch(e) { res.status(502).json({ error: "Cannot reach server: "+e.message }); }
});

const ALLOWED = new Set(["get_live_categories","get_live_streams","get_vod_categories","get_vod_streams","get_short_epg","get_epg"]);
app.get("/api/xc/:action", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  const { action } = req.params;
  if (!ALLOWED.has(action)) return res.status(403).json({ error: "Not allowed" });
  const extra = {};
  for (const [k,v] of Object.entries(req.query)) if (k !== "username" && k !== "password") extra[k] = v;
  try { res.json(await xcFetch(xcUrl(username, password, action, extra))); }
  catch(e) { res.status(502).json({ error: e.message }); }
});

app.get("/api/epg/:id", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  try { res.json(await xcFetch(xcUrl(username, password, "get_short_epg", { stream_id:req.params.id, limit:8 }))); }
  catch(_) { res.json({ epg_listings: [] }); }
});

app.get("/api/favs/:u",  (req,res) => res.json(readUser(req.params.u.trim(),"favs",[])));
app.post("/api/favs/:u", (req,res) => { writeUser(req.params.u.trim(),"favs",Array.isArray(req.body)?req.body:[]); res.json({ok:true}); });
app.get("/api/prefs/:u",  (req,res) => res.json(readUser(req.params.u.trim(),"prefs",{timezone:"America/Toronto"})));
app.post("/api/prefs/:u", (req,res) => { writeUser(req.params.u.trim(),"prefs",req.body||{}); res.json({ok:true}); });

app.post("/api/settings", (req, res) => {
  const s = req.body || {};
  const pl   = v => typeof v==="string"&&v.trim() ? v.trim().split(/\s+/).filter(Boolean) : [];
  const bool = (v,def) => v===undefined ? def : (v!==false&&v!=="false"&&v!=="0");
  const int  = (v,def,min=0) => Math.max(min, parseInt(v)||def);
  CFG.ua             = UA_MAP[s.ua] || UA_MAP.chrome;
  CFG.segSecs        = int(s.segSecs,2,1);
  CFG.prebuf         = int(s.prebuf,2,1);
  CFG.window         = int(s.window,60,5);
  CFG.idle           = int(s.idle,20,5)*1000;
  CFG.stallRestart   = int(s.stallRestart,10,2)*1000;
  CFG.maxRestarts    = int(s.maxRestarts,5,0);
  CFG.hlsBuf         = int(s.hlsBuf,30,5);
  CFG.backBuf        = int(s.backBuf,0,0);
  CFG.liveSync       = int(s.liveSync,6,1);
  CFG.stallDelay     = int(s.stallDelay,8,1);
  CFG.snapLive       = bool(s.snapLive,true);
  CFG.safariTranscode= bool(s.safariTranscode,true);
  CFG.safariProfile  = ["baseline","main","high"].includes(s.safariProfile)?s.safariProfile:"baseline";
  CFG.safariPreset   = ["ultrafast","superfast","veryfast","faster"].includes(s.safariPreset)?s.safariPreset:"ultrafast";
  CFG.safariVbr      = int(s.safariVbr,0,0);
  CFG.forceAac       = bool(s.forceAac,false);
  CFG.audioBr        = int(s.audioBr,192,64);
  CFG.audioSr        = s.audioSr==="44100"?44100:48000;
  CFG.audioPrebuf    = int(s.audioPrebuf,4,1);
  CFG.aresample      = bool(s.aresample,true);
  CFG.ffmpegInput    = pl(s.ffmpegInput);
  CFG.probeSize      = int(s.probeSize,1000000,50000);
  CFG.analyzeDur     = int(s.analyzeDur,1500000,100000);
  CFG.threadQueue    = int(s.threadQueue,8192,512);
  CFG.ffmpegExtra    = pl(s.ffmpegExtra);
  CFG.discardCorrupt = bool(s.discardCorrupt,true);
  CFG.genpts         = bool(s.genpts,true);
  CFG.ignoreErr      = bool(s.ignoreErr,false);
  CFG.noBuffer       = bool(s.noBuffer,false);
  CFG.reconnect      = bool(s.reconnect,true);
  CFG.reconnectNet   = bool(s.reconnectNet,true);
  CFG.reconnectDelay = int(s.reconnectDelay,5,1);
  CFG.rwTimeout      = int(s.rwTimeout,15000000,1000000);
  console.log("[settings]", JSON.stringify(CFG));
  res.json({ ok:true, cfg:CFG });
});

app.get("/api/ffcmd", (req, res) => {
  const cmd = ["ffmpeg","-loglevel","error","-user_agent",CFG.ua,"-i","<stream_url>",
    "-c:v","copy","-c:a","aac","-b:a",CFG.audioBr+"k","-ar",String(CFG.audioSr),"-ac","2",
    "-fflags",buildFflags(),"-f","hls","-hls_time",String(CFG.segSecs),"-hls_list_size",String(CFG.window),
    "-hls_flags","delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_segment_type","mpegts","-hls_segment_filename","<dir>/seg%06d.ts","<dir>/index.m3u8"];
  res.json({ cmd, cmdStr: cmd.join(" ") });
});

app.get("/api/ffcmd/custom", (req,res) => {
  const current = readCustomCmd(), isCustom = !!CFG_CUSTOM_CMD;
  try { res.json({ current, default: fs.readFileSync(DEFAULT_CMD,"utf8"), isCustom }); }
  catch(_) { res.json({ current, default: current, isCustom }); }
});
app.post("/api/ffcmd/custom", (req,res) => {
  const { cmd, enabled } = req.body || {};
  if (typeof cmd === "string") { fs.writeFileSync(CUSTOM_CMD, cmd); CFG_CUSTOM_CMD = enabled!==false ? cmd : null; }
  else { CFG_CUSTOM_CMD = enabled!==false ? readCustomCmd() : null; }
  res.json({ ok:true, enabled: !!CFG_CUSTOM_CMD });
});
app.post("/api/ffcmd/reset", (req,res) => {
  try { fs.unlinkSync(CUSTOM_CMD); } catch(_) {}
  CFG_CUSTOM_CMD = null;
  res.json({ ok:true, default: fs.existsSync(DEFAULT_CMD) ? fs.readFileSync(DEFAULT_CMD,"utf8") : "" });
});

// ── Stream start ──────────────────────────────────────────────────
app.post("/api/stream/start", (req, res) => {
  const { username, password, streamId, sessionId: oldSid, safari } = req.body || {};
  if (!username || !password || !streamId) return res.status(400).json({ error: "Missing params" });

  if (oldSid) killSession(oldSid);

  const sid  = Date.now().toString(36) + Math.random().toString(36).slice(2);
  const dir  = path.join(HLS_DIR, sid);
  const m3u8 = path.join(dir, "index.m3u8");
  fs.mkdirSync(dir, { recursive: true });

  const tsUrl   = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.ts`;
  const m3uUrl  = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.m3u8`;

  // Quick probe to detect audio-only
  let audioOnly = false;
  try {
    const r = spawnSync("ffprobe", [
      "-v","quiet","-user_agent","Mozilla/5.0",
      "-show_entries","stream=codec_type",
      "-of","csv=p=0", tsUrl,
    ], { timeout: 5000, encoding: "utf8" });
    const out = (r.stdout||"").toLowerCase();
    const hasVideo = out.includes("video");
    const hasAudio = out.includes("audio");
    audioOnly = hasAudio && !hasVideo;
    console.log(`[stream] ${sid.slice(0,8)} → ${streamId}  video=${hasVideo} audio=${hasAudio}${audioOnly?" [audio-only]":""}${safari?" [safari]":""}`);
  } catch(_) {
    console.log(`[stream] ${sid.slice(0,8)} → ${streamId}  probe failed, assuming video`);
  }

  const streamUrl = tsUrl; // always start with .ts
  const IGNORE_RE = /^\[h264|^\[hevc|^\[aac|^\[mp3|PES packet|Packet corrupt|non monotonous|non-existing SPS|non-existing PPS|no frame!|Could not find ref|Error constructing|Last message repeated|frame size not set/i;

  let restarts = 0;
  let ff = spawnFfmpeg(streamUrl, audioOnly, safari, dir, m3u8, 0);
  ff.stderr.on("data", d => {
    const m = d.toString().trim();
    if (m && !IGNORE_RE.test(m)) console.error(`[ff:${sid.slice(0,8)}]`, m);
  });

  const handleClose = () => {
    const s = sessions.get(sid);
    if (!s || s.dead) return;
    if (CFG.maxRestarts > 0 && restarts >= CFG.maxRestarts) {
      console.log(`[stream] ${sid.slice(0,8)} max restarts reached`);
      killSession(sid); return;
    }
    restarts++;
    const next = segCount(dir);
    ff = spawnFfmpeg(streamUrl, audioOnly, safari, dir, m3u8, next);
    ff.stderr.on("data", d => { const m=d.toString().trim(); if(m&&!IGNORE_RE.test(m)) console.error(`[ff:${sid.slice(0,8)}]`,m); });
    ff.on("close", handleClose);
    s.ff = ff;
  };
  ff.on("close", handleClose);
  ff.on("error", err => console.error("[ff] spawn:", err.message));

  // Watchdog: restart if no new segments for stallRestart ms
  let lastSeg = 0, lastSegTime = Date.now(), watchdogArmed = false;
  const watchdog = setInterval(() => {
    const s = sessions.get(sid); if (!s||s.dead) { clearInterval(watchdog); return; }
    const n = segCount(dir);
    if (n > lastSeg) { lastSeg=n; lastSegTime=Date.now(); if(n>=CFG.prebuf) watchdogArmed=true; }
    else if (watchdogArmed && Date.now()-lastSegTime > CFG.stallRestart) {
      lastSegTime = Date.now();
      try { s.ff.kill("SIGKILL"); } catch(_) {}
    }
  }, 1000);

  const idleTimer = setTimeout(() => killSession(sid), CFG.idle);
  sessions.set(sid, { ff, dir, idleTimer, watchdog, dead: false });

  // Wait for prebuf segments
  const t0 = Date.now();
  const prebuf = audioOnly ? CFG.audioPrebuf : CFG.prebuf;
  const poll = setInterval(() => {
    if (!sessions.has(sid)) { clearInterval(poll); if (!res.headersSent) res.status(502).json({ error:"Stream failed" }); return; }
    if (segCount(dir) >= prebuf && fs.existsSync(m3u8) && fs.statSync(m3u8).size > 0) {
      clearInterval(poll);
      console.log(`[stream] ${sid.slice(0,8)} ready`);
      res.json({ ok:true, sessionId:sid, url:`/hls/${sid}/index.m3u8`, audioOnly,
        hlsCfg:{ maxBufferLength:CFG.hlsBuf, backBufferLength:CFG.backBuf,
          liveSyncSeconds:CFG.liveSync, maxStarvationDelay:CFG.stallDelay, snapLive:CFG.snapLive } });
    } else if (Date.now()-t0 > 30000) {
      clearInterval(poll); killSession(sid);
      if (!res.headersSent) res.status(504).json({ error:"Stream timed out" });
    }
  }, 300);
});

app.post("/api/stream/heartbeat/:sid", (req,res) => {
  if (!sessions.has(req.params.sid)) return res.status(404).json({ error:"Session gone" });
  resetIdle(req.params.sid); res.json({ ok:true });
});
app.post("/api/stream/stop/:sid", (req,res) => { killSession(req.params.sid); res.json({ ok:true }); });
app.post("/api/stream/stopall", (req,res) => {
  const sids = [...sessions.keys()];
  sids.forEach(sid => killSession(sid));
  console.log("[stream] stopped all:", sids.length);
  res.json({ ok:true, stopped:sids.length });
});

// ── HLS serving ───────────────────────────────────────────────────
app.get("/hls/:sid/:file", (req, res) => {
  const { sid, file } = req.params;
  const fp = path.join(HLS_DIR, sid, file);
  if (!fs.existsSync(fp)) return res.status(404).send("Not found");
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (file.endsWith(".m3u8")) {
    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.setHeader("Cache-Control", "no-cache");
    try {
      const raw = fs.readFileSync(fp, "utf8");
      // Rewrite segment filenames to full URLs
      res.send(raw.replace(/^(seg\d+\.ts)$/mg, `/hls/${sid}/$1`));
    } catch(_) { res.status(500).end(); }
  } else {
    res.setHeader("Content-Type", "video/mp2t");
    res.setHeader("Cache-Control", "public,max-age=10");
    res.sendFile(fp);
  }
});

// ── Logo proxy ────────────────────────────────────────────────────
app.get("/logo", async (req, res) => {
  const url = req.query.url;
  if (!url || !/^https?:\/\//i.test(url)) return res.status(400).end();
  try {
    const p = new URL(url), lib = p.protocol === "https:" ? https : http;
    const preq = lib.request({
      hostname:p.hostname, port:p.port||(p.protocol==="https:"?443:80),
      path:p.pathname+p.search, method:"GET",
      headers:{"User-Agent":"Mozilla/5.0","Referer":p.origin,"Accept":"image/*,*/*"},
    }, pres => {
      res.setHeader("Content-Type", pres.headers["content-type"]||"image/png");
      res.setHeader("Cache-Control","public,max-age=86400");
      res.setHeader("Access-Control-Allow-Origin","*");
      pres.pipe(res, { end:true });
    });
    preq.on("error", () => res.status(502).end());
    preq.setTimeout(5000, () => { preq.destroy(); res.status(504).end(); });
    preq.end();
  } catch(_) { res.status(400).end(); }
});

// ── Static ────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, "../static")));
app.get("*", (req,res) => res.sendFile(path.join(__dirname,"../static/index.html")));
process.on("SIGTERM", () => { [...sessions.keys()].forEach(killSession); process.exit(0); });
app.listen(PORT, () => console.log(`Stream :${PORT}  XC: ${XC_HOST}`));
