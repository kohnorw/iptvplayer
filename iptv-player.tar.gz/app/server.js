"use strict";

const express              = require("express");
const path                 = require("path");
const fs                   = require("fs");
const http                 = require("http");
const https                = require("https");
const { spawn, spawnSync } = require("child_process");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
const XC_HOST  = (process.env.XC_HOST || "http://192.168.1.124:3000").replace(/\/+$/, "");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
app.use(express.json({ limit: "10mb" }));

// ── Per-user data ─────────────────────────────────────────────────
function userFile(u, type) {
  return path.join(DATA_DIR, `${type}_${u.replace(/[^a-zA-Z0-9_\-\.]/g,"_")}.json`);
}
function readUser(u, type, def) {
  try { return JSON.parse(fs.readFileSync(userFile(u,type),"utf8")); } catch(_){ return def; }
}
function writeUser(u, type, d) { fs.writeFileSync(userFile(u,type), JSON.stringify(d)); }

// ── XC API fetch ──────────────────────────────────────────────────
async function xcFetch(url, ms=15000) {
  return new Promise((resolve, reject) => {
    const p   = new URL(url);
    const lib = p.protocol==="https:" ? https : http;
    const req = lib.request({
      hostname: p.hostname, port: p.port||(p.protocol==="https:"?443:80),
      path: p.pathname+p.search, method: "GET",
      headers: {"User-Agent":"Mozilla/5.0"},
    }, res => {
      let body="";
      res.on("data",c=>body+=c);
      res.on("end",()=>{ try{resolve(JSON.parse(body));}catch(_){reject(new Error(`Non-JSON HTTP ${res.statusCode}`));} });
    });
    req.on("error",reject);
    req.setTimeout(ms,()=>{ req.destroy(); reject(new Error("Timeout")); });
    req.end();
  });
}

function buildXcUrl(u,p,action,extra={}) {
  const url=new URL(`${XC_HOST}/player_api.php`);
  url.searchParams.set("username",u); url.searchParams.set("password",p);
  if (action) url.searchParams.set("action",action);
  for (const [k,v] of Object.entries(extra)) url.searchParams.set(k,v);
  return url.toString();
}

// ── Auth ──────────────────────────────────────────────────────────
app.post("/api/login", async (req,res) => {
  const {username,password}=req.body||{};
  if (!username||!password) return res.status(400).json({error:"username and password required"});
  try {
    const d=await xcFetch(buildXcUrl(username,password,null));
    if (d.user_info&&d.user_info.auth==1) {
      res.json({ok:true,status:d.user_info.status,expiry:d.user_info.exp_date,
        connections:`${d.user_info.active_cons}/${d.user_info.max_connections}`});
    } else { res.status(401).json({error:"Invalid username or password"}); }
  } catch(e){ res.status(502).json({error:"Cannot reach server: "+e.message}); }
});

// ── XC API proxy ──────────────────────────────────────────────────
const ALLOWED=new Set(["get_live_categories","get_live_streams","get_vod_categories","get_vod_streams","get_short_epg","get_epg"]);
app.get("/api/xc/:action", async (req,res) => {
  const {username,password}=req.query;
  if (!username||!password) return res.status(401).json({error:"Missing credentials"});
  const {action}=req.params;
  if (!ALLOWED.has(action)) return res.status(403).json({error:"Not allowed"});
  const extra={};
  for (const [k,v] of Object.entries(req.query)) if (k!=="username"&&k!=="password") extra[k]=v;
  try { res.json(await xcFetch(buildXcUrl(username,password,action,extra))); }
  catch(e){ res.status(502).json({error:e.message}); }
});

app.get("/api/epg/:streamId", async (req,res) => {
  const {username,password}=req.query;
  if (!username||!password) return res.status(401).json({error:"Missing credentials"});
  try { res.json(await xcFetch(buildXcUrl(username,password,"get_short_epg",{stream_id:req.params.streamId,limit:8}))); }
  catch(_){ res.json({epg_listings:[]}); }
});

// ── Favourites + Prefs ────────────────────────────────────────────
app.get("/api/favs/:u",   (req,res)=>res.json(readUser(req.params.u.trim(),"favs",[])));
app.post("/api/favs/:u",  (req,res)=>{ writeUser(req.params.u.trim(),"favs",Array.isArray(req.body)?req.body:[]); res.json({ok:true}); });
app.get("/api/prefs/:u",  (req,res)=>res.json(readUser(req.params.u.trim(),"prefs",{timezone:"America/Toronto"})));
app.post("/api/prefs/:u", (req,res)=>{ writeUser(req.params.u.trim(),"prefs",req.body||{}); res.json({ok:true}); });

// ── Audio codec detection ─────────────────────────────────────────
const probeCache = new Map(); // url -> { audioCodec, hasVideo, hasAudio, ts }
const PROBE_TTL  = 300000;    // 5 min cache

function detectStream(url) {
  const cached = probeCache.get(url);
  if (cached && Date.now() - cached.ts < PROBE_TTL) return cached;

  try {
    const r = spawnSync("ffprobe",[
      "-v","error","-user_agent","Mozilla/5.0",
      "-show_entries","stream=codec_type,codec_name",
      "-of","default=noprint_wrappers=1", url,
    ],{timeout:8000,encoding:"utf8"});
    const out = (r.stdout||"").toLowerCase();
    const lines = out.split("\n");
    const hasVideo = out.includes("codec_type=video");
    const hasAudio = out.includes("codec_type=audio");
    const audioLine = lines.find(l=>l.startsWith("codec_name="));
    const audioCodec = audioLine ? audioLine.split("=")[1].trim() : "";
    const result = {hasVideo, hasAudio, audioCodec, ts:Date.now()};
    probeCache.set(url, result);
    return result;
  } catch(_){
    return {hasVideo:true, hasAudio:true, audioCodec:"", ts:Date.now()};
  }
}

// ── Active ffmpeg processes (audio transcoding only) ──────────────
const active = new Map();
function killActive(key) {
  const ff = active.get(key);
  if (!ff) return;
  try { ff.kill("SIGKILL"); } catch(_) {}
  active.delete(key);
}

// ── HLS proxy — pass XC-Menu segments directly to browser ─────────
// Rewrites the m3u8 playlist so segments go through our proxy
// (needed to avoid CORS and Cloudflare hotlink blocks)
// Audio transcoding via ffmpeg pipe ONLY when source codec unsupported

function proxyRequest(xcUrl, res, extraHeaders={}) {
  const p = new URL(xcUrl);
  const lib = p.protocol==="https:" ? https : http;
  const req = lib.request({
    hostname: p.hostname,
    port: p.port||(p.protocol==="https:"?443:80),
    path: p.pathname+p.search,
    method: "GET",
    headers: { "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", ...extraHeaders },
  }, upstream => {
    // Forward status and key headers
    const ct = upstream.headers["content-type"]||"";
    res.setHeader("Access-Control-Allow-Origin","*");
    res.setHeader("Cache-Control","no-cache,no-store");
    res.setHeader("Content-Type", ct || "application/octet-stream");
    upstream.pipe(res, {end:true});
  });
  req.on("error", ()=>{ if (!res.headersSent) res.status(502).end(); });
  req.setTimeout(10000, ()=>{ req.destroy(); if (!res.headersSent) res.status(504).end(); });
  req.end();
}

// Proxy and rewrite .m3u8 playlists — replace segment URLs with our proxy path
app.get("/proxy/m3u8/:username/:password/:streamId", async (req,res) => {
  const {username,password,streamId} = req.params;
  const xcUrl = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.m3u8`;

  const p = new URL(xcUrl);
  const lib = p.protocol==="https:" ? https : http;
  const request = lib.request({
    hostname:p.hostname, port:p.port||(p.protocol==="https:"?443:80),
    path:p.pathname+p.search, method:"GET",
    headers:{"User-Agent":"Mozilla/5.0"},
  }, upstream => {
    let body = "";
    upstream.on("data", c=>body+=c);
    upstream.on("end", ()=>{
      res.setHeader("Content-Type","application/vnd.apple.mpegurl");
      res.setHeader("Cache-Control","no-cache,no-store");
      res.setHeader("Access-Control-Allow-Origin","*");

      // Rewrite segment URLs to go through our /proxy/seg/ endpoint
      const base = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/`;
      const rewritten = body
        .split("\n")
        .map(line => {
          line = line.trim();
          if (!line || line.startsWith("#")) return line;
          // Resolve relative URLs and rewrite through our proxy
          const segUrl = line.startsWith("http") ? line : base + line;
          return `/proxy/seg/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${encodeURIComponent(segUrl)}`;
        })
        .join("\n");

      res.send(rewritten);
    });
  });
  request.on("error",()=>res.status(502).end());
  request.end();
});

// Proxy raw .ts segments — if audio needs transcoding, pipe through ffmpeg
app.get("/proxy/seg/:username/:password/:segUrl", (req,res) => {
  const {username,password} = req.params;
  const segUrl = decodeURIComponent(req.params.segUrl);
  const key = `${username}_${segUrl}`;

  // Check if this stream needs audio transcoding
  // Use the stream's base URL for probe caching
  const streamBase = segUrl.replace(/\/[^\/]+\.ts.*$/, "");
  const info = detectStream(segUrl); // probe the actual segment

  const UNSUPPORTED_AUDIO = ["ac3","eac3","mp2","dts","truehd","mlp"];
  const needsTranscode = info.hasAudio && UNSUPPORTED_AUDIO.some(c=>info.audioCodec.includes(c));

  res.setHeader("Access-Control-Allow-Origin","*");
  res.setHeader("Cache-Control","no-cache");
  res.setHeader("Content-Type","video/mp2t");

  if (!needsTranscode) {
    // Pass segment directly — zero CPU, zero latency
    proxyRequest(segUrl, res);
    return;
  }

  // Audio needs transcoding — pipe through ffmpeg
  console.log(`[transcode] ${info.audioCodec}→aac: ${segUrl.split("/").pop()}`);
  const ff = spawn("ffmpeg",[
    "-user_agent","Mozilla/5.0",
    "-i", segUrl,
    "-c:v","copy",
    "-c:a","aac","-b:a","192k","-ar","48000","-ac","2",
    "-f","mpegts","pipe:1",
  ]);
  active.set(key, ff);
  ff.stdout.pipe(res,{end:true});
  ff.on("close",()=>{ active.delete(key); if(!res.writableEnded) res.end(); });
  ff.on("error",()=>{ active.delete(key); if(!res.headersSent) res.status(502).end(); });
  req.on("close",()=>killActive(key));
});

// ── Stream URL resolver — tells browser which URL format to use ───
app.get("/api/stream/url/:username/:password/:streamId", (req,res) => {
  const {username,password,streamId} = req.params;
  // Return the proxied m3u8 URL — browser plays it via HLS.js
  res.json({
    url: `/proxy/m3u8/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}`,
  });
});

// ── Logo proxy ────────────────────────────────────────────────────
app.get("/logo", async (req,res) => {
  const url=req.query.url;
  if (!url||!/^https?:\/\//i.test(url)) return res.status(400).end();
  try {
    const p=new URL(url),lib=p.protocol==="https:"?https:http;
    const preq=lib.request({hostname:p.hostname,port:p.port||(p.protocol==="https:"?443:80),
      path:p.pathname+p.search,method:"GET",
      headers:{"User-Agent":"Mozilla/5.0","Referer":p.origin,"Accept":"image/*,*/*"}},
      pres=>{
        res.setHeader("Content-Type",pres.headers["content-type"]||"image/png");
        res.setHeader("Cache-Control","public,max-age=86400");
        res.setHeader("Access-Control-Allow-Origin","*");
        pres.pipe(res,{end:true});
      });
    preq.on("error",()=>res.status(502).end());
    preq.setTimeout(5000,()=>{preq.destroy();res.status(504).end();});
    preq.end();
  } catch(_){res.status(400).end();}
});

// ── Static + SPA ──────────────────────────────────────────────────
app.use(express.static(path.join(__dirname,"../static")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../static/index.html")));
process.on("SIGTERM",()=>{ active.forEach((_,k)=>killActive(k)); process.exit(0); });
app.listen(PORT,()=>console.log(`Stream :${PORT}  XC: ${XC_HOST}`));
