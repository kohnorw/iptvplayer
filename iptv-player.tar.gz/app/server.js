"use strict";

const express   = require("express");
const path      = require("path");
const fs        = require("fs");
const http      = require("http");
const https     = require("https");
const { spawn } = require("child_process");
const os        = require("os");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
const XC_HOST  = (process.env.XC_HOST || "http://192.168.1.124:3000").replace(/\/+$/, "");
const HLS_DIR  = path.join(os.tmpdir(), "iptv-hls");

[DATA_DIR, HLS_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

// Each user gets their own favourites file: /data/favs_USERNAME.json
function favFile(username) {
  // Sanitise username — only allow alphanumeric and basic chars
  const safe = username.replace(/[^a-zA-Z0-9_\-\.]/g, "_");
  return path.join(DATA_DIR, `favs_${safe}.json`);
}

function getFavs(username) {
  try { return JSON.parse(fs.readFileSync(favFile(username), "utf8")); } catch(_){ return []; }
}

function setFavs(username, data) {
  fs.writeFileSync(favFile(username), JSON.stringify(Array.isArray(data) ? data : [], null, 2));
}

app.use(express.json({ limit: "10mb" }));

// ── XC fetch ──────────────────────────────────────────────────────
async function xcFetch(url, ms = 15000) {
  return new Promise((resolve, reject) => {
    const p   = new URL(url);
    const lib = p.protocol === "https:" ? https : http;
    const req = lib.request({
      hostname: p.hostname,
      port:     p.port || (p.protocol === "https:" ? 443 : 80),
      path:     p.pathname + p.search,
      method:   "GET",
      headers:  { "User-Agent": "Mozilla/5.0" },
    }, res => {
      let body = "";
      res.on("data", c => body += c);
      res.on("end", () => {
        try   { resolve(JSON.parse(body)); }
        catch (_) { reject(new Error(`Non-JSON (HTTP ${res.statusCode}): ${body.slice(0,80)}`)); }
      });
    });
    req.on("error", reject);
    req.setTimeout(ms, () => { req.destroy(); reject(new Error("Timeout")); });
    req.end();
  });
}

function buildXcUrl(u, p, action, extra = {}) {
  const url = new URL(`${XC_HOST}/player_api.php`);
  url.searchParams.set("username", u);
  url.searchParams.set("password", p);
  if (action) url.searchParams.set("action", action);
  for (const [k, v] of Object.entries(extra)) url.searchParams.set(k, v);
  return url.toString();
}

// ── Auth ──────────────────────────────────────────────────────────
app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "username and password required" });
  try {
    const d = await xcFetch(buildXcUrl(username, password, null));
    if (d.user_info && d.user_info.auth == 1) {
      res.json({ ok: true, status: d.user_info.status, expiry: d.user_info.exp_date,
        connections: `${d.user_info.active_cons}/${d.user_info.max_connections}` });
    } else {
      res.status(401).json({ error: "Invalid username or password" });
    }
  } catch(e) { res.status(502).json({ error: "Cannot reach server: " + e.message }); }
});

// ── XC API proxy ──────────────────────────────────────────────────
const ALLOWED = new Set(["get_live_categories","get_live_streams","get_short_epg","get_epg"]);

app.get("/api/xc/:action", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  const { action } = req.params;
  if (!ALLOWED.has(action)) return res.status(403).json({ error: "Not allowed" });
  const extra = {};
  for (const [k, v] of Object.entries(req.query)) if (k !== "username" && k !== "password") extra[k] = v;
  try { res.json(await xcFetch(buildXcUrl(username, password, action, extra))); }
  catch(e) { res.status(502).json({ error: e.message }); }
});

app.get("/api/epg/:streamId", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  try { res.json(await xcFetch(buildXcUrl(username, password, "get_short_epg", { stream_id: req.params.streamId, limit: 8 }))); }
  catch(_) { res.json({ epg_listings: [] }); }
});

// ── Favourites — one file per user ───────────────────────────────
app.get("/api/favs/:username", (req, res) => {
  const { username } = req.params;
  const favs = getFavs(username);
  console.log(`[favs] GET "${username}" → ${favs.length} items  (file: favs_${username.replace(/[^a-zA-Z0-9_\-\.]/g,"_")}.json)`);
  res.json(favs);
});

app.post("/api/favs/:username", (req, res) => {
  const { username } = req.params;
  const data = Array.isArray(req.body) ? req.body : [];
  setFavs(username, data);
  console.log(`[favs] POST "${username}" → saved ${data.length} items`);
  res.json({ ok: true });
});

// ── Active streams ────────────────────────────────────────────────
const streams = new Map();

function killStream(sid) {
  const s = streams.get(sid);
  if (!s) return;
  clearTimeout(s.timer);
  try { s.ff.kill("SIGKILL"); } catch(_) {}
  try { fs.readdirSync(s.dir).forEach(f => fs.unlinkSync(path.join(s.dir, f))); fs.rmdirSync(s.dir); } catch(_) {}
  streams.delete(sid);
}

function resetTimer(sid) {
  const s = streams.get(sid);
  if (!s) return;
  clearTimeout(s.timer);
  s.timer = setTimeout(() => killStream(sid), 15000);
}

app.post("/api/stream/start", (req, res) => {
  const { username, password, streamId, sessionId: old } = req.body || {};
  if (!username || !password || !streamId) return res.status(400).json({ error: "Missing params" });

  if (old) killStream(old);

  const sid   = Math.random().toString(36).slice(2) + Date.now();
  const dir   = path.join(HLS_DIR, sid);
  const m3u8  = path.join(dir, "index.m3u8");
  const xcUrl = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.ts`;

  fs.mkdirSync(dir, { recursive: true });

  // Use m3u8 input (XC-Menu native HLS) — more stable than raw TS
  const xcUrlM3u8 = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.m3u8`;

  const ff = spawn("ffmpeg", [
    "-loglevel",         "warning",
    "-user_agent",       "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "-analyzeduration",  "1000000",
    "-probesize",        "1000000",
    "-fflags",           "+nobuffer+discardcorrupt+genpts",
    "-i",                xcUrlM3u8,
    "-map",              "0",          // all streams — fixes missing audio tracks
    "-c",                "copy",       // zero transcoding
    "-f",                "hls",
    "-hls_time",         "2",
    "-hls_list_size",    "5",
    "-hls_flags",        "delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_segment_type", "mpegts",
    "-hls_segment_filename", path.join(dir, "seg%03d.ts"),
    "-start_number",     "0",
    m3u8,
  ]);

  ff.stderr.on("data", d => { const m = d.toString().trim(); if (m) console.error(`[ff]`, m); });
  ff.on("error", err => console.error(`[ff] spawn:`, err.message));
  ff.on("close", () => streams.delete(sid));

  const timer = setTimeout(() => killStream(sid), 15000);
  streams.set(sid, { ff, dir, timer });

  const t0   = Date.now();
  const poll = setInterval(() => {
    try {
      if (fs.existsSync(m3u8) && fs.statSync(m3u8).size > 0) {
        clearInterval(poll);
        res.json({ ok: true, sessionId: sid, url: `/hls/${sid}/index.m3u8` });
      } else if (Date.now() - t0 > 12000) {
        clearInterval(poll);
        killStream(sid);
        res.status(504).json({ error: "Stream did not start — try another channel" });
      }
    } catch(_) {}
  }, 250);
});

app.post("/api/stream/heartbeat/:sid", (req, res) => {
  if (!streams.has(req.params.sid)) return res.status(404).json({ error: "Session gone" });
  resetTimer(req.params.sid);
  res.json({ ok: true });
});

app.post("/api/stream/stop/:sid", (req, res) => {
  killStream(req.params.sid);
  res.json({ ok: true });
});

app.get("/hls/:sid/:file", (req, res) => {
  const fp = path.join(HLS_DIR, req.params.sid, req.params.file);
  if (!fs.existsSync(fp)) return res.status(404).send("Not found");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
  res.setHeader("Content-Type", req.params.file.endsWith(".m3u8") ? "application/vnd.apple.mpegurl" : "video/mp2t");
  res.sendFile(fp);
});

// Static + SPA — must be last
app.use(express.static(path.join(__dirname, "../static")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../static/index.html")));

process.on("SIGTERM", () => { streams.forEach((_, sid) => killStream(sid)); process.exit(0); });
app.listen(PORT, () => console.log(`IPTV Player :${PORT}  XC: ${XC_HOST}`));
