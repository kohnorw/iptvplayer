"use strict";
const express = require("express");
const path    = require("path");
const fs      = require("fs");
const http    = require("http");
const https   = require("https");
const os      = require("os");
const { spawn, spawnSync } = require("child_process");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
const XC_HOST  = (process.env.XC_HOST || "http://192.168.1.124:3000").replace(/\/+$/, "");

// Safari transcode still uses ffmpeg — but ONLY for Safari
const HLS_DIR  = path.join(os.tmpdir(), "iptv-hls");
[DATA_DIR, HLS_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));
app.use(express.json({ limit: "10mb" }));

// ── Config ────────────────────────────────────────────────────────
const UA = {
  chrome:   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
  vlc:      "VLC/3.0.20 LibVLC/3.0.20",
  tivimate: "TiviMate/4.7.0",
};
let C = {
  ua: UA.chrome,
  // Safari transcode settings (only used when safari=true)
  safariTranscode: true,
  safariProfile:   "baseline",
  safariPreset:    "ultrafast",
  safariVbr:       0,
  segSecs:         2,
  safariWindow:    4,
  safariStall:     12,
  audioBr:         192,
  audioSr:         48000,
  // Session management
  idle:            20000,
  stallRestart:    10000,
  prebuf:          2,
  audioPrebuf:     4,
};

// ── Helpers ───────────────────────────────────────────────────────
const ufile = (u, t) => path.join(DATA_DIR, `${t}_${u.replace(/[^a-zA-Z0-9_\-.]/g,"_")}.json`);
const ruser = (u, t, d) => { try { return JSON.parse(fs.readFileSync(ufile(u,t),"utf8")); } catch(_) { return d; } };
const wuser = (u, t, d) => fs.writeFileSync(ufile(u,t), JSON.stringify(d));

function xfetch(url, ms=15000) {
  return new Promise((res, rej) => {
    const p = new URL(url), lib = p.protocol === "https:" ? https : http;
    const req = lib.request({
      hostname: p.hostname, port: p.port||(p.protocol==="https:"?443:80),
      path: p.pathname+p.search, method: "GET", headers: {"User-Agent":"Mozilla/5.0"}
    }, r => {
      let b = ""; r.on("data", c => b+=c);
      r.on("end", () => { try { res(JSON.parse(b)); } catch(_) { rej(new Error("Non-JSON")); } });
    });
    req.on("error", rej);
    req.setTimeout(ms, () => { req.destroy(); rej(new Error("Timeout")); });
    req.end();
  });
}

function xurl(u, p, action, extra={}) {
  const url = new URL(`${XC_HOST}/player_api.php`);
  url.searchParams.set("username", u); url.searchParams.set("password", p);
  if (action) url.searchParams.set("action", action);
  Object.entries(extra).forEach(([k,v]) => url.searchParams.set(k,v));
  return url.toString();
}

function detectStream(url) {
  const r = spawnSync("ffprobe", [
    "-v","quiet","-user_agent","Mozilla/5.0",
    "-show_entries","stream=codec_type,r_frame_rate,codec_name",
    "-of","json", url
  ], { timeout: 8000, encoding: "utf8" });
  try {
    const streams = JSON.parse(r.stdout||"{}").streams || [];
    if (!streams.length) return null;
    const v = streams.find(s => s.codec_type === "video");
    const a = streams.find(s => s.codec_type === "audio");
    let fps = 25;
    if (v?.r_frame_rate) {
      const [n,d] = v.r_frame_rate.split("/").map(Number);
      if (d > 0) fps = Math.round(n/d);
    }
    const videoCodec = v?.codec_name || "";
    const needsTranscode = /hevc|h265|av1|vp9/i.test(videoCodec);
    return { hasVideo:!!v, hasAudio:!!a, fps, videoCodec, needsTranscode };
  } catch(_) { return null; }
}

// ── API Routes ────────────────────────────────────────────────────
app.post("/api/login", async (req,res) => {
  const {username,password} = req.body||{};
  if (!username||!password) return res.status(400).json({error:"Missing credentials"});
  try {
    const d = await xfetch(xurl(username,password,null));
    if (d.user_info?.auth==1) res.json({ok:true,status:d.user_info.status,expiry:d.user_info.exp_date,connections:`${d.user_info.active_cons}/${d.user_info.max_connections}`});
    else res.status(401).json({error:"Invalid credentials"});
  } catch(e) { res.status(502).json({error:e.message}); }
});

const ALLOWED = new Set(["get_live_categories","get_live_streams","get_vod_categories","get_vod_streams","get_short_epg","get_epg"]);
app.get("/api/xc/:action", async (req,res) => {
  const {username,password} = req.query;
  if (!username||!password) return res.status(401).json({error:"Missing credentials"});
  if (!ALLOWED.has(req.params.action)) return res.status(403).json({error:"Not allowed"});
  const extra={};
  Object.entries(req.query).forEach(([k,v])=>{ if(k!=="username"&&k!=="password") extra[k]=v; });
  try { res.json(await xfetch(xurl(username,password,req.params.action,extra))); }
  catch(e) { res.status(502).json({error:e.message}); }
});

app.get("/api/epg/:id", async (req,res) => {
  const {username,password} = req.query;
  if (!username||!password) return res.status(401).json({error:"Missing credentials"});
  try { res.json(await xfetch(xurl(username,password,"get_short_epg",{stream_id:req.params.id,limit:8}))); }
  catch(_) { res.json({epg_listings:[]}); }
});

app.get("/api/favs/:u",  (req,res) => res.json(ruser(req.params.u.trim(),"favs",[])));
app.post("/api/favs/:u", (req,res) => { wuser(req.params.u.trim(),"favs",Array.isArray(req.body)?req.body:[]); res.json({ok:true}); });
app.get("/api/prefs/:u",  (req,res) => res.json(ruser(req.params.u.trim(),"prefs",{timezone:"America/Toronto"})));
app.post("/api/prefs/:u", (req,res) => { wuser(req.params.u.trim(),"prefs",req.body||{}); res.json({ok:true}); });

app.post("/api/settings", (req,res) => {
  const s=req.body||{};
  const bool=(v,d)=>v===undefined?d:(v!==false&&v!=="false"&&v!=="0");
  const int=(v,d,m=0)=>Math.max(m,parseInt(v)||d);
  C.ua             = UA[s.ua]||UA.chrome;
  C.safariTranscode= bool(s.safariTranscode,true);
  C.safariProfile  = ["baseline","main","high"].includes(s.safariProfile)?s.safariProfile:"baseline";
  C.safariPreset   = ["ultrafast","superfast","veryfast","faster"].includes(s.safariPreset)?s.safariPreset:"ultrafast";
  C.safariVbr      = int(s.safariVbr,0,0);
  C.segSecs        = int(s.segSecs,2,1);
  C.safariWindow   = int(s.safariWindow,4,2);
  C.safariStall    = int(s.safariStall,12,4);
  C.audioBr        = int(s.audioBr,192,64);
  C.audioSr        = s.audioSr==="44100"?44100:48000;
  C.idle           = int(s.idle,20,5)*1000;
  C.prebuf         = int(s.prebuf,2,1);
  console.log("[settings]", JSON.stringify(C));
  res.json({ok:true});
});

// ── Stream URL endpoint ───────────────────────────────────────────
// For Chrome/Firefox: return the upstream .m3u8 URL directly
// The browser plays it with zero server involvement — no ffmpeg, no lag
// For Safari: still transcode because Safari needs H.264+IDR alignment
app.post("/api/stream/url", (req,res) => {
  const {username,password,streamId,safari} = req.body||{};
  if (!username||!password||!streamId) return res.status(400).json({error:"Missing params"});

  const m3u8Url = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.m3u8`;
  const tsUrl   = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.ts`;

  if (!safari || !C.safariTranscode) {
    // Direct play — give browser the upstream URL, zero lag, zero CPU
    console.log(`[direct] ${streamId} → ${m3u8Url.slice(-20)}`);
    res.json({ ok:true, url: m3u8Url, direct: true });
    return;
  }

  // Safari: probe then transcode
  res.json({ ok:true, url: m3u8Url, direct: false, needsTranscode: true, tsUrl, m3u8Url });
});

// ── Safari transcode sessions ─────────────────────────────────────
const sessions = new Map();
const segCount = dir => { try { return fs.readdirSync(dir).filter(f=>f.endsWith(".ts")).length; } catch(_) { return 0; } };

function killSession(sid) {
  const s = sessions.get(sid); if (!s) return; s.dead=true;
  clearTimeout(s.idleTimer); clearTimeout(s.heartbeatTimer); clearInterval(s.watchdog);
  try { s.ff.kill("SIGKILL"); } catch(_) {}
  try { if(fs.existsSync(s.dir)){fs.readdirSync(s.dir).forEach(f=>{try{fs.unlinkSync(path.join(s.dir,f));}catch(_){}});fs.rmdirSync(s.dir);} } catch(_) {}
  sessions.delete(sid);
}
function touchHeartbeat(sid) {
  const s=sessions.get(sid); if(!s) return;
  clearTimeout(s.heartbeatTimer);
  s.heartbeatTimer=setTimeout(()=>{ console.log(`[stream] ${sid.slice(0,8)} heartbeat timeout`); killSession(sid); },25000);
}
function resetIdle(sid) {
  const s=sessions.get(sid); if(!s) return;
  clearTimeout(s.idleTimer);
  s.idleTimer=setTimeout(()=>killSession(sid),C.idle);
}

app.post("/api/stream/start", (req,res) => {
  const {username,password,streamId,sessionId:oldSid,safari} = req.body||{};
  if (!username||!password||!streamId) return res.status(400).json({error:"Missing params"});
  if (oldSid) killSession(oldSid);

  const sid  = Date.now().toString(36)+Math.random().toString(36).slice(2);
  const dir  = path.join(HLS_DIR,sid);
  const m3u8 = path.join(dir,"index.m3u8");
  fs.mkdirSync(dir,{recursive:true});

  const urlTs   = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.ts`;
  const urlM3u8 = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.m3u8`;

  // Probe to detect codec/fps
  let info = detectStream(urlTs);
  let xcUrl = urlTs;
  if (!info) { info=detectStream(urlM3u8); xcUrl=urlM3u8; }
  else if (info.needsTranscode||safari) { xcUrl=urlM3u8; }
  if (!info) info={hasVideo:true,hasAudio:true,fps:25,videoCodec:"",needsTranscode:false};

  const audioOnly   = info.hasAudio&&!info.hasVideo;
  const is10bit     = info.needsTranscode||false;
  const profile     = (is10bit&&C.safariProfile==="baseline")?"main":C.safariProfile;
  const level       = profile==="baseline"?"3.1":profile==="main"?"4.0":"4.1";
  const gop         = Math.max(1,Math.round(info.fps*C.segSecs));
  const fps         = info.fps;

  console.log(`[stream:safari] ${sid.slice(0,8)} → ${streamId} ${profile}/${level} fps=${fps} gop=${gop}`);

  const SKIP = /frame size not set|PES packet|Packet corrupt|Last message repeated|non monoton|non-existing SPS|no frame!|\[h264 @|\[hevc @|\[aac @|\[mp3 @/i;
  const onErr = d => { const m=d.toString().trim(); if(m&&!SKIP.test(m)) console.error(`[ff:${sid.slice(0,8)}]`,m); };

  const vbr  = C.safariVbr>0?["-b:v",C.safariVbr+"k"]:[];
  const spawnArgs = [
    "-hide_banner","-loglevel","warning",
    "-reconnect","1","-reconnect_streamed","1",
    "-reconnect_at_eof","1","-reconnect_on_network_error","1",
    "-reconnect_delay_max","5","-rw_timeout","15000000",
    "-thread_queue_size","4096",
    "-fflags","+genpts+igndts+discardcorrupt",
    "-use_wallclock_as_timestamps","1",
    "-avoid_negative_ts","make_zero",
    "-user_agent",C.ua,
    "-i",xcUrl,
    "-map","0:v:0?","-map","0:a:0?","-sn","-dn",
    "-c:v","libx264","-profile:v",profile,"-level:v",level,
    "-preset",C.safariPreset,"-tune","zerolatency",
    "-pix_fmt","yuv420p",
    "-g",String(gop),"-keyint_min",String(gop),
    "-forced_idr","1","-sc_threshold","0","-bf","0",
    ...vbr,
    "-c:a","aac","-profile:a","aac_low",
    "-b:a",C.audioBr+"k","-ar",String(C.audioSr),"-ac","2",
    "-af","aresample=async=1000:min_hard_comp=0.100:first_pts=0",
    "-f","hls",
    "-hls_time",String(C.segSecs),
    "-hls_list_size",String(C.safariWindow||4),
    "-hls_delete_threshold","3",
    "-hls_flags","delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_allow_cache","0",
    "-hls_segment_type","mpegts",
    "-hls_segment_filename",path.join(dir,"seg%06d.ts"),
    "-start_number","0",
    m3u8,
  ];

  let failCount=0, everWorked=false;
  let ff = spawn("ffmpeg",spawnArgs);
  ff.stderr.on("data",onErr);

  const restart = () => {
    const s=sessions.get(sid); if(!s||s.dead) return;
    if (everWorked) { failCount=0; }
    else { failCount++; if(failCount>=5){console.error(`[stream] ${sid.slice(0,8)} failed 5x — giving up`);killSession(sid);return;} }
    const delay=everWorked?1000:Math.min(1000*Math.pow(2,failCount-1),16000);
    setTimeout(()=>{
      const s2=sessions.get(sid); if(!s2||s2.dead) return;
      ff=spawn("ffmpeg",spawnArgs);
      ff.stderr.on("data",onErr); ff.on("close",restart);
      ff.on("error",e=>{console.error("[ff]",e.message);restart();});
      s2.ff=ff;
    },delay);
  };
  ff.on("close",restart);
  ff.on("error",e=>{console.error("[ff]",e.message);restart();});

  let lastN=0,lastT=Date.now();
  const watchdog=setInterval(()=>{
    const s=sessions.get(sid); if(!s||s.dead){clearInterval(watchdog);return;}
    const n=segCount(dir);
    if(n>lastN){lastN=n;lastT=Date.now();if(!everWorked){everWorked=true;console.log(`[stream] ${sid.slice(0,8)} first segment written`);}}
    else if(everWorked&&Date.now()-lastT>C.stallRestart){lastT=Date.now();try{s.ff.kill("SIGKILL");}catch(_){}}
    else if(!everWorked&&Date.now()-lastT>30000){console.error(`[stream] ${sid.slice(0,8)} no segments in 30s`);killSession(sid);}
  },1000);

  const idleTimer=setTimeout(()=>killSession(sid),C.idle);
  sessions.set(sid,{ff,dir,idleTimer,heartbeatTimer:null,watchdog,dead:false});
  touchHeartbeat(sid);

  const prebuf=audioOnly?C.audioPrebuf:Math.max(C.prebuf,3);
  const t0=Date.now();
  const poll=setInterval(()=>{
    if(!sessions.has(sid)){clearInterval(poll);if(!res.headersSent)res.status(502).json({error:"Stream failed"});return;}
    if(segCount(dir)>=prebuf&&fs.existsSync(m3u8)&&fs.statSync(m3u8).size>0){
      clearInterval(poll);
      console.log(`[stream] ${sid.slice(0,8)} ready`);
      res.json({ok:true,sessionId:sid,url:`/hls/${sid}/index.m3u8`,audioOnly,hlsCfg:{segSecs:C.segSecs}});
    } else if(Date.now()-t0>30000){
      clearInterval(poll);killSession(sid);
      if(!res.headersSent)res.status(504).json({error:"Timed out"});
    }
  },300);
});

app.post("/api/stream/heartbeat/:sid",(req,res)=>{
  if(!sessions.has(req.params.sid))return res.status(404).json({error:"Gone"});
  resetIdle(req.params.sid); touchHeartbeat(req.params.sid); res.json({ok:true});
});
app.post("/api/stream/stop/:sid",(req,res)=>{ killSession(req.params.sid); res.json({ok:true}); });
app.post("/api/stream/stopall",(req,res)=>{
  const sids=[...sessions.keys()]; sids.forEach(killSession);
  res.json({ok:true,stopped:sids.length});
});

// ── Direct stream proxy (Chrome/Firefox) ─────────────────────────
// Proxies the upstream m3u8/ts through our server to handle CORS.
// No ffmpeg, no transcoding — just pipes bytes from XC_HOST to browser.
// Zero CPU, zero lag — the upstream has already done all the work.
app.get("/api/proxy/stream/:user/:pass/:id/index.m3u8", async (req,res) => {
  const {user,pass,id} = req.params;
  const upUrl = `${XC_HOST}/live/${encodeURIComponent(user)}/${encodeURIComponent(pass)}/${id}.m3u8`;
  try {
    const p = new URL(upUrl), lib = p.protocol==="https:"?https:http;
    const upReq = lib.request({
      hostname:p.hostname, port:p.port||(p.protocol==="https:"?443:80),
      path:p.pathname+p.search, method:"GET",
      headers:{"User-Agent":C.ua}
    }, upRes => {
      res.setHeader("Access-Control-Allow-Origin","*");
      res.setHeader("Content-Type","application/vnd.apple.mpegurl");
      res.setHeader("Cache-Control","no-cache, no-store");
      // Rewrite segment URLs in the m3u8 to go through our proxy too
      let body = "";
      upRes.on("data", d => body += d.toString());
      upRes.on("end", () => {
        // Rewrite absolute .ts URLs to go through proxy
        const base = `${XC_HOST}/live/${encodeURIComponent(user)}/${encodeURIComponent(pass)}/`;
        const rewritten = body
          .replace(/^(https?:\/\/[^\s]+\.ts)/mg, seg => `/api/proxy/ts?url=${encodeURIComponent(seg)}`)
          .replace(/^([0-9]+\.ts)/mg, seg => `/api/proxy/ts?url=${encodeURIComponent(base+seg)}`);
        res.send(rewritten);
      });
    });
    upReq.on("error", e => res.status(502).json({error:e.message}));
    upReq.setTimeout(10000, () => { upReq.destroy(); res.status(504).end(); });
    upReq.end();
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.get("/api/proxy/ts", (req,res) => {
  const url = req.query.url;
  if (!url||!/^https?:\/\//i.test(url)) return res.status(400).end();
  try {
    const p = new URL(url), lib = p.protocol==="https:"?https:http;
    const upReq = lib.request({
      hostname:p.hostname, port:p.port||(p.protocol==="https:"?443:80),
      path:p.pathname+p.search, method:"GET",
      headers:{"User-Agent":C.ua}
    }, upRes => {
      res.setHeader("Access-Control-Allow-Origin","*");
      res.setHeader("Content-Type","video/mp2t");
      res.setHeader("Cache-Control","public,max-age=10");
      upRes.pipe(res, {end:true});
    });
    upReq.on("error", () => res.status(502).end());
    upReq.setTimeout(15000, () => { upReq.destroy(); res.status(504).end(); });
    upReq.end();
  } catch(_) { res.status(400).end(); }
});

// ── HLS serving (Safari transcode only) ──────────────────────────
app.get("/hls/:sid/:file",(req,res)=>{
  const fp=path.join(HLS_DIR,req.params.sid,req.params.file);
  if(!fs.existsSync(fp))return res.status(404).send("Not found");
  res.setHeader("Access-Control-Allow-Origin","*");
  if(req.params.file.endsWith(".m3u8")){
    res.setHeader("Content-Type","application/vnd.apple.mpegurl");
    res.setHeader("Cache-Control","no-cache, no-store, must-revalidate");
    try {
      const raw=fs.readFileSync(fp,"utf8");
      const out=raw
        .replace(/^.*[/\\](seg\d+\.ts)\s*$/mg,`/hls/${req.params.sid}/$1`)
        .replace(/^(seg\d+\.ts)\s*$/mg,`/hls/${req.params.sid}/$1`);
      res.send(out);
    } catch(_){res.status(500).end();}
  } else {
    res.setHeader("Content-Type","video/mp2t");
    res.setHeader("Cache-Control","public,max-age=30");
    res.sendFile(fp);
  }
});

// ── Logo proxy ────────────────────────────────────────────────────
app.get("/logo",(req,res)=>{
  const url=req.query.url;
  if(!url||!/^https?:\/\//i.test(url))return res.status(400).end();
  try {
    const p=new URL(url),lib=p.protocol==="https:"?https:http;
    const r=lib.request({hostname:p.hostname,port:p.port||(p.protocol==="https:"?443:80),path:p.pathname+p.search,method:"GET",headers:{"User-Agent":"Mozilla/5.0","Accept":"image/*,*/*"}},pr=>{
      res.setHeader("Content-Type",pr.headers["content-type"]||"image/png");
      res.setHeader("Cache-Control","public,max-age=86400");
      pr.pipe(res,{end:true});
    });
    r.on("error",()=>res.status(502).end());
    r.setTimeout(5000,()=>{r.destroy();res.status(504).end();});
    r.end();
  } catch(_){res.status(400).end();}
});

app.use(express.static(path.join(__dirname,"../static")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../static/index.html")));
process.on("SIGTERM",()=>{[...sessions.keys()].forEach(killSession);process.exit(0);});
app.listen(PORT,()=>console.log(`Stream :${PORT}  XC: ${XC_HOST}`));
