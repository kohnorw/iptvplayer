// build: 1778532664
"use strict";

const express              = require("express");
const path                 = require("path");
const fs                   = require("fs");
const http                 = require("http");
const https                = require("https");
const { spawn, spawnSync } = require("child_process");
const os                   = require("os");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
const XC_HOST  = (process.env.XC_HOST || "http://192.168.1.124:3000").replace(/\/+$/, "");
const HLS_DIR       = path.join(os.tmpdir(), "iptv-hls");
const DEFAULT_CMD   = path.join(__dirname, "ffmpeg-default.txt");
const CUSTOM_CMD    = path.join(DATA_DIR,  "ffmpeg-custom.txt");

// Read custom command if saved, otherwise use default
function readCustomCmd() {
  try { return fs.readFileSync(CUSTOM_CMD, "utf8"); } catch(_) {}
  try { return fs.readFileSync(DEFAULT_CMD, "utf8"); } catch(_) { return ""; }
}
let CFG_CUSTOM_CMD = null; // null = use built-in logic, string = use custom template

[DATA_DIR, HLS_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });
app.use(express.json({ limit: "10mb" }));

// ── Live config (updated by /api/settings) ────────────────────────
const UA_MAP = {
  chrome:   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
  vlc:      "VLC/3.0.20 LibVLC/3.0.20",
  tivimate: "TiviMate/4.7.0",
};

let CFG = {
  // General
  ua:              UA_MAP.chrome,
  // Buffering
  segSecs:         2,
  prebuf:          2,
  window:          60,
  idle:            20000,
  hlsBuf:          30,
  liveSync:        3,
  stallDelay:      10,
  // Safari
  safariTranscode: true,
  safariProfile:   "baseline",
  safariPreset:    "ultrafast",
  safariVbr:       0,
  // Audio
  forceAac:        false,
  audioBr:         192,
  audioSr:         48000,
  audioPrebuf:     4,
  aresample:       true,
  // FFmpeg
  ffmpegInput:     [],
  ffmpegExtra:     [],
  discardCorrupt:  true,
  genpts:          true,
};

// ── Per-user data ─────────────────────────────────────────────────
function userFile(u, type) {
  return path.join(DATA_DIR, `${type}_${u.replace(/[^a-zA-Z0-9_\-\.]/g, "_")}.json`);
}
function readUser(u, type, def) {
  try { return JSON.parse(fs.readFileSync(userFile(u, type), "utf8")); } catch (_) { return def; }
}
function writeUser(u, type, d) {
  fs.writeFileSync(userFile(u, type), JSON.stringify(d));
}

// ── XC API helpers ────────────────────────────────────────────────
async function xcFetch(url, ms = 15000) {
  return new Promise((resolve, reject) => {
    const p   = new URL(url);
    const lib = p.protocol === "https:" ? https : http;
    const req = lib.request({
      hostname: p.hostname,
      port:     p.port || (p.protocol === "https:" ? 443 : 80),
      path:     p.pathname + p.search,
      method:   "GET",
      headers:  { "User-Agent": "Mozilla/5.0" },
    }, res => {
      let body = "";
      res.on("data", c => body += c);
      res.on("end", () => {
        try { resolve(JSON.parse(body)); }
        catch (_) { reject(new Error(`Non-JSON HTTP ${res.statusCode}`)); }
      });
    });
    req.on("error", reject);
    req.setTimeout(ms, () => { req.destroy(); reject(new Error("Timeout")); });
    req.end();
  });
}

function buildXcUrl(username, password, action, extra = {}) {
  const url = new URL(`${XC_HOST}/player_api.php`);
  url.searchParams.set("username", username);
  url.searchParams.set("password", password);
  if (action) url.searchParams.set("action", action);
  for (const [k, v] of Object.entries(extra)) url.searchParams.set(k, v);
  return url.toString();
}

// ── Auth ──────────────────────────────────────────────────────────
app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "username and password required" });
  try {
    const d = await xcFetch(buildXcUrl(username, password, null));
    if (d.user_info && d.user_info.auth == 1) {
      res.json({
        ok: true,
        status:      d.user_info.status,
        expiry:      d.user_info.exp_date,
        connections: `${d.user_info.active_cons}/${d.user_info.max_connections}`,
      });
    } else {
      res.status(401).json({ error: "Invalid username or password" });
    }
  } catch (e) {
    res.status(502).json({ error: "Cannot reach server: " + e.message });
  }
});

// ── XC API proxy ──────────────────────────────────────────────────
const ALLOWED = new Set(["get_live_categories","get_live_streams","get_vod_categories","get_vod_streams","get_short_epg","get_epg"]);

app.get("/api/xc/:action", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  const { action } = req.params;
  if (!ALLOWED.has(action)) return res.status(403).json({ error: "Not allowed" });
  const extra = {};
  for (const [k, v] of Object.entries(req.query))
    if (k !== "username" && k !== "password") extra[k] = v;
  try { res.json(await xcFetch(buildXcUrl(username, password, action, extra))); }
  catch (e) { res.status(502).json({ error: e.message }); }
});

app.get("/api/epg/:streamId", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  try {
    res.json(await xcFetch(buildXcUrl(username, password, "get_short_epg", { stream_id: req.params.streamId, limit: 8 })));
  } catch (_) { res.json({ epg_listings: [] }); }
});

// ── Favourites + Prefs ────────────────────────────────────────────
app.get("/api/favs/:u",   (req, res) => res.json(readUser(req.params.u.trim(), "favs", [])));
app.post("/api/favs/:u",  (req, res) => { writeUser(req.params.u.trim(), "favs", Array.isArray(req.body) ? req.body : []); res.json({ ok: true }); });
app.get("/api/prefs/:u",  (req, res) => res.json(readUser(req.params.u.trim(), "prefs", { timezone: "America/Toronto" })));
app.post("/api/prefs/:u", (req, res) => { writeUser(req.params.u.trim(), "prefs", req.body || {}); res.json({ ok: true }); });

// ── Advanced settings ─────────────────────────────────────────────
app.post("/api/settings", (req, res) => {
  const s = req.body || {};
  const parseList = v => typeof v === "string" && v.trim() ? v.trim().split(/\s+/).filter(Boolean) : [];
  // General
  CFG.ua              = UA_MAP[s.ua] || UA_MAP.chrome;
  // Buffering
  CFG.segSecs         = Math.max(1, parseInt(s.segSecs)    || 2);
  CFG.prebuf          = Math.max(1, parseInt(s.prebuf)     || 2);
  CFG.window          = Math.max(5, parseInt(s.window)     || 60);
  CFG.idle            = Math.max(5, parseInt(s.idle)       || 20) * 1000;
  CFG.hlsBuf          = Math.max(5, parseInt(s.hlsBuf)     || 30);
  CFG.liveSync        = Math.max(1, parseInt(s.liveSync)   || 3);
  CFG.stallDelay      = Math.max(2, parseInt(s.stallDelay) || 10);
  // Safari
  CFG.safariTranscode = s.safariTranscode !== false && s.safariTranscode !== "false";
  CFG.safariProfile   = ["baseline","main","high"].includes(s.safariProfile) ? s.safariProfile : "baseline";
  CFG.safariPreset    = ["ultrafast","superfast","veryfast","faster"].includes(s.safariPreset) ? s.safariPreset : "ultrafast";
  CFG.safariVbr       = Math.max(0, parseInt(s.safariVbr)  || 0);
  // Audio
  CFG.forceAac        = !!s.forceAac;
  CFG.audioBr         = Math.max(64, parseInt(s.audioBr)   || 192);
  CFG.audioSr         = s.audioSr === "44100" ? 44100 : 48000;
  CFG.audioPrebuf     = Math.max(1, parseInt(s.audioPrebuf)|| 4);
  CFG.aresample       = s.aresample !== false && s.aresample !== "false";
  // FFmpeg
  CFG.ffmpegInput     = parseList(s.ffmpegInput);
  CFG.ffmpegExtra     = parseList(s.ffmpegExtra);
  CFG.discardCorrupt  = s.discardCorrupt !== false && s.discardCorrupt !== "false";
  CFG.genpts          = s.genpts !== false && s.genpts !== "false";
  console.log("[settings]", JSON.stringify(CFG));
  res.json({ ok: true, cfg: CFG });
});

// ── Stream probe ──────────────────────────────────────────────────
const probeCache = new Map(); // url → { hasVideo, hasAudio, audioCodec, ts }
const PROBE_TTL  = 3600000;   // 1 hour

function probeStream(url) {
  const hit = probeCache.get(url);
  if (hit && Date.now() - hit.ts < PROBE_TTL) return hit;

  // Dispatcharr uses probesize=1000000 analyzeduration=1500000 for live MPEG-TS
  const result = {
    hasVideo: true, hasAudio: false,
    videoCodec: "", audioCodec: "",
    pixFmt: "", audioChannels: 0,
    audioSampleRate: 0, audioProfile: "",
    interlaced: false, ts: Date.now(),
  };
  try {
    const r = spawnSync("ffprobe", [
      "-v", "error",
      "-user_agent", "Mozilla/5.0",
      "-probesize",       "1000000",
      "-analyzeduration", "1500000",
      "-show_entries",    "stream=codec_type,codec_name,pix_fmt,channels,sample_rate,profile,field_order",
      "-of", "json",
      url,
    ], { timeout: 10000, encoding: "utf8" });

    const data = JSON.parse(r.stdout || "{}");
    const streams = data.streams || [];
    const videoStream = streams.find(s => s.codec_type === "video");
    const audioStream = streams.find(s => s.codec_type === "audio");

    result.hasVideo        = !!videoStream;
    result.hasAudio        = !!audioStream;
    result.videoCodec      = videoStream ? (videoStream.codec_name  || "").toLowerCase() : "";
    result.pixFmt          = videoStream ? (videoStream.pix_fmt     || "").toLowerCase() : "";
    result.interlaced      = videoStream ? ["tt","bb","tb","bt"].includes((videoStream.field_order||"").toLowerCase()) : false;
    result.audioCodec      = audioStream ? (audioStream.codec_name  || "").toLowerCase() : "";
    result.audioChannels   = audioStream ? (audioStream.channels    || 0)  : 0;
    result.audioSampleRate = audioStream ? (parseInt(audioStream.sample_rate) || 0) : 0;
    result.audioProfile    = audioStream ? (audioStream.profile     || "")  : "";
    result.ts              = Date.now();
  } catch (_) { /* keep defaults */ }

  probeCache.set(url, result);
  return result;
}

// ── Session store ─────────────────────────────────────────────────
const sessions = new Map();

function segCount(dir) {
  try { return fs.readdirSync(dir).filter(f => f.endsWith(".ts")).length; } catch (_) { return 0; }
}

function killSession(sid) {
  const s = sessions.get(sid);
  if (!s) return;
  s.dead = true;
  clearTimeout(s.idleTimer);
  clearInterval(s.watchdog);
  try { s.ff.kill("SIGKILL"); } catch (_) {}
  try {
    if (fs.existsSync(s.dir)) {
      fs.readdirSync(s.dir).forEach(f => { try { fs.unlinkSync(path.join(s.dir, f)); } catch (_) {} });
      fs.rmdirSync(s.dir);
    }
  } catch (_) {}
  sessions.delete(sid);
}

function resetIdle(sid) {
  const s = sessions.get(sid);
  if (!s) return;
  clearTimeout(s.idleTimer);
  s.idleTimer = setTimeout(() => killSession(sid), CFG.idle);
}

// ── ffmpeg spawn ──────────────────────────────────────────────────
const UNSUPPORTED_AUDIO = ["ac3","eac3","mp2","dts","truehd","mlp","pcm"];

function buildFflags() {
  const flags = [];
  if (CFG.genpts)         flags.push("genpts");
  if (CFG.discardCorrupt) flags.push("discardcorrupt");
  return flags.length ? "+" + flags.join("+") : "+genpts+discardcorrupt";
}

// Parse shell-style ffmpeg command into args array
// Handles: backslash line continuations, quoted strings, # comments, {vars}
function parseCustomCmd(template, vars) {
  // Replace {variables}
  let cmd = template.replace(/\{(\w+)\}/g, (_, k) => vars[k] !== undefined ? vars[k] : "{"+k+"}");

  // Strip leading "ffmpeg" or "ffmpeg \" if present
  cmd = cmd.replace(/^\s*ffmpeg\s*(\\\s*)?\n?/, "");

  // Join backslash-continued lines
  cmd = cmd.replace(/\\\s*\n/g, " ");

  // Split into tokens respecting quoted strings
  const args = [];
  const re = /("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|\S+)/g;
  let match;
  while ((match = re.exec(cmd)) !== null) {
    let tok = match[1];
    if (tok.startsWith("#")) break; // comment to end of line — skip rest
    // Strip surrounding quotes
    if ((tok.startsWith('"') && tok.endsWith('"')) ||
        (tok.startsWith("'") && tok.endsWith("'"))) {
      tok = tok.slice(1, -1);
    }
    if (tok) args.push(tok);
  }
  return args;
}

// ── Dispatcharr-style smart codec decision ───────────────────────
// Mirrors build_hls_ffmpeg_cmd() software path from Dispatcharr/neTV
function decideCopy(probe) {
  // Copy video only if H.264 yuv420p — guaranteed browser-safe
  const copyVideo = probe.hasVideo
    && probe.videoCodec === "h264"
    && probe.pixFmt === "yuv420p"
    && !probe.interlaced;

  // Copy audio only if AAC stereo/mono, standard sample rate, NOT HE-AAC
  // (Dispatcharr: "HE-AAC has browser compatibility issues - only copy LC-AAC")
  const copyAudio = probe.hasAudio
    && probe.audioCodec === "aac"
    && probe.audioChannels <= 2
    && [44100, 48000].includes(probe.audioSampleRate)
    && !(probe.audioProfile || "").includes("HE");

  return { copyVideo, copyAudio };
}

function spawnFfmpeg(xcUrl, safari, audioOnly, dir, m3u8, startNum) {
  // If custom command is enabled, use it
  if (CFG_CUSTOM_CMD) {
    const vars = {
      STREAM_URL:   xcUrl,
      ua:           CFG.ua,
      audioBr:      CFG.audioBr+"k",
      audioSr:      String(CFG.audioSr),
      safariProfile:CFG.safariProfile,
      safariPreset: CFG.safariPreset,
      segSecs:      String(CFG.segSecs),
      window:       String(CFG.window),
    };

    let args = parseCustomCmd(CFG_CUSTOM_CMD, vars);

    // Replace placeholder paths with real paths
    args = args.map(a => {
      if (a === "./seg%06d.ts" || a.endsWith("/seg%06d.ts")) return path.join(dir, "seg%06d.ts");
      if (a === "./index.m3u8" || a === "index.m3u8") return m3u8;
      if (a === "<STREAM_URL>") return xcUrl;
      return a;
    });

    // Inject -start_number before the m3u8 output if not present
    if (!args.includes("-start_number") && startNum) {
      const m3uIdx = args.lastIndexOf(m3u8);
      if (m3uIdx > -1) args.splice(m3uIdx, 0, "-start_number", String(startNum));
    }

    // Ensure hls_segment_filename uses full path
    const segIdx = args.indexOf("-hls_segment_filename");
    if (segIdx > -1 && args[segIdx+1] && !path.isAbsolute(args[segIdx+1])) {
      args[segIdx+1] = path.join(dir, "seg%06d.ts");
    }

    console.log("[ff custom]", args.slice(0,6).join(" ")+"…");
    return spawn("ffmpeg", args);
  }

  // Built-in logic — Dispatcharr software path (smart copy/transcode)
  // audioOnly is passed as parameter from caller
  const { copyVideo, copyAudio } = decideCopy(probe);

  let codecArgs;
  if (safari && CFG.safariTranscode) {
    // Safari: full transcode — H.264 Baseline + AAC LC
    const vbrArgs = CFG.safariVbr > 0 ? ["-b:v", CFG.safariVbr+"k"] : [];
    codecArgs = [
      "-map", "0:v?", "-map", "0:a?",
      "-c:v", "libx264",
      "-profile:v", CFG.safariProfile,
      "-level",     CFG.safariProfile === "baseline" ? "3.1" : "4.0",
      "-preset",    CFG.safariPreset, "-tune", "zerolatency",
      ...vbrArgs,
      "-c:a", "aac", "-ac", "2", "-ar", String(CFG.audioSr),
      "-b:a", CFG.audioBr+"k", "-profile:a", "aac_low",
      ...(CFG.aresample ? ["-af", "aresample=async=1:first_pts=0"] : []),
    ];
  } else if (audioOnly) {
    // Audio-only: Dispatcharr uses aac_low profile + aresample for timing gaps
    const af = CFG.aresample ? ["-af", "aresample=async=1:first_pts=0"] : [];
    codecArgs = [
      "-vn", "-map", "0:a:0",
      "-c:a", "aac", "-ac", "2",
      "-ar", String(CFG.audioSr),
      "-b:a", CFG.audioBr+"k",
      "-profile:a", "aac_low",
      ...af,
    ];
  } else {
    // Video stream — Dispatcharr smart copy:
    // copy if already H.264/yuv420p (no re-encode needed)
    // copy audio if already LC-AAC stereo at standard sample rate
    const vArgs = copyVideo
      ? ["-c:v", "copy"]
      : ["-c:v", "libx264", "-preset", "veryfast", "-crf", "26",
         "-profile:v", "high", "-level", "4.1"];
    const aArgs = (copyAudio && !CFG.forceAac)
      ? ["-c:a", "copy"]
      : ["-c:a", "aac", "-ac", "2", "-ar", String(CFG.audioSr),
         "-b:a", CFG.audioBr+"k", "-profile:a", "aac_low"];
    codecArgs = ["-map", "0:v:0", "-map", "0:a:0", ...vArgs, ...aArgs];
  }

  const mode = audioOnly ? "audio-only"
    : (safari ? "safari-transcode"
    : (copyVideo && (copyAudio && !CFG.forceAac) ? "copy"
    : copyVideo ? "copy-v/transcode-a"
    : "transcode"));
  console.log("[ff] mode=" + mode);

  const prebuf = audioOnly ? CFG.audioPrebuf : CFG.prebuf;

  // Dispatcharr input flags: reconnect + err_detect for live streams
  const reconnectArgs = [
    "-err_detect",         "ignore_err",
    "-reconnect",          "1",
    "-reconnect_streamed", "1",
    "-reconnect_on_network_error", "1",
    "-reconnect_on_http_error",    "4xx,5xx",
    "-reconnect_delay_max","30",
  ];

  return spawn("ffmpeg", [
    "-loglevel",   "error",
    ...reconnectArgs,
    ...CFG.ffmpegInput,
    "-user_agent", CFG.ua,
    // Dispatcharr: larger probe buffers for MPEG-TS live streams
    "-probesize",       "1000000",
    "-analyzeduration", "1500000",
    "-fflags",     buildFflags(),
    "-i",          xcUrl,
    ...codecArgs,
    ...CFG.ffmpegExtra,
    "-f",          "hls",
    "-hls_time",   String(CFG.segSecs),
    "-hls_list_size", String(CFG.window),
    "-hls_flags",  "delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_segment_type", "mpegts",
    "-hls_segment_filename", path.join(dir, "seg%06d.ts"),
    "-start_number", String(startNum || 0),
    m3u8,
  ]);
}

// ── Start stream ──────────────────────────────────────────────────
app.post("/api/stream/start", (req, res) => {
  const { username, password, streamId, sessionId: oldSid, safari } = req.body || {};
  if (!username || !password || !streamId)
    return res.status(400).json({ error: "Missing params" });

  if (oldSid) killSession(oldSid);

  const sid  = Date.now().toString(36) + Math.random().toString(36).slice(2);
  const dir  = path.join(HLS_DIR, sid);
  const m3u8 = path.join(dir, "index.m3u8");
  fs.mkdirSync(dir, { recursive: true });

  const urlTs   = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.ts`;
  const urlM3u8 = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.m3u8`;

  let probe = probeStream(urlTs);
  let xcUrl;
  if (!probe.hasVideo && !probe.hasAudio) {
    // .ts failed — try .m3u8
    probe = probeStream(urlM3u8); xcUrl = urlM3u8;
  } else if (!probe.hasVideo) {
    // Audio-only: try .ts first, fall back to .m3u8 if .ts fails
    // Custom command handles both via -allowed_extensions + -protocol_whitelist
    xcUrl = urlTs;
  } else {
    xcUrl = urlTs;
  }

  const audioOnly       = probe.hasAudio && !probe.hasVideo;
  const effectivePrebuf = audioOnly ? CFG.audioPrebuf : CFG.prebuf;
  const modeStr         = CFG_CUSTOM_CMD ? "[custom cmd]" : "built-in";
  console.log(`[stream] ${sid.slice(0,8)} → ${streamId}  url=${xcUrl.split("/").pop()}  audio="${probe.audioCodec||"?"}"  ${modeStr}${safari?" [safari]":""}${audioOnly?" [audio-only]":""}`);

  const IGNORE_RE = /frame size not set|PES packet|Packet corrupt|non monotonous|non-existing SPS|non-existing PPS|no frame!|Could not find ref|Error constructing|Error submitting packet|decode_band_types|exhausted before END|Invalid data found|Error opening input/i;

  let ff = spawnFfmpeg(xcUrl, safari, audioOnly, dir, m3u8, 0);

  ff.stderr.on("data", d => {
    const m = d.toString().trim();
    if (m && !IGNORE_RE.test(m)) console.error(`[ff:${sid.slice(0,8)}]`, m);
  });

  // For audio-only custom commands: if .ts fails immediately, retry with .m3u8
  let audioFallbackUrl = xcUrl;
  let audioFallbackTried = false;

  const handleClose = () => {
    const s = sessions.get(sid);
    if (!s || s.dead) return;
    const next = segCount(dir);
    // If audio-only, no segments written yet, and haven't tried .m3u8 yet — switch URL
    if (audioOnly && next === 0 && !audioFallbackTried && audioFallbackUrl === urlTs) {
      audioFallbackTried = true;
      audioFallbackUrl = urlM3u8;
      console.log(`[stream] ${sid.slice(0,8)} .ts failed, retrying with .m3u8`);
    }
    ff = spawnFfmpeg(audioFallbackUrl, safari, audioOnly, dir, m3u8, next);
    ff.stderr.on("data", d => { const m = d.toString().trim(); if (m && !IGNORE_RE.test(m)) console.error(`[ff:${sid.slice(0,8)}]`, m); });
    ff.on("close", handleClose);
    s.ff = ff;
  };
  ff.on("close", handleClose);
  ff.on("error", err => console.error("[ff] spawn:", err.message));

  // Watchdog — restart if segments stall
  let lastSeg = 0, lastTime = Date.now(), watchdogActive = false;
  const watchdog = setInterval(() => {
    const s = sessions.get(sid);
    if (!s || s.dead) { clearInterval(watchdog); return; }
    const n = segCount(dir);
    if (n > lastSeg) {
      lastSeg = n; lastTime = Date.now();
      if (n >= effectivePrebuf) watchdogActive = true;
    } else if (watchdogActive && Date.now() - lastTime > 10000) {
      lastTime = Date.now();
      try { s.ff.kill("SIGKILL"); } catch (_) {}
    }
  }, 2000);

  const idleTimer = setTimeout(() => killSession(sid), CFG.idle);
  sessions.set(sid, { ff, dir, idleTimer, watchdog, dead: false });

  // Poll until pre-buffer is ready
  const t0 = Date.now();
  const poll = setInterval(() => {
    if (!sessions.has(sid)) {
      clearInterval(poll);
      if (!res.headersSent) res.status(502).json({ error: "Stream failed" });
      return;
    }
    if (segCount(dir) >= effectivePrebuf && fs.existsSync(m3u8) && fs.statSync(m3u8).size > 0) {
      clearInterval(poll);
      console.log(`[stream] ${sid.slice(0,8)} ready`);
      res.json({ ok: true, sessionId: sid, url: `/hls/${sid}/index.m3u8`, audioOnly, hlsCfg: { maxBufferLength: CFG.hlsBuf, liveSyncDurationCount: CFG.liveSync, maxStarvationDelay: CFG.stallDelay } });
    } else if (Date.now() - t0 > 25000) {
      clearInterval(poll);
      killSession(sid);
      if (!res.headersSent) res.status(504).json({ error: "Stream timed out" });
    }
  }, 300);
});

// ── Current ffmpeg command preview ───────────────────────────────
app.get("/api/ffcmd", (req, res) => {
  const needsTranscode = CFG.forceAac; // show both variants if not forced
  const cmd = [
    "ffmpeg",
    "-loglevel",   "error",
    "-user_agent", `"${CFG.ua}"`,
    "-i",          "<stream_url>",
    "-map",        "0:v?",
    "-map",        "0:a?",
    "-c:v",        "copy",
    "-c:a",        needsTranscode ? "aac" : "copy",
    ...(needsTranscode ? ["-b:a","192k","-ar","48000","-ac","2"] : []),
    "-fflags",     "+genpts+discardcorrupt",
    ...CFG.ffmpegExtra,
    "-f",          "hls",
    "-hls_time",   String(CFG.segSecs),
    "-hls_list_size", String(CFG.window),
    "-hls_flags",  "delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_segment_type", "mpegts",
    "-hls_segment_filename", "<dir>/seg%06d.ts",
    "-start_number","0",
    "<dir>/index.m3u8",
  ];
  res.json({ cmd, cmdStr: cmd.join(" "), cfg: CFG });
});

app.post("/api/stream/heartbeat/:sid", (req, res) => {
  if (!sessions.has(req.params.sid)) return res.status(404).json({ error: "Session gone" });
  resetIdle(req.params.sid);
  res.json({ ok: true });
});

app.post("/api/stream/stop/:sid", (req, res) => {
  killSession(req.params.sid);
  res.json({ ok: true });
});

// ── HLS file serving ──────────────────────────────────────────────
app.get("/hls/:sid/:file", (req, res) => {
  const { sid, file } = req.params;
  const fp = path.join(HLS_DIR, sid, file);
  if (!fs.existsSync(fp)) return res.status(404).send("Not found");
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (file.endsWith(".m3u8")) {
    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    // Safari requires no-cache (not no-store) to reload playlist correctly
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Pragma", "no-cache");
    try {
      const raw = fs.readFileSync(fp, "utf8");
      const out = raw.split("\n").map(l => {
        const t = l.trim();
        return (t && !t.startsWith("#") && t.endsWith(".ts")) ? `/hls/${sid}/${t}` : l;
      }).join("\n");
      res.send(out);
    } catch (_) { res.status(500).end(); }
  } else {
    res.setHeader("Content-Type", "video/mp2t");
    // Safari is strict about segment caching — allow short cache
    res.setHeader("Cache-Control", "public,max-age=5");
    // Safari needs explicit content-length for segments
    try {
      const stat = fs.statSync(fp);
      res.setHeader("Content-Length", stat.size);
    } catch(_) {}
    res.sendFile(fp);
  }
});

// ── Logo proxy ────────────────────────────────────────────────────
app.get("/logo", async (req, res) => {
  const url = req.query.url;
  if (!url || !/^https?:\/\//i.test(url)) return res.status(400).end();
  try {
    const p = new URL(url);
    const lib = p.protocol === "https:" ? https : http;
    const preq = lib.request({
      hostname: p.hostname,
      port:     p.port || (p.protocol === "https:" ? 443 : 80),
      path:     p.pathname + p.search,
      method:   "GET",
      headers:  { "User-Agent": "Mozilla/5.0", "Referer": p.origin, "Accept": "image/*,*/*" },
    }, pres => {
      res.setHeader("Content-Type", pres.headers["content-type"] || "image/png");
      res.setHeader("Cache-Control", "public,max-age=86400");
      res.setHeader("Access-Control-Allow-Origin", "*");
      pres.pipe(res, { end: true });
    });
    preq.on("error", () => res.status(502).end());
    preq.setTimeout(5000, () => { preq.destroy(); res.status(504).end(); });
    preq.end();
  } catch (_) { res.status(400).end(); }
});

// ── Custom ffmpeg command ─────────────────────────────────────────
app.get("/api/ffcmd/custom", (req, res) => {
  const current = readCustomCmd();
  const isCustom = !!CFG_CUSTOM_CMD;
  try {
    const defaultTxt = fs.readFileSync(DEFAULT_CMD, "utf8");
    res.json({ current, default: defaultTxt, isCustom });
  } catch(_) {
    res.json({ current, default: current, isCustom });
  }
});

app.post("/api/ffcmd/custom", (req, res) => {
  const { cmd, enabled } = req.body || {};
  if (typeof cmd === "string") {
    fs.writeFileSync(CUSTOM_CMD, cmd);
    CFG_CUSTOM_CMD = enabled !== false ? cmd : null;
  } else {
    CFG_CUSTOM_CMD = enabled !== false ? readCustomCmd() : null;
  }
  res.json({ ok: true, enabled: !!CFG_CUSTOM_CMD });
});

app.post("/api/ffcmd/reset", (req, res) => {
  try { fs.unlinkSync(CUSTOM_CMD); } catch(_) {}
  CFG_CUSTOM_CMD = null;
  res.json({ ok: true, default: fs.readFileSync(DEFAULT_CMD, "utf8") });
});

// ── Static + SPA ──────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, "../static")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../static/index.html")));

process.on("SIGTERM", () => { sessions.forEach((_, sid) => killSession(sid)); process.exit(0); });
app.listen(PORT, () => console.log(`Stream :${PORT}  XC: ${XC_HOST}`));
