"use strict";

const express  = require("express");
const path     = require("path");
const fs       = require("fs");
const { spawn } = require("child_process");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const FAVOURITES_FILE = path.join(DATA_DIR, "favourites.json");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "../static")));

function load(f)    { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch(_){ return null; } }
function save(f, d) { fs.writeFileSync(f, JSON.stringify(d)); }

// ── Favourites (only persistent data — no credentials) ────────────
app.get("/api/favourites",  (req, res) => res.json(load(FAVOURITES_FILE) || []));
app.post("/api/favourites", (req, res) => { save(FAVOURITES_FILE, req.body); res.json({ ok: true }); });

// ── FFmpeg stream proxy ───────────────────────────────────────────
// Accepts the full XC stream URL as a query param, transcodes to HLS-compatible
// fMP4/MPEG-TS and pipes directly to the browser via chunked transfer.
// This lets Chrome play any stream format the provider sends.
app.get("/proxy/stream", (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).send("Missing url param");

  // Basic URL validation — must be http/https
  if (!/^https?:\/\//i.test(url)) return res.status(400).send("Invalid URL");

  console.log("FFmpeg proxying:", url.replace(/\/[^/]+\/[^/]+\/(\d+)/, "/***/***/***"));

  res.setHeader("Content-Type", "video/mp2t");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Access-Control-Allow-Origin", "*");

  const ff = spawn("ffmpeg", [
    "-loglevel", "error",
    "-re",
    "-user_agent", "Mozilla/5.0",
    "-i", url,
    "-c", "copy",
    "-f", "mpegts",
    "pipe:1",
  ]);

  ff.stdout.pipe(res, { end: true });

  ff.stderr.on("data", d => {
    const msg = d.toString();
    if (!msg.includes("fps")) console.error("FFmpeg:", msg.trim());
  });

  ff.on("error", err => {
    console.error("FFmpeg spawn error:", err.message);
    if (!res.headersSent) res.status(502).send("FFmpeg error: " + err.message);
  });

  ff.on("close", code => {
    if (code !== 0 && code !== null) console.log("FFmpeg exited:", code);
    if (!res.writableEnded) res.end();
  });

  // Kill ffmpeg if client disconnects
  req.on("close", () => {
    ff.kill("SIGKILL");
  });
});

// ── SPA ───────────────────────────────────────────────────────────
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../static/index.html")));

app.listen(PORT, () => console.log(`IPTV Player on :${PORT}`));
