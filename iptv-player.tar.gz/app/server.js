"use strict";

const express            = require("express");
const path               = require("path");
const fs                 = require("fs");
const http               = require("http");
const https              = require("https");
const { spawn, spawnSync } = require("child_process");
const os                 = require("os");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
const XC_HOST  = (process.env.XC_HOST || "http://192.168.1.124:3000").replace(/\/+$/, "");
const HLS_DIR  = path.join(os.tmpdir(), "iptv-hls");

[DATA_DIR, HLS_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

app.use(express.json({ limit: "10mb" }));

// ── Buffer tuning ─────────────────────────────────────────────────
const SEG_SECS     = 2;    // seconds per HLS segment
const PREBUF_SEGS  = 10;   // wait for 10 segments (~20s) before playback starts
const WINDOW_SEGS  = 20;   // rolling playlist window (20 segments = 40s on disk)
const IDLE_MS      = 25000; // kill session after 25s no heartbeat

// ── Favourites ────────────────────────────────────────────────────
function favFile(u) {
  return path.join(DATA_DIR, `favs_${u.replace(/[^a-zA-Z0-9_\-\.]/g,"_")}.json`);
}
function getFavs(u)    { try { return JSON.parse(fs.readFileSync(favFile(u),"utf8")); } catch(_){ return []; } }
function setFavs(u, d) { fs.writeFileSync(favFile(u), JSON.stringify(d)); }

// ── XC fetch ──────────────────────────────────────────────────────
async function xcFetch(url, ms=15000) {
  return new Promise((resolve, reject) => {
    const p   = new URL(url);
    const lib = p.protocol==="https:" ? https : http;
    const req = lib.request({
      hostname: p.hostname,
      port:     p.port||(p.protocol==="https:"?443:80),
      path:     p.pathname+p.search,
      method:   "GET",
      headers:  {"User-Agent":"Mozilla/5.0"},
    }, res => {
      let body = "";
      res.on("data", c => body+=c);
      res.on("end", () => {
        try   { resolve(JSON.parse(body)); }
        catch (_) { reject(new Error(`Non-JSON HTTP ${res.statusCode}: ${body.slice(0,80)}`)); }
      });
    });
    req.on("error", reject);
    req.setTimeout(ms, () => { req.destroy(); reject(new Error("Timeout")); });
    req.end();
  });
}

function buildXcUrl(u, p, action, extra={}) {
  const url = new URL(`${XC_HOST}/player_api.php`);
  url.searchParams.set("username", u);
  url.searchParams.set("password", p);
  if (action) url.searchParams.set("action", action);
  for (const [k,v] of Object.entries(extra)) url.searchParams.set(k,v);
  return url.toString();
}

// ── Auth ──────────────────────────────────────────────────────────
app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "username and password required" });
  try {
    const d = await xcFetch(buildXcUrl(username, password, null));
    if (d.user_info && d.user_info.auth == 1) {
      res.json({ ok:true, status:d.user_info.status, expiry:d.user_info.exp_date,
        connections:`${d.user_info.active_cons}/${d.user_info.max_connections}` });
    } else {
      res.status(401).json({ error: "Invalid username or password" });
    }
  } catch(e) { res.status(502).json({ error: "Cannot reach server: "+e.message }); }
});

// ── XC API ────────────────────────────────────────────────────────
const ALLOWED = new Set(["get_live_categories","get_live_streams","get_vod_categories",
  "get_vod_streams","get_short_epg","get_epg"]);

app.get("/api/xc/:action", async (req, res) => {
  const { username, password } = req.query;
  if (!username||!password) return res.status(401).json({ error:"Missing credentials" });
  const { action } = req.params;
  if (!ALLOWED.has(action)) return res.status(403).json({ error:"Not allowed" });
  const extra = {};
  for (const [k,v] of Object.entries(req.query)) if (k!=="username"&&k!=="password") extra[k]=v;
  try { res.json(await xcFetch(buildXcUrl(username,password,action,extra))); }
  catch(e) { res.status(502).json({ error:e.message }); }
});

app.get("/api/epg/:streamId", async (req, res) => {
  const { username, password } = req.query;
  if (!username||!password) return res.status(401).json({ error:"Missing credentials" });
  try { res.json(await xcFetch(buildXcUrl(username,password,"get_short_epg",{stream_id:req.params.streamId,limit:8}))); }
  catch(_) { res.json({ epg_listings:[] }); }
});

// ── Favourites routes ─────────────────────────────────────────────
app.get("/api/favs/:username", (req, res) => {
  const u = req.params.username.trim();
  const favs = getFavs(u);
  console.log(`[favs] GET "${u}" → ${favs.length} items`);
  res.json(favs);
});

app.post("/api/favs/:username", (req, res) => {
  const u = req.params.username.trim();
  const d = Array.isArray(req.body) ? req.body : [];
  setFavs(u, d);
  console.log(`[favs] POST "${u}" → ${d.length} items`);
  res.json({ ok:true });
});

// ── Audio codec detection ─────────────────────────────────────────
function detectAudioCodec(streamUrl) {
  try {
    const r = spawnSync("ffprobe", [
      "-v","error",
      "-user_agent","Mozilla/5.0",
      "-select_streams","a:0",
      "-show_entries","stream=codec_name",
      "-of","default=noprint_wrappers=1:nokey=1",
      streamUrl,
    ], { timeout:8000, encoding:"utf8" });
    return (r.stdout||"").trim().toLowerCase();
  } catch(_) { return ""; }
}

// ── Session store ─────────────────────────────────────────────────
const sessions = new Map();

function killSession(sid) {
  const s = sessions.get(sid);
  if (!s) return;
  clearTimeout(s.idleTimer);
  s.dead = true;
  try { s.ff.kill("SIGKILL"); } catch(_) {}
  try {
    if (fs.existsSync(s.dir)) {
      fs.readdirSync(s.dir).forEach(f => { try { fs.unlinkSync(path.join(s.dir,f)); } catch(_){} });
      fs.rmdirSync(s.dir);
    }
  } catch(_) {}
  sessions.delete(sid);
  console.log(`[stream] ${sid.slice(0,8)} killed`);
}

function resetIdle(sid) {
  const s = sessions.get(sid);
  if (!s) return;
  clearTimeout(s.idleTimer);
  s.idleTimer = setTimeout(() => killSession(sid), IDLE_MS);
}

function segCount(dir) {
  try { return fs.readdirSync(dir).filter(f=>f.endsWith(".ts")).length; }
  catch(_) { return 0; }
}

// ── Start stream ──────────────────────────────────────────────────
app.post("/api/stream/start", async (req, res) => {
  const { username, password, streamId, sessionId:old } = req.body || {};
  if (!username||!password||!streamId) return res.status(400).json({ error:"Missing params" });

  if (old) killSession(old);

  const sid  = Date.now().toString(36) + Math.random().toString(36).slice(2);
  const dir  = path.join(HLS_DIR, sid);
  const m3u8 = path.join(dir, "index.m3u8");
  fs.mkdirSync(dir, { recursive:true });

  const xcM3u8 = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.ts`;

  // Detect audio codec
  console.log(`[stream] ${sid.slice(0,8)} probing audio for stream ${streamId}…`);
  const detected      = detectAudioCodec(xcM3u8);
  const UNSUPPORTED   = ["ac3","eac3","mp2","dts","truehd","mlp","pcm"];
  const needsTranscode = UNSUPPORTED.some(c => detected.includes(c));
  const audioCodec    = needsTranscode ? "aac" : "copy";
  console.log(`[stream] ${sid.slice(0,8)} audio="${detected||"unknown"}" codec=${audioCodec}`);

  const ff = spawn("ffmpeg", [
    "-loglevel",          "warning",
    "-user_agent",        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    // Generous probe so ffmpeg starts cleanly
    "-analyzeduration",   "3000000",
    "-probesize",         "3000000",
    // Input flags — no buffering at the read level, generate pts if missing
    "-fflags",            "+nobuffer+discardcorrupt+genpts",
    "-i",                 xcM3u8,
    // Map first video + first audio only
    "-map",               "0:v:0",
    "-map",               "0:a:0",
    "-c:v",               "copy",
    "-c:a",               audioCodec,
    ...(needsTranscode ? ["-b:a","192k","-ar","48000","-ac","2"] : []),
    // Output as HLS
    "-f",                 "hls",
    "-hls_time",          String(SEG_SECS),
    // Large rolling window — lots of segments on disk at all times
    "-hls_list_size",     String(WINDOW_SEGS),
    "-hls_flags",         "delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_segment_type",  "mpegts",
    "-hls_segment_filename", path.join(dir, "seg%06d.ts"),
    "-start_number",      "0",
    m3u8,
  ]);

  ff.stderr.on("data", d => {
    const m = d.toString().trim();
    if (m && !m.includes("Last message repeated")) console.error(`[ff:${sid.slice(0,8)}]`, m);
  });
  ff.on("error", err => console.error(`[ff] spawn:`, err.message));
  ff.on("close", code => { console.log(`[ff:${sid.slice(0,8)}] exit ${code}`); const s=sessions.get(sid); if(s){clearTimeout(s.idleTimer);} sessions.delete(sid); });

  const idleTimer = setTimeout(() => killSession(sid), IDLE_MS);
  sessions.set(sid, { ff, dir, idleTimer, dead:false });

  // Wait for PREBUF_SEGS segments before handing URL to browser
  // This ensures the browser always starts with a full buffer
  console.log(`[stream] ${sid.slice(0,8)} waiting for ${PREBUF_SEGS} segments (~${PREBUF_SEGS*SEG_SECS}s buffer)…`);
  const t0   = Date.now();
  const poll = setInterval(() => {
    const s = sessions.get(sid);
    if (!s || s.dead) { clearInterval(poll); return; }

    const segs = segCount(dir);
    const ready = fs.existsSync(m3u8) && fs.statSync(m3u8).size > 0 && segs >= PREBUF_SEGS;

    // If ffmpeg died, session is gone — bail immediately
    if (!sessions.has(sid)) {
      clearInterval(poll);
      if (!res.headersSent) res.status(502).json({ error:"Stream failed — channel may not be available" });
      return;
    }
    if (ready) {
      clearInterval(poll);
      console.log(`[stream] ${sid.slice(0,8)} ready — ${segs} segs buffered (${segs*SEG_SECS}s)`);
      res.json({ ok:true, sessionId:sid, url:`/hls/${sid}/index.m3u8` });
    } else if (Date.now()-t0 > 25000) {
      clearInterval(poll);
      killSession(sid);
      if (!res.headersSent) res.status(504).json({ error:"Stream timed out — try another channel" });
    } else {
      if (segs > 0 && segs % 3 === 0) {
        console.log(`[stream] ${sid.slice(0,8)} buffering… ${segs}/${PREBUF_SEGS} segs`);
      }
    }
  }, 300);
});

// ── Heartbeat + stop ──────────────────────────────────────────────
app.post("/api/stream/heartbeat/:sid", (req, res) => {
  if (!sessions.has(req.params.sid)) return res.status(404).json({ error:"Session gone" });
  resetIdle(req.params.sid);
  res.json({ ok:true });
});

app.post("/api/stream/stop/:sid", (req, res) => {
  killSession(req.params.sid);
  res.json({ ok:true });
});

// ── HLS file serving — no cache, proper MIME ──────────────────────
app.get("/hls/:sid/:file", (req, res) => {
  const fp = path.join(HLS_DIR, req.params.sid, req.params.file);
  if (!fs.existsSync(fp)) return res.status(404).send("Not found");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  if (req.params.file.endsWith(".m3u8")) {
    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
  } else {
    res.setHeader("Content-Type", "video/mp2t");
  }
  res.sendFile(fp);
});

// ── Static + SPA (must be last) ───────────────────────────────────
app.use(express.static(path.join(__dirname, "../static")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../static/index.html")));

process.on("SIGTERM", () => { sessions.forEach((_,sid) => killSession(sid)); process.exit(0); });
app.listen(PORT, () => console.log(`IPTV Player :${PORT}  XC: ${XC_HOST}  prebuf: ${PREBUF_SEGS*SEG_SECS}s`));
