"use strict";
const express = require("express");
const path = require("path");
const fs = require("fs");
const http = require("http");
const https = require("https");
const { spawn, spawnSync } = require("child_process");
const os = require("os");

const app = express();
const PORT = process.env.PORT || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
const XC_HOST = (process.env.XC_HOST || "http://192.168.1.124:3000").replace(/\/+$/, "");
const HLS_DIR = path.join(os.tmpdir(), "iptv-hls");

[DATA_DIR, HLS_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });
app.use(express.json({ limit: "10mb" }));

// ── Config ────────────────────────────────────────────────────────
const UA = {
  chrome: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
  vlc: "VLC/3.0.20 LibVLC/3.0.20",
  tivimate: "TiviMate/4.7.0",
};
let C = {
  ua: UA.chrome,
  segSecs: 2, prebuf: 2, window: 60, idle: 20000,
  stallRestart: 10000, maxRestarts: 5,
  hlsBuf: 30, backBuf: 0, liveSync: 6, stallDelay: 8, snapLive: true,
  safariTranscode: true, safariProfile: "baseline", safariPreset: "ultrafast", safariVbr: 0,
  forceAac: false, audioBr: 192, audioSr: 48000, audioPrebuf: 4, aresample: true,
  ffmpegInput: [], probeSize: 1000000, analyzeDur: 1500000, threadQueue: 8192,
  ffmpegExtra: [], discardCorrupt: true, genpts: true, ignoreErr: false, noBuffer: false,
  reconnect: true, reconnectNet: true, reconnectDelay: 5, rwTimeout: 15000000,
};

// ── Helpers ───────────────────────────────────────────────────────
const ufile = (u, t) => path.join(DATA_DIR, t + "_" + u.replace(/[^a-zA-Z0-9_\-.]/g, "_") + ".json");
const ruser = (u, t, d) => { try { return JSON.parse(fs.readFileSync(ufile(u, t), "utf8")); } catch (_) { return d; } };
const wuser = (u, t, d) => fs.writeFileSync(ufile(u, t), JSON.stringify(d));

async function xfetch(url, ms = 15000) {
  return new Promise((resolve, reject) => {
    const p = new URL(url), lib = p.protocol === "https:" ? https : http;
    const req = lib.request({ hostname: p.hostname, port: p.port || (p.protocol === "https:" ? 443 : 80), path: p.pathname + p.search, method: "GET", headers: { "User-Agent": "Mozilla/5.0" } }, res => {
      let b = ""; res.on("data", c => b += c); res.on("end", () => { try { resolve(JSON.parse(b)); } catch (_) { reject(new Error("Non-JSON")); } });
    });
    req.on("error", reject); req.setTimeout(ms, () => { req.destroy(); reject(new Error("Timeout")); }); req.end();
  });
}

function xurl(u, p, action, extra = {}) {
  const url = new URL(XC_HOST + "/player_api.php");
  url.searchParams.set("username", u); url.searchParams.set("password", p);
  if (action) url.searchParams.set("action", action);
  Object.entries(extra).forEach(([k, v]) => url.searchParams.set(k, v));
  return url.toString();
}

function fflags() {
  const f = [];
  if (C.genpts) f.push("genpts");
  if (C.discardCorrupt) f.push("discardcorrupt");
  if (C.noBuffer) f.push("nobuffer");
  return f.length ? "+" + f.join("+") : "+genpts";
}

function inputArgs() {
  const a = [];
  if (C.reconnect) a.push("-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", String(C.reconnectDelay));
  if (C.reconnectNet) a.push("-reconnect_on_network_error", "1");
  if (C.rwTimeout > 0) a.push("-rw_timeout", String(C.rwTimeout));
  if (C.ignoreErr) a.push("-err_detect", "ignore_err");
  a.push("-probesize", String(C.probeSize), "-analyzeduration", String(C.analyzeDur), "-thread_queue_size", String(C.threadQueue));
  return a;
}

function hlsArgs(dir, m3u8, n) {
  return ["-f", "hls", "-hls_time", String(C.segSecs), "-hls_list_size", String(C.window),
    "-hls_flags", "delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_segment_type", "mpegts", "-hls_segment_filename", path.join(dir, "seg%06d.ts"),
    "-start_number", String(n || 0), m3u8];
}

// ── Custom command ────────────────────────────────────────────────
const DEF_CMD = path.join(__dirname, "ffmpeg-default.txt");
const CUS_CMD = path.join(DATA_DIR, "ffmpeg-custom.txt");
let CUSTOM = null;

function readCmd() { try { return fs.readFileSync(CUS_CMD, "utf8"); } catch (_) { } try { return fs.readFileSync(DEF_CMD, "utf8"); } catch (_) { return ""; } }

function parseCmd(tmpl, vars) {
  let cmd = tmpl.replace(/\{(\w+)\}/g, (_, k) => vars[k] !== undefined ? vars[k] : "{" + k + "}");
  cmd = cmd.replace(/^\s*ffmpeg\s*/, "");
  const lines = cmd.split("\n"); const joined = [];
  for (const line of lines) { if (line.trimEnd().endsWith("\\")) joined.push(line.trimEnd().slice(0, -1) + " "); else joined.push(line + " "); }
  cmd = joined.join("").trim();
  const args = []; let pos = 0;
  while (pos < cmd.length) {
    while (pos < cmd.length && cmd[pos] === " ") pos++;
    if (pos >= cmd.length) break;
    if (cmd[pos] === "#") break;
    if (cmd[pos] === '"') { const e = cmd.indexOf('"', pos + 1); args.push(cmd.slice(pos + 1, e === -1 ? cmd.length : e)); pos = (e === -1 ? cmd.length : e) + 1; }
    else { const e = cmd.indexOf(" ", pos); args.push(cmd.slice(pos, e === -1 ? cmd.length : e)); pos = e === -1 ? cmd.length : e; }
  }
  return args.filter(a => a.length > 0);
}

// ── ffmpeg spawn ──────────────────────────────────────────────────
function spawnFF(url, audioOnly, safari, dir, m3u8, n) {
  n = n || 0;
  if (CUSTOM) {
    const vars = { STREAM_URL: url, ua: C.ua, audioBr: C.audioBr + "k", audioSr: String(C.audioSr), safariProfile: C.safariProfile, safariPreset: C.safariPreset, segSecs: String(C.segSecs), window: String(C.window) };
    let args = parseCmd(CUSTOM, vars).map(a => {
      if (a === "./seg%06d.ts" || a.endsWith("/seg%06d.ts")) return path.join(dir, "seg%06d.ts");
      if (a === "./index.m3u8" || a === "index.m3u8") return m3u8;
      if (a === "<STREAM_URL>") return url;
      return a;
    });
    if (!args.includes("-start_number") && n) { const i = args.lastIndexOf(m3u8); if (i > -1) args.splice(i, 0, "-start_number", String(n)); }
    const si = args.indexOf("-hls_segment_filename");
    if (si > -1 && args[si + 1] && !path.isAbsolute(args[si + 1])) args[si + 1] = path.join(dir, "seg%06d.ts");
    return spawn("ffmpeg", args);
  }
  if (safari && C.safariTranscode) {
    const vbr = C.safariVbr > 0 ? ["-b:v", C.safariVbr + "k"] : [];
    return spawn("ffmpeg", ["-loglevel", "error", ...inputArgs(), "-user_agent", C.ua, "-i", url,
      "-map", "0:v?", "-map", "0:a?", "-c:v", "libx264", "-profile:v", C.safariProfile,
      "-level", C.safariProfile === "baseline" ? "3.1" : "4.0", "-preset", C.safariPreset, "-tune", "zerolatency", ...vbr,
      "-c:a", "aac", "-b:a", C.audioBr + "k", "-ar", String(C.audioSr), "-ac", "2",
      "-fflags", fflags(), ...C.ffmpegExtra, ...hlsArgs(dir, m3u8, n)]);
  }
  const af = C.aresample ? ["-af", "aresample=async=1:first_pts=0"] : [];
  return spawn("ffmpeg", ["-loglevel", "error", ...inputArgs(), "-user_agent", C.ua, "-i", url,
    "-map", "0:v?", "-map", "0:a?", "-c:v", "copy", "-c:a", "aac", "-b:a", C.audioBr + "k", "-ar", String(C.audioSr), "-ac", "2",
    ...af, "-fflags", fflags(), ...C.ffmpegExtra, ...hlsArgs(dir, m3u8, n)]);
}

// ── Sessions ──────────────────────────────────────────────────────
const sessions = new Map();
const segCount = dir => { try { return fs.readdirSync(dir).filter(f => f.endsWith(".ts")).length; } catch (_) { return 0; } };

function kill(sid) {
  const s = sessions.get(sid); if (!s) return;
  s.dead = true; clearTimeout(s.idleTimer); clearInterval(s.watchdog);
  try { s.ff.kill("SIGKILL"); } catch (_) { }
  try { if (fs.existsSync(s.dir)) { fs.readdirSync(s.dir).forEach(f => { try { fs.unlinkSync(path.join(s.dir, f)); } catch (_) { } }); fs.rmdirSync(s.dir); } } catch (_) { }
  sessions.delete(sid);
}

function touch(sid) { const s = sessions.get(sid); if (!s) return; clearTimeout(s.idleTimer); s.idleTimer = setTimeout(() => kill(sid), C.idle); }

// ── Routes ────────────────────────────────────────────────────────
app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "Missing credentials" });
  try {
    const d = await xfetch(xurl(username, password, null));
    if (d.user_info && d.user_info.auth == 1) res.json({ ok: true, status: d.user_info.status, expiry: d.user_info.exp_date, connections: d.user_info.active_cons + "/" + d.user_info.max_connections });
    else res.status(401).json({ error: "Invalid credentials" });
  } catch (e) { res.status(502).json({ error: e.message }); }
});

const ALLOWED = new Set(["get_live_categories", "get_live_streams", "get_vod_categories", "get_vod_streams", "get_short_epg", "get_epg"]);
app.get("/api/xc/:action", async (req, res) => {
  const { username, password } = req.query; if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  const { action } = req.params; if (!ALLOWED.has(action)) return res.status(403).json({ error: "Not allowed" });
  const extra = {}; Object.entries(req.query).forEach(([k, v]) => { if (k !== "username" && k !== "password") extra[k] = v; });
  try { res.json(await xfetch(xurl(username, password, action, extra))); } catch (e) { res.status(502).json({ error: e.message }); }
});

app.get("/api/epg/:id", async (req, res) => {
  const { username, password } = req.query; if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  try { res.json(await xfetch(xurl(username, password, "get_short_epg", { stream_id: req.params.id, limit: 8 }))); } catch (_) { res.json({ epg_listings: [] }); }
});

app.get("/api/favs/:u", (req, res) => res.json(ruser(req.params.u.trim(), "favs", [])));
app.post("/api/favs/:u", (req, res) => { wuser(req.params.u.trim(), "favs", Array.isArray(req.body) ? req.body : []); res.json({ ok: true }); });
app.get("/api/prefs/:u", (req, res) => res.json(ruser(req.params.u.trim(), "prefs", { timezone: "America/Toronto" })));
app.post("/api/prefs/:u", (req, res) => { wuser(req.params.u.trim(), "prefs", req.body || {}); res.json({ ok: true }); });

app.post("/api/settings", (req, res) => {
  const s = req.body || {};
  const pl = v => typeof v === "string" && v.trim() ? v.trim().split(/\s+/).filter(Boolean) : [];
  const bool = (v, d) => v === undefined ? d : (v !== false && v !== "false" && v !== "0");
  const int = (v, d, m = 0) => Math.max(m, parseInt(v) || d);
  C.ua = UA[s.ua] || UA.chrome;
  C.segSecs = int(s.segSecs, 2, 1); C.prebuf = int(s.prebuf, 2, 1); C.window = int(s.window, 60, 5);
  C.idle = int(s.idle, 20, 5) * 1000; C.stallRestart = int(s.stallRestart, 10, 2) * 1000; C.maxRestarts = int(s.maxRestarts, 5, 0);
  C.hlsBuf = int(s.hlsBuf, 30, 5); C.backBuf = int(s.backBuf, 0, 0); C.liveSync = int(s.liveSync, 6, 1);
  C.stallDelay = int(s.stallDelay, 8, 1); C.snapLive = bool(s.snapLive, true);
  C.safariTranscode = bool(s.safariTranscode, true);
  C.safariProfile = ["baseline", "main", "high"].includes(s.safariProfile) ? s.safariProfile : "baseline";
  C.safariPreset = ["ultrafast", "superfast", "veryfast", "faster"].includes(s.safariPreset) ? s.safariPreset : "ultrafast";
  C.safariVbr = int(s.safariVbr, 0, 0);
  C.forceAac = bool(s.forceAac, false); C.audioBr = int(s.audioBr, 192, 64); C.audioSr = s.audioSr === "44100" ? 44100 : 48000;
  C.audioPrebuf = int(s.audioPrebuf, 4, 1); C.aresample = bool(s.aresample, true);
  C.ffmpegInput = pl(s.ffmpegInput); C.probeSize = int(s.probeSize, 1000000, 50000);
  C.analyzeDur = int(s.analyzeDur, 1500000, 100000); C.threadQueue = int(s.threadQueue, 8192, 512);
  C.ffmpegExtra = pl(s.ffmpegExtra); C.discardCorrupt = bool(s.discardCorrupt, true);
  C.genpts = bool(s.genpts, true); C.ignoreErr = bool(s.ignoreErr, false); C.noBuffer = bool(s.noBuffer, false);
  C.reconnect = bool(s.reconnect, true); C.reconnectNet = bool(s.reconnectNet, true);
  C.reconnectDelay = int(s.reconnectDelay, 5, 1); C.rwTimeout = int(s.rwTimeout, 15000000, 1000000);
  console.log("[settings]", JSON.stringify(C));
  res.json({ ok: true });
});

app.get("/api/ffcmd", (req, res) => {
  const cmd = ["ffmpeg", "-loglevel", "error", "-user_agent", C.ua, "-i", "<stream_url>", "-c:v", "copy", "-c:a", "aac", "-b:a", C.audioBr + "k", "-ar", String(C.audioSr), "-ac", "2", "-fflags", fflags(), "-f", "hls", "-hls_time", String(C.segSecs), "-hls_list_size", String(C.window), "-hls_flags", "delete_segments+append_list+omit_endlist+independent_segments", "-hls_segment_type", "mpegts", "-hls_segment_filename", "<dir>/seg%06d.ts", "<dir>/index.m3u8"];
  res.json({ cmd, cmdStr: cmd.join(" ") });
});

app.get("/api/ffcmd/custom", (req, res) => {
  const current = readCmd(), isCustom = !!CUSTOM;
  try { res.json({ current, default: fs.readFileSync(DEF_CMD, "utf8"), isCustom }); } catch (_) { res.json({ current, default: current, isCustom }); }
});
app.post("/api/ffcmd/custom", (req, res) => {
  const { cmd, enabled } = req.body || {};
  if (typeof cmd === "string") { fs.writeFileSync(CUS_CMD, cmd); CUSTOM = enabled !== false ? cmd : null; } else { CUSTOM = enabled !== false ? readCmd() : null; }
  res.json({ ok: true, enabled: !!CUSTOM });
});
app.post("/api/ffcmd/reset", (req, res) => {
  try { fs.unlinkSync(CUS_CMD); } catch (_) { } CUSTOM = null;
  res.json({ ok: true, default: fs.existsSync(DEF_CMD) ? fs.readFileSync(DEF_CMD, "utf8") : "" });
});

app.post("/api/stream/start", (req, res) => {
  const { username, password, streamId, sessionId: oldSid, safari } = req.body || {};
  if (!username || !password || !streamId) return res.status(400).json({ error: "Missing params" });
  if (oldSid) kill(oldSid);

  const sid = Date.now().toString(36) + Math.random().toString(36).slice(2);
  const dir = path.join(HLS_DIR, sid);
  const m3u8 = path.join(dir, "index.m3u8");
  fs.mkdirSync(dir, { recursive: true });

  const tsUrl = XC_HOST + "/live/" + encodeURIComponent(username) + "/" + encodeURIComponent(password) + "/" + streamId + ".ts";

  // Quick probe
  let audioOnly = false;
  try {
    const r = spawnSync("ffprobe", ["-v", "quiet", "-user_agent", "Mozilla/5.0", "-show_entries", "stream=codec_type", "-of", "csv=p=0", tsUrl], { timeout: 5000, encoding: "utf8" });
    const out = (r.stdout || "").toLowerCase();
    audioOnly = out.includes("audio") && !out.includes("video");
    console.log("[stream]", sid.slice(0, 8), "->", streamId, "video=" + out.includes("video"), "audio=" + out.includes("audio"), safari ? "[safari]" : "");
  } catch (_) { console.log("[stream]", sid.slice(0, 8), "-> probe failed"); }

  const SKIP = /^\[h264|^\[hevc|^\[aac|^\[mp3|^\[mpeg|PES packet|Packet corrupt|non monotonous|non-existing SPS|non-existing PPS|no frame!|Could not find ref|Error constructing|Last message repeated|frame size not set/i;
  let restarts = 0;
  let ff = spawnFF(tsUrl, audioOnly, safari, dir, m3u8, 0);
  ff.stderr.on("data", d => { const m = d.toString().trim(); if (m && !SKIP.test(m)) console.error("[ff:" + sid.slice(0, 8) + "]", m); });

  const restart = () => {
    const s = sessions.get(sid); if (!s || s.dead) return;
    if (C.maxRestarts > 0 && restarts >= C.maxRestarts) { kill(sid); return; }
    restarts++;
    ff = spawnFF(tsUrl, audioOnly, safari, dir, m3u8, segCount(dir));
    ff.stderr.on("data", d => { const m = d.toString().trim(); if (m && !SKIP.test(m)) console.error("[ff:" + sid.slice(0, 8) + "]", m); });
    ff.on("close", restart); s.ff = ff;
  };
  ff.on("close", restart);
  ff.on("error", e => console.error("[ff] spawn:", e.message));

  let lastN = 0, lastT = Date.now(), armed = false;
  const watchdog = setInterval(() => {
    const s = sessions.get(sid); if (!s || s.dead) { clearInterval(watchdog); return; }
    const n = segCount(dir);
    if (n > lastN) { lastN = n; lastT = Date.now(); if (n >= C.prebuf) armed = true; }
    else if (armed && Date.now() - lastT > C.stallRestart) { lastT = Date.now(); try { s.ff.kill("SIGKILL"); } catch (_) { } }
  }, 1000);

  sessions.set(sid, { ff, dir, idleTimer: setTimeout(() => kill(sid), C.idle), watchdog, dead: false });

  const prebuf = audioOnly ? C.audioPrebuf : C.prebuf;
  const t0 = Date.now();
  const poll = setInterval(() => {
    if (!sessions.has(sid)) { clearInterval(poll); if (!res.headersSent) res.status(502).json({ error: "Stream failed" }); return; }
    if (segCount(dir) >= prebuf && fs.existsSync(m3u8) && fs.statSync(m3u8).size > 0) {
      clearInterval(poll);
      console.log("[stream]", sid.slice(0, 8), "ready");
      res.json({ ok: true, sessionId: sid, url: "/hls/" + sid + "/index.m3u8", audioOnly, hlsCfg: { maxBufferLength: C.hlsBuf, backBufferLength: C.backBuf, liveSyncSeconds: C.liveSync, maxStarvationDelay: C.stallDelay, snapLive: C.snapLive } });
    } else if (Date.now() - t0 > 30000) { clearInterval(poll); kill(sid); if (!res.headersSent) res.status(504).json({ error: "Timed out" }); }
  }, 300);
});

app.post("/api/stream/heartbeat/:sid", (req, res) => { if (!sessions.has(req.params.sid)) return res.status(404).json({ error: "Gone" }); touch(req.params.sid); res.json({ ok: true }); });
app.post("/api/stream/stop/:sid", (req, res) => { kill(req.params.sid); res.json({ ok: true }); });
app.post("/api/stream/stopall", (req, res) => { const s = [...sessions.keys()]; s.forEach(kill); res.json({ ok: true, stopped: s.length }); });

app.get("/hls/:sid/:file", (req, res) => {
  const fp = path.join(HLS_DIR, req.params.sid, req.params.file);
  if (!fs.existsSync(fp)) return res.status(404).send("Not found");
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (req.params.file.endsWith(".m3u8")) {
    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.setHeader("Cache-Control", "no-cache");
    try { res.send(fs.readFileSync(fp, "utf8").replace(/^(seg\d+\.ts)$/mg, "/hls/" + req.params.sid + "/$1")); } catch (_) { res.status(500).end(); }
  } else { res.setHeader("Content-Type", "video/mp2t"); res.setHeader("Cache-Control", "public,max-age=10"); res.sendFile(fp); }
});

app.get("/logo", async (req, res) => {
  const url = req.query.url;
  if (!url || !/^https?:\/\//i.test(url)) return res.status(400).end();
  try {
    const p = new URL(url), lib = p.protocol === "https:" ? https : http;
    const r = lib.request({ hostname: p.hostname, port: p.port || (p.protocol === "https:" ? 443 : 80), path: p.pathname + p.search, method: "GET", headers: { "User-Agent": "Mozilla/5.0", "Accept": "image/*,*/*" } }, pr => {
      res.setHeader("Content-Type", pr.headers["content-type"] || "image/png"); res.setHeader("Cache-Control", "public,max-age=86400"); res.setHeader("Access-Control-Allow-Origin", "*"); pr.pipe(res, { end: true });
    });
    r.on("error", () => res.status(502).end()); r.setTimeout(5000, () => { r.destroy(); res.status(504).end(); }); r.end();
  } catch (_) { res.status(400).end(); }
});

app.use(express.static(path.join(__dirname, "../static")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../static/index.html")));
process.on("SIGTERM", () => { [...sessions.keys()].forEach(kill); process.exit(0); });
app.listen(PORT, () => console.log("Stream :" + PORT + "  XC: " + XC_HOST));
