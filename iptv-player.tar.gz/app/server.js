"use strict";
const express  = require("express");
const path     = require("path");
const fs       = require("fs");
const http     = require("http");
const https    = require("https");
const os       = require("os");
const { spawn, spawnSync } = require("child_process");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
const XC_HOST  = (process.env.XC_HOST || "http://192.168.1.124:3000").replace(/\/+$/, "");
const HLS_DIR  = path.join(os.tmpdir(), "iptv-hls");

[DATA_DIR, HLS_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));
app.use(express.json({ limit: "10mb" }));

// ── Config ────────────────────────────────────────────────────────
const UA = {
  chrome:   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
  vlc:      "VLC/3.0.20 LibVLC/3.0.20",
  tivimate: "TiviMate/4.7.0",
};

let C = {
  ua: UA.chrome,
  segSecs: 2, prebuf: 2, window: 10, idle: 20000, stallRestart: 10000,
  forwardPad: 3, backPad: 2,
  forceAac: false, audioBr: 192, audioSr: 48000, aresample: true, audioPrebuf: 4,
  safariTranscode: true, safariProfile: "baseline", safariPreset: "ultrafast", safariVbr: 0,
  genpts: true, discardCorrupt: true, ffmpegInput: [], ffmpegExtra: [],
};

// ── Helpers ───────────────────────────────────────────────────────
const ufile = (u, t) => path.join(DATA_DIR, `${t}_${u.replace(/[^a-zA-Z0-9_\-.]/g,"_")}.json`);
const ruser = (u, t, d) => { try { return JSON.parse(fs.readFileSync(ufile(u,t),"utf8")); } catch(_) { return d; } };
const wuser = (u, t, d) => fs.writeFileSync(ufile(u,t), JSON.stringify(d));

function xfetch(url, ms=15000) {
  return new Promise((res, rej) => {
    const p = new URL(url), lib = p.protocol === "https:" ? https : http;
    const req = lib.request({
      hostname: p.hostname, port: p.port || (p.protocol === "https:" ? 443 : 80),
      path: p.pathname + p.search, method: "GET", headers: { "User-Agent": "Mozilla/5.0" }
    }, r => {
      let b = ""; r.on("data", c => b += c);
      r.on("end", () => { try { res(JSON.parse(b)); } catch(_) { rej(new Error("Non-JSON")); } });
    });
    req.on("error", rej);
    req.setTimeout(ms, () => { req.destroy(); rej(new Error("Timeout")); });
    req.end();
  });
}

function xurl(u, p, action, extra = {}) {
  const url = new URL(`${XC_HOST}/player_api.php`);
  url.searchParams.set("username", u);
  url.searchParams.set("password", p);
  if (action) url.searchParams.set("action", action);
  Object.entries(extra).forEach(([k,v]) => url.searchParams.set(k,v));
  return url.toString();
}

function detectStream(url) {
  const r = spawnSync("ffprobe", [
    "-v", "quiet", "-user_agent", "Mozilla/5.0",
    "-show_entries", "stream=codec_type,r_frame_rate,codec_name",
    "-of", "json", url
  ], { timeout: 8000, encoding: "utf8" });
  try {
    const streams = (JSON.parse(r.stdout || "{}").streams) || [];
    if (!streams.length) return null;  // null = probe failed, try other URL
    const v = streams.find(s => s.codec_type === "video");
    const a = streams.find(s => s.codec_type === "audio");
    let fps = 25;
    if (v?.r_frame_rate) {
      const [n,d] = v.r_frame_rate.split("/").map(Number);
      if (d > 0) fps = Math.round(n/d);
    }
    const videoCodec = v?.codec_name || "";
    // HEVC/H.265, AV1, VP9 cannot be direct-copied to HLS for Safari
    // They need transcoding — flag this so we can handle it
    const needsTranscode = /hevc|h265|av1|vp9/i.test(videoCodec);
    return { hasVideo: !!v, hasAudio: !!a, fps, videoCodec, needsTranscode };
  } catch(_) { return null; }
}

// ── Custom command ────────────────────────────────────────────────
const DEF_CMD = path.join(__dirname, "ffmpeg-default.txt");
const CUS_CMD = path.join(DATA_DIR, "ffmpeg-custom.txt");
let CUSTOM = null;

function readCmd() {
  try { return fs.readFileSync(CUS_CMD, "utf8"); } catch(_) {}
  try { return fs.readFileSync(DEF_CMD, "utf8"); } catch(_) { return ""; }
}

function parseCmd(tmpl, vars) {
  let cmd = tmpl.replace(/\{(\w+)\}/g, (_,k) => vars[k] ?? `{${k}}`);
  cmd = cmd.replace(/^\s*ffmpeg\s*/, "");
  const lines = cmd.split("\n"), joined = [];
  for (const line of lines)
    joined.push(line.trimEnd().endsWith("\\") ? line.trimEnd().slice(0,-1)+" " : line+" ");
  cmd = joined.join("").trim();
  const args = []; let pos = 0;
  while (pos < cmd.length) {
    while (pos < cmd.length && cmd[pos] === " ") pos++;
    if (pos >= cmd.length || cmd[pos] === "#") break;
    if (cmd[pos] === '"') {
      const e = cmd.indexOf('"', pos+1);
      args.push(cmd.slice(pos+1, e === -1 ? cmd.length : e));
      pos = (e === -1 ? cmd.length : e) + 1;
    } else {
      const e = cmd.indexOf(" ", pos);
      args.push(cmd.slice(pos, e === -1 ? cmd.length : e));
      pos = e === -1 ? cmd.length : e;
    }
  }
  return args.filter(a => a.length > 0);
}

// ── ffmpeg ────────────────────────────────────────────────────────
function spawnFfmpeg(url, info, dir, m3u8, startNum, safari) {
  startNum = startNum || 0;
  const audioOnly = info?.hasAudio && !info?.hasVideo;
  const fps = info?.fps || 25;

  // Custom command override
  if (CUSTOM) {
    const vars = { STREAM_URL: url, ua: C.ua, audioBr: C.audioBr+"k",
      audioSr: String(C.audioSr), segSecs: String(C.segSecs), window: String(C.window) };
    let args = parseCmd(CUSTOM, vars).map(a => {
      if (a === "./seg%06d.ts" || a.endsWith("/seg%06d.ts")) return path.join(dir,"seg%06d.ts");
      if (a === "./index.m3u8" || a === "index.m3u8") return m3u8;
      if (a === "<STREAM_URL>") return url;
      return a;
    });
    if (!args.includes("-start_number") && startNum) {
      const i = args.lastIndexOf(m3u8);
      if (i > -1) args.splice(i, 0, "-start_number", String(startNum));
    }
    const si = args.indexOf("-hls_segment_filename");
    if (si > -1 && args[si+1] && !path.isAbsolute(args[si+1]))
      args[si+1] = path.join(dir, "seg%06d.ts");
    return spawn("ffmpeg", args);
  }

  // Input flags — applied before -i
  // These settings are proven for IPTV live streams:
  const fflags = [
    C.genpts        ? "genpts"        : null,
    C.discardCorrupt? "discardcorrupt": null,
  ].filter(Boolean).join("+");

  const inputArgs = [
    "-hide_banner", "-loglevel",            "error",
    "-reconnect",                           "1",
    "-reconnect_streamed",                  "1",
    "-reconnect_on_network_error",          "1",
    "-reconnect_delay_max",                 "5",
    "-rw_timeout",                          "10000000",   // 10s
    "-thread_queue_size",                   "4096",
    "-analyzeduration",                     "1000000",    // 1s
    "-probesize",                           "1000000",    // 1MB
    ...(fflags ? ["-fflags", "+"+fflags] : []),
    "-user_agent",                          C.ua,
    ...C.ffmpegInput,
    "-i",                                   url,
  ];

  // HLS output flags
  // Safari native player buffers the entire playlist eagerly.
  // Short window (4 segs) = ~8s pre-buffered, no catch-up stutter.
  const safariListSize = Math.min(4, C.window);
  const listSize = (safari && C.safariTranscode) ? safariListSize : C.window;

  const hlsArgs = [
    "-f",                    "hls",
    "-hls_time",             String(C.segSecs),
    "-hls_list_size",        String(listSize),
    "-hls_delete_threshold", String(Math.max(3, C.backPad)),
    "-hls_flags",            "delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_allow_cache",      "0",
    "-hls_segment_type",     "mpegts",
    "-hls_segment_filename", path.join(dir, "seg%06d.ts"),
    "-start_number",         String(startNum),
    m3u8,
  ];

  // ── Safari/iOS: H.264 + AAC-LC ───────────────────────────────
  // 10-bit HEVC (4K HDR) cannot be encoded with Baseline profile.
  // -pix_fmt yuv420p forces 8-bit 4:2:0 — required for all H.264 profiles.
  // For 10-bit sources this is mandatory; for 8-bit it's a no-op.
  // If source is 10-bit, use Main profile minimum (Baseline rejects 10-bit input
  // even after pix_fmt conversion because libx264 checks input bit depth).
  if (safari && C.safariTranscode) {
    const gop   = Math.round(fps * C.segSecs);
    // Force Main profile for 10-bit sources — Baseline explicitly rejects them
    const is10bit = info?.needsTranscode || false;
    const profile = is10bit && C.safariProfile === "baseline" ? "main" : C.safariProfile;
    const level   = profile === "baseline" ? "3.1" : profile === "main" ? "4.0" : "4.1";
    const vbr     = C.safariVbr > 0 ? ["-b:v", C.safariVbr+"k"] : [];
    console.log(`[ff:safari] ${profile}/${level} fps=${fps} gop=${gop} seg=${C.segSecs}s 10bit=${is10bit}`);
    return spawn("ffmpeg", [
      ...inputArgs,
      "-map", "0:v:0", "-map", "0:a:0",
      "-c:v",          "libx264",
      "-profile:v",    profile,
      "-level:v",      level,
      "-preset",       C.safariPreset,
      "-tune",         "zerolatency",
      // pix_fmt yuv420p: converts 10-bit → 8-bit and ensures 4:2:0 chroma
      // This MUST come before -profile:v takes effect, so put it early
      "-pix_fmt",      "yuv420p",
      "-g",            String(gop),
      "-keyint_min",   String(gop),
      "-forced_idr",   "1",
      "-sc_threshold", "0",
      "-bf",           "0",
      ...vbr,
      "-c:a",          "aac",
      "-profile:a",    "aac_low",
      "-b:a",          C.audioBr+"k",
      "-ar",           String(C.audioSr),
      "-ac",           "2",
      ...C.ffmpegExtra,
      ...hlsArgs,
    ]);
  }

  // ── Audio-only: radio / SiriusXM ─────────────────────────────
  // async=1000 absorbs large timing gaps without audible artifacts.
  if (audioOnly) {
    const af = C.aresample
      ? ["-af", "aresample=async=1000:min_hard_comp=0.100:first_pts=0"]
      : [];
    console.log("[ff:audio] audio-only");
    return spawn("ffmpeg", [
      ...inputArgs,
      "-vn", "-map", "0:a:0",
      "-c:a",       "aac",
      "-profile:a", "aac_low",
      "-b:a",       C.audioBr+"k",
      "-ar",        String(C.audioSr),
      "-ac",        "2",
      ...af,
      ...C.ffmpegExtra,
      ...hlsArgs,
    ]);
  }

  // ── Standard video: copy video, transcode audio ───────────────
  // -c:v copy = zero CPU, zero quality loss, instant start.
  // aresample=async=1 fixes PTS drift from copy-v vs transcode-a.
  const af = C.aresample ? ["-af", "aresample=async=1:first_pts=0"] : [];
  console.log(`[ff:video] copy-v/aac-a seg=${C.segSecs}s`);
  return spawn("ffmpeg", [
    ...inputArgs,
    "-map", "0:v:0", "-map", "0:a:0",
    "-c:v",       "copy",
    "-c:a",       "aac",
    "-profile:a", "aac_low",
    "-b:a",       C.audioBr+"k",
    "-ar",        String(C.audioSr),
    "-ac",        "2",
    ...af,
    ...C.ffmpegExtra,
    ...hlsArgs,
  ]);
}

// ── Sessions ──────────────────────────────────────────────────────
const sessions = new Map();
const segCount = dir => {
  try { return fs.readdirSync(dir).filter(f => f.endsWith(".ts")).length; }
  catch(_) { return 0; }
};

function killSession(sid) {
  const s = sessions.get(sid);
  if (!s) return;
  s.dead = true;
  clearTimeout(s.idleTimer);
  clearTimeout(s.heartbeatTimer);
  clearInterval(s.watchdog);
  try { s.ff.kill("SIGKILL"); } catch(_) {}
  try {
    if (fs.existsSync(s.dir)) {
      fs.readdirSync(s.dir).forEach(f => { try { fs.unlinkSync(path.join(s.dir,f)); } catch(_) {} });
      fs.rmdirSync(s.dir);
    }
  } catch(_) {}
  sessions.delete(sid);
}

function resetIdle(sid) {
  const s = sessions.get(sid);
  if (!s) return;
  clearTimeout(s.idleTimer);
  s.idleTimer = setTimeout(() => killSession(sid), C.idle);
}

// Touch heartbeat timer — separate from idle timer
// If client goes away without calling /stop, this kills the session
// after 25s of silence (client heartbeats every 8s normally)
function touchHeartbeat(sid) {
  const s = sessions.get(sid);
  if (!s) return;
  clearTimeout(s.heartbeatTimer);
  s.heartbeatTimer = setTimeout(() => {
    console.log(`[stream] ${sid.slice(0,8)} heartbeat timeout — killing`);
    killSession(sid);
  }, 25000);
}

// ── Routes ────────────────────────────────────────────────────────
app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "Missing credentials" });
  try {
    const d = await xfetch(xurl(username, password, null));
    if (d.user_info?.auth == 1)
      res.json({ ok: true, status: d.user_info.status, expiry: d.user_info.exp_date,
        connections: `${d.user_info.active_cons}/${d.user_info.max_connections}` });
    else res.status(401).json({ error: "Invalid credentials" });
  } catch(e) { res.status(502).json({ error: e.message }); }
});

const ALLOWED = new Set(["get_live_categories","get_live_streams","get_vod_categories",
  "get_vod_streams","get_short_epg","get_epg"]);

app.get("/api/xc/:action", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  const { action } = req.params;
  if (!ALLOWED.has(action)) return res.status(403).json({ error: "Not allowed" });
  const extra = {};
  Object.entries(req.query).forEach(([k,v]) => { if (k!=="username"&&k!=="password") extra[k]=v; });
  try { res.json(await xfetch(xurl(username, password, action, extra))); }
  catch(e) { res.status(502).json({ error: e.message }); }
});

app.get("/api/epg/:id", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  try { res.json(await xfetch(xurl(username, password, "get_short_epg", { stream_id: req.params.id, limit: 8 }))); }
  catch(_) { res.json({ epg_listings: [] }); }
});

app.get("/api/favs/:u",  (req,res) => res.json(ruser(req.params.u.trim(),"favs",[])));
app.post("/api/favs/:u", (req,res) => { wuser(req.params.u.trim(),"favs",Array.isArray(req.body)?req.body:[]); res.json({ok:true}); });
app.get("/api/prefs/:u",  (req,res) => res.json(ruser(req.params.u.trim(),"prefs",{timezone:"America/Toronto"})));
app.post("/api/prefs/:u", (req,res) => { wuser(req.params.u.trim(),"prefs",req.body||{}); res.json({ok:true}); });

app.post("/api/settings", (req, res) => {
  const s = req.body || {};
  const pl   = v => typeof v==="string"&&v.trim() ? v.trim().split(/\s+/).filter(Boolean) : [];
  const bool = (v,d) => v===undefined ? d : (v!==false && v!=="false" && v!=="0");
  const int  = (v,d,m=0) => Math.max(m, parseInt(v)||d);
  C.ua             = UA[s.ua] || UA.chrome;
  C.segSecs        = int(s.segSecs,2,1);
  C.prebuf         = int(s.prebuf,2,1);
  C.window         = int(s.window,10,3);
  C.idle           = int(s.idle,20,5) * 1000;
  C.stallRestart   = int(s.stallRestart,10,2) * 1000;
  C.forwardPad     = int(s.forwardPad,3,1);
  C.backPad        = int(s.backPad,2,0);
  C.forceAac       = bool(s.forceAac,false);
  C.audioBr        = int(s.audioBr,192,64);
  C.audioSr        = s.audioSr==="44100" ? 44100 : 48000;
  C.aresample      = bool(s.aresample,true);
  C.audioPrebuf    = int(s.audioPrebuf,4,1);
  C.safariTranscode= bool(s.safariTranscode,true);
  C.safariProfile  = ["baseline","main","high"].includes(s.safariProfile) ? s.safariProfile : "baseline";
  C.safariPreset   = ["ultrafast","superfast","veryfast","faster"].includes(s.safariPreset) ? s.safariPreset : "ultrafast";
  C.safariVbr      = int(s.safariVbr,0,0);
  C.genpts         = bool(s.genpts,true);
  C.discardCorrupt = bool(s.discardCorrupt,true);
  C.ffmpegInput    = pl(s.ffmpegInput);
  C.ffmpegExtra    = pl(s.ffmpegExtra);
  console.log("[settings]", JSON.stringify(C));
  res.json({ ok: true });
});

app.get("/api/ffcmd", (req, res) => {
  const fflags = [C.genpts?"genpts":null, C.discardCorrupt?"discardcorrupt":null].filter(Boolean).join("+");
  const cmd = ["ffmpeg","-hide_banner","-loglevel","error","-reconnect","1","-reconnect_streamed","1",
    "-reconnect_on_network_error","1","-reconnect_delay_max","5","-rw_timeout","10000000",
    "-thread_queue_size","4096","-analyzeduration","1000000","-probesize","1000000",
    ...(fflags?["-fflags","+"+fflags]:[]),"-user_agent",C.ua,"-i","<stream_url>",
    "-map","0:v:0","-map","0:a:0","-c:v","copy","-c:a","aac","-profile:a","aac_low",
    "-b:a",C.audioBr+"k","-ar",String(C.audioSr),"-ac","2",
    "-f","hls","-hls_time",String(C.segSecs),"-hls_list_size",String(C.window),
    "-hls_flags","delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_segment_type","mpegts","-hls_segment_filename","<dir>/seg%06d.ts","<dir>/index.m3u8"];
  res.json({ cmd, cmdStr: cmd.join(" ") });
});

app.get("/api/ffcmd/custom", (req, res) => {
  const current = readCmd(), isCustom = !!CUSTOM;
  try { res.json({ current, default: fs.readFileSync(DEF_CMD,"utf8"), isCustom }); }
  catch(_) { res.json({ current, default: current, isCustom }); }
});
app.post("/api/ffcmd/custom", (req, res) => {
  const { cmd, enabled } = req.body || {};
  if (typeof cmd === "string") { fs.writeFileSync(CUS_CMD, cmd); CUSTOM = enabled!==false ? cmd : null; }
  else { CUSTOM = enabled!==false ? readCmd() : null; }
  res.json({ ok: true, enabled: !!CUSTOM });
});
app.post("/api/ffcmd/reset", (req, res) => {
  try { fs.unlinkSync(CUS_CMD); } catch(_) {}
  CUSTOM = null;
  res.json({ ok: true, default: fs.existsSync(DEF_CMD) ? fs.readFileSync(DEF_CMD,"utf8") : "" });
});

// ── Stream start ──────────────────────────────────────────────────
app.post("/api/stream/start", (req, res) => {
  const { username, password, streamId, sessionId: oldSid, safari } = req.body || {};
  if (!username || !password || !streamId) return res.status(400).json({ error: "Missing params" });
  if (oldSid) killSession(oldSid);

  const sid  = Date.now().toString(36) + Math.random().toString(36).slice(2);
  const dir  = path.join(HLS_DIR, sid);
  const m3u8 = path.join(dir, "index.m3u8");
  fs.mkdirSync(dir, { recursive: true });

  const urlTs   = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.ts`;
  const urlM3u8 = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.m3u8`;

  // Try .ts first, fall back to .m3u8 if it fails
  // 4K/HEVC streams often fail on .ts but work via .m3u8
  let info = detectStream(urlTs);
  let xcUrl = urlTs;
  if (!info) {
    console.log(`[stream] ${sid.slice(0,8)} .ts probe failed — trying .m3u8`);
    info = detectStream(urlM3u8);
    xcUrl = urlM3u8;
  }
  // Still null? Default and hope for the best
  if (!info) info = { hasVideo: true, hasAudio: true, fps: 25, videoCodec: "", needsTranscode: false };

  const audioOnly = info.hasAudio && !info.hasVideo;

  // For Safari: HEVC streams need full transcode regardless of safariTranscode setting
  const effectiveSafari = safari && (C.safariTranscode || info.needsTranscode);

  console.log(`[stream] ${sid.slice(0,8)} → ${streamId} video=${info.hasVideo} audio=${info.hasAudio} codec=${info.videoCodec||"?"} fps=${info.fps} needsTranscode=${info.needsTranscode} safari=${!!safari} url=${xcUrl.slice(-8)}`);

  const SKIP = /frame size not set|PES packet|Packet corrupt|Last message repeated|non monotonous|non-existing SPS|non-existing PPS|no frame!|Could not find ref|Error constructing|\[h264 @|\[hevc @|\[aac @|\[mp3 @/i;

  let ff = spawnFfmpeg(xcUrl, info, dir, m3u8, 0, effectiveSafari);
  const onErr = d => { const m = d.toString().trim(); if (m && !SKIP.test(m)) console.error(`[ff:${sid.slice(0,8)}]`, m); };
  ff.stderr.on("data", onErr);

  // Restart with failure tracking
  // - max 5 restarts total before giving up and killing the session
  // - exponential backoff: 1s, 2s, 4s, 8s, 16s between attempts
  // - fast exits (ffmpeg dies in <3s) count as failures
  // - slow exits (ffmpeg ran >10s) reset the failure counter (stream was working)
  let restartCount = 0;
  let lastSpawnTime = Date.now();
  const MAX_RESTARTS = 5;

  const restart = () => {
    const s = sessions.get(sid);
    if (!s || s.dead) return;

    const aliveMs = Date.now() - lastSpawnTime;

    if (aliveMs > 10000) {
      // Was running for >10s — counts as a good run, reset failure counter
      restartCount = 0;
    } else {
      restartCount++;
    }

    if (restartCount >= MAX_RESTARTS) {
      console.error(`[stream] ${sid.slice(0,8)} failed ${MAX_RESTARTS} times — giving up`);
      killSession(sid);
      return;
    }

    const delay = Math.min(1000 * Math.pow(2, restartCount - 1), 16000);
    console.log(`[stream] ${sid.slice(0,8)} restarting (attempt ${restartCount}/${MAX_RESTARTS}) in ${delay}ms`);

    setTimeout(() => {
      const s2 = sessions.get(sid);
      if (!s2 || s2.dead) return;
      lastSpawnTime = Date.now();
      const next = segCount(dir);
      ff = spawnFfmpeg(xcUrl, info, dir, m3u8, next, effectiveSafari);
      ff.stderr.on("data", onErr);
      ff.on("close", restart);
      ff.on("error", e => { console.error("[ff] spawn:", e.message); restart(); });
      s2.ff = ff;
    }, delay);
  };
  ff.on("close", restart);
  ff.on("error", e => { console.error("[ff] spawn:", e.message); restart(); });

  // Watchdog: two jobs —
  // 1. Kill stalled ffmpeg so restart() can recover it
  // 2. Kill the whole session if no segments ever appear within 30s (hard fail)
  let lastN = 0, lastT = Date.now(), firstSegTime = 0;
  const watchdog = setInterval(() => {
    const s = sessions.get(sid);
    if (!s || s.dead) { clearInterval(watchdog); return; }
    const n = segCount(dir);

    if (n > lastN) {
      // New segment — stream is alive
      if (!firstSegTime) firstSegTime = Date.now();
      lastN = n; lastT = Date.now();
    } else if (firstSegTime && Date.now() - lastT > C.stallRestart) {
      // Had segments, now stalled — kill ffmpeg so restart() fires
      console.log(`[stream] ${sid.slice(0,8)} stalled — killing ffmpeg`);
      lastT = Date.now();
      try { s.ff.kill("SIGKILL"); } catch(_) {}
    } else if (!firstSegTime && Date.now() - lastT > 30000) {
      // Never produced any segments after 30s — hard fail, kill session entirely
      console.error(`[stream] ${sid.slice(0,8)} no segments in 30s — killing session`);
      killSession(sid);
    }
  }, 1000);

  const idleTimer = setTimeout(() => killSession(sid), C.idle);
  sessions.set(sid, { ff, dir, idleTimer, watchdog, heartbeatTimer: null, dead: false });
  touchHeartbeat(sid);  // start heartbeat timeout immediately

  // Wait for prebuf segments
  const prebuf = audioOnly ? C.audioPrebuf
               : effectiveSafari ? Math.max(C.prebuf, 3)
               : C.prebuf;
  const t0 = Date.now();
  const poll = setInterval(() => {
    if (!sessions.has(sid)) {
      clearInterval(poll);
      if (!res.headersSent) res.status(502).json({ error: "Stream failed" });
      return;
    }
    if (segCount(dir) >= prebuf && fs.existsSync(m3u8) && fs.statSync(m3u8).size > 0) {
      clearInterval(poll);
      console.log(`[stream] ${sid.slice(0,8)} ready (${segCount(dir)} segs)`);
      res.json({
        ok: true, sessionId: sid,
        url: `/hls/${sid}/index.m3u8`,
        audioOnly,
        hlsCfg: {
          segSecs:    C.segSecs,
          forwardPad: C.forwardPad,
          backPad:    C.backPad,
        },
      });
    } else if (Date.now()-t0 > 30000) {
      clearInterval(poll); killSession(sid);
      if (!res.headersSent) res.status(504).json({ error: "Stream timed out" });
    }
  }, 300);
});

app.post("/api/stream/heartbeat/:sid", (req, res) => {
  if (!sessions.has(req.params.sid)) return res.status(404).json({ error: "Gone" });
  resetIdle(req.params.sid);
  touchHeartbeat(req.params.sid);
  res.json({ ok: true });
});

app.post("/api/stream/stop/:sid", (req, res) => {
  killSession(req.params.sid);
  res.json({ ok: true });
});

app.post("/api/stream/stopall", (req, res) => {
  const sids = [...sessions.keys()];
  sids.forEach(killSession);
  console.log(`[stream] stopped all: ${sids.length}`);
  res.json({ ok: true, stopped: sids.length });
});

// ── HLS serving ───────────────────────────────────────────────────
function serveM3u8(fp, sid, res) {
  try {
    const raw = fs.readFileSync(fp, "utf8");
    res.send(raw.replace(/^(seg\d+\.ts)$/mg, `/hls/${sid}/$1`));
  } catch(_) { res.status(500).end(); }
}

app.get("/hls/:sid/:file", (req, res) => {
  const fp = path.join(HLS_DIR, req.params.sid, req.params.file);
  if (!fs.existsSync(fp)) return res.status(404).send("Not found");
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (req.params.file.endsWith(".m3u8")) {
    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    serveM3u8(fp, req.params.sid, res);
  } else {
    res.setHeader("Content-Type", "video/mp2t");
    res.setHeader("Cache-Control", "public, max-age=30");
    res.sendFile(fp);
  }
});

// ── Logo proxy ────────────────────────────────────────────────────
app.get("/logo", async (req, res) => {
  const url = req.query.url;
  if (!url || !/^https?:\/\//i.test(url)) return res.status(400).end();
  try {
    const p = new URL(url), lib = p.protocol === "https:" ? https : http;
    const r = lib.request({
      hostname: p.hostname, port: p.port||(p.protocol==="https:"?443:80),
      path: p.pathname+p.search, method: "GET",
      headers: { "User-Agent": "Mozilla/5.0", "Accept": "image/*,*/*" }
    }, pr => {
      res.setHeader("Content-Type", pr.headers["content-type"]||"image/png");
      res.setHeader("Cache-Control", "public,max-age=86400");
      pr.pipe(res, { end: true });
    });
    r.on("error", () => res.status(502).end());
    r.setTimeout(5000, () => { r.destroy(); res.status(504).end(); });
    r.end();
  } catch(_) { res.status(400).end(); }
});

app.use(express.static(path.join(__dirname, "../static")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../static/index.html")));
process.on("SIGTERM", () => { [...sessions.keys()].forEach(killSession); process.exit(0); });
app.listen(PORT, () => console.log(`Stream :${PORT}  XC: ${XC_HOST}`));
