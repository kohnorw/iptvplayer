"use strict";

const express    = require("express");
const path       = require("path");
const fs         = require("fs");
const http       = require("http");
const https      = require("https");
const { spawn }  = require("child_process");

const app        = express();
const PORT       = process.env.PORT     || 8080;
const DATA_DIR   = process.env.DATA_DIR || path.join(__dirname, "../data");
const XC_HOST    = process.env.XC_HOST  || "http://192.168.1.124:3000";

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
const FAVOURITES_FILE = path.join(DATA_DIR, "favourites.json");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "../static")));

function load(f)    { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch(_){ return null; } }
function save(f, d) { fs.writeFileSync(f, JSON.stringify(d)); }

// ── XC-Menu fetch (server-side, bypasses allowlist) ───────────────
async function xcFetch(url, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const lib    = parsed.protocol === "https:" ? https : http;
    const req    = lib.request({
      hostname: parsed.hostname,
      port:     parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path:     parsed.pathname + parsed.search,
      method:   "GET",
      headers:  { "User-Agent": "Mozilla/5.0" },
    }, res => {
      let body = "";
      res.on("data", c => body += c);
      res.on("end", () => {
        try { resolve(JSON.parse(body)); }
        catch(_) { reject(new Error(`Non-JSON from XC-Menu (HTTP ${res.statusCode}): ${body.slice(0,120)}`)); }
      });
    });
    req.on("error", reject);
    req.setTimeout(timeoutMs, () => { req.destroy(); reject(new Error("XC-Menu request timed out")); });
    req.end();
  });
}

function xcUrl(username, password, action, extra = {}) {
  const u = new URL(`${XC_HOST}/player_api.php`);
  u.searchParams.set("username", username);
  u.searchParams.set("password", password);
  if (action) u.searchParams.set("action", action);
  for (const [k, v] of Object.entries(extra)) u.searchParams.set(k, v);
  return u.toString();
}

// ── Auth ──────────────────────────────────────────────────────────
app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password)
    return res.status(400).json({ error: "username and password required" });
  try {
    const d = await xcFetch(xcUrl(username, password, null));
    if (d.user_info && d.user_info.auth == 1) {
      res.json({
        ok: true,
        status:      d.user_info.status,
        expiry:      d.user_info.exp_date,
        connections: `${d.user_info.active_cons}/${d.user_info.max_connections}`,
      });
    } else {
      res.status(401).json({ error: "Invalid username or password" });
    }
  } catch(e) {
    res.status(502).json({ error: "Cannot reach XC-Menu: " + e.message });
  }
});

// ── XC API proxy ──────────────────────────────────────────────────
const ALLOWED_ACTIONS = new Set([
  "get_live_categories", "get_live_streams",
  "get_vod_categories",  "get_vod_streams",
  "get_series_categories","get_series",
  "get_short_epg",       "get_epg",
]);

app.get("/api/xc/:action", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  const { action } = req.params;
  if (!ALLOWED_ACTIONS.has(action)) return res.status(403).json({ error: "Action not allowed" });

  const extra = {};
  for (const [k, v] of Object.entries(req.query))
    if (k !== "username" && k !== "password") extra[k] = v;

  try {
    res.json(await xcFetch(xcUrl(username, password, action, extra)));
  } catch(e) {
    res.status(502).json({ error: e.message });
  }
});

// ── EPG ───────────────────────────────────────────────────────────
app.get("/api/epg/:streamId", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  try {
    res.json(await xcFetch(xcUrl(username, password, "get_short_epg", {
      stream_id: req.params.streamId, limit: 8,
    })));
  } catch(_) { res.json({ epg_listings: [] }); }
});

// ── FFmpeg stream proxy ───────────────────────────────────────────
app.get("/proxy/stream/:streamId", (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).send("Missing credentials");

  const streamId = req.params.streamId;
  const xcUrl    = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.ts`;

  console.log(`FFmpeg → ${XC_HOST}/live/***/***/${streamId}.ts`);

  res.setHeader("Content-Type", "video/mp2t");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Access-Control-Allow-Origin", "*");

  const ff = spawn("ffmpeg", [
    "-loglevel", "error",
    "-user_agent", "Mozilla/5.0",
    "-i", xcUrl,
    "-c", "copy",       // zero transcoding — pure remux
    "-f", "mpegts",
    "pipe:1",
  ]);

  ff.stdout.pipe(res, { end: true });
  ff.stderr.on("data", d => console.error("FFmpeg:", d.toString().trim()));
  ff.on("error", err => { if (!res.headersSent) res.status(502).send(err.message); });
  ff.on("close", () => { if (!res.writableEnded) res.end(); });
  req.on("close", () => ff.kill("SIGKILL"));
});

// ── Favourites ────────────────────────────────────────────────────
app.get("/api/favourites",  (req, res) => res.json(load(FAVOURITES_FILE) || []));
app.post("/api/favourites", (req, res) => { save(FAVOURITES_FILE, req.body); res.json({ ok: true }); });

// ── SPA ───────────────────────────────────────────────────────────
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../static/index.html")));

app.listen(PORT, () => console.log(`IPTV Player on :${PORT}  XC-Menu: ${XC_HOST}`));
