"use strict";
const express=require("express"),path=require("path"),fs=require("fs"),
  http=require("http"),https=require("https"),
  {spawn,spawnSync}=require("child_process"),os=require("os");

const app=express();
const PORT=process.env.PORT||8080;
const DATA_DIR=process.env.DATA_DIR||path.join(__dirname,"../data");
const XC_HOST=(process.env.XC_HOST||"http://192.168.1.124:3000").replace(/\/+$/,"");
const HLS_DIR=path.join(os.tmpdir(),"iptv-hls");
[DATA_DIR,HLS_DIR].forEach(d=>{if(!fs.existsSync(d))fs.mkdirSync(d,{recursive:true});});
app.use(express.json({limit:"10mb"}));

// ── Config ────────────────────────────────────────────────────────
const UA_MAP={chrome:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",vlc:"VLC/3.0.20",tivimate:"TiviMate/4.7.0"};
let CFG={
  ua:UA_MAP.chrome,
  segSecs:2, prebuf:2, window:10, idle:20000, stallRestart:10000,
  forwardPad:3, backPad:2,
  forceAac:false, audioBr:192, audioSr:48000, aresample:true, audioPrebuf:4,
  safariTranscode:true, safariProfile:"baseline", safariPreset:"ultrafast", safariVbr:0,
  genpts:true, discardCorrupt:true, ffmpegInput:[], ffmpegExtra:[],
};

// ── Helpers ───────────────────────────────────────────────────────
const ufile=(u,t)=>path.join(DATA_DIR,t+"_"+u.replace(/[^a-zA-Z0-9_\-.]/g,"_")+".json");
const ruser=(u,t,d)=>{try{return JSON.parse(fs.readFileSync(ufile(u,t),"utf8"));}catch(_){return d;}};
const wuser=(u,t,d)=>fs.writeFileSync(ufile(u,t),JSON.stringify(d));

async function xfetch(url,ms=15000){
  return new Promise((resolve,reject)=>{
    const p=new URL(url),lib=p.protocol==="https:"?https:http;
    const req=lib.request({hostname:p.hostname,port:p.port||(p.protocol==="https:"?443:80),path:p.pathname+p.search,method:"GET",headers:{"User-Agent":"Mozilla/5.0"}},res=>{
      let b="";res.on("data",c=>b+=c);res.on("end",()=>{try{resolve(JSON.parse(b));}catch(_){reject(new Error("Non-JSON "+res.statusCode));}});
    });
    req.on("error",reject);req.setTimeout(ms,()=>{req.destroy();reject(new Error("Timeout"));});req.end();
  });
}
function xurl(u,p,action,extra={}){
  const url=new URL(XC_HOST+"/player_api.php");
  url.searchParams.set("username",u);url.searchParams.set("password",p);
  if(action)url.searchParams.set("action",action);
  Object.entries(extra).forEach(([k,v])=>url.searchParams.set(k,v));
  return url.toString();
}
function fflags(){
  const f=[];if(CFG.genpts)f.push("genpts");if(CFG.discardCorrupt)f.push("discardcorrupt");
  return f.length?"+"+f.join("+"):"+genpts";
}
function detectStream(url){
  const r=spawnSync("ffprobe",["-v","quiet","-user_agent","Mozilla/5.0","-show_entries","stream=codec_type,r_frame_rate","-of","json",url],{timeout:6000,encoding:"utf8"});
  try{
    const streams=(JSON.parse(r.stdout||"{}").streams)||[];
    const v=streams.find(s=>s.codec_type==="video");
    const a=streams.find(s=>s.codec_type==="audio");
    let fps=25;
    if(v&&v.r_frame_rate){const[n,d]=v.r_frame_rate.split("/").map(Number);if(d>0)fps=Math.round(n/d);}
    return{hasVideo:!!v,hasAudio:!!a,fps};
  }catch(_){return{hasVideo:true,hasAudio:true,fps:25};}
}

// ── Custom command ────────────────────────────────────────────────
const DEF_CMD=path.join(__dirname,"ffmpeg-default.txt");
const CUS_CMD=path.join(DATA_DIR,"ffmpeg-custom.txt");
let CUSTOM=null;
function readCmd(){try{return fs.readFileSync(CUS_CMD,"utf8");}catch(_){}try{return fs.readFileSync(DEF_CMD,"utf8");}catch(_){return "";}}
function parseCmd(tmpl,vars){
  let cmd=tmpl.replace(/\{(\w+)\}/g,(_,k)=>vars[k]!==undefined?vars[k]:"{"+k+"}");
  cmd=cmd.replace(/^\s*ffmpeg\s*/,"");
  const lines=cmd.split("\n"),joined=[];
  for(const line of lines){if(line.trimEnd().endsWith("\\"))joined.push(line.trimEnd().slice(0,-1)+" ");else joined.push(line+" ");}
  cmd=joined.join("").trim();
  const args=[];let pos=0;
  while(pos<cmd.length){
    while(pos<cmd.length&&cmd[pos]===" ")pos++;if(pos>=cmd.length)break;if(cmd[pos]==="#")break;
    if(cmd[pos]==='"'){const e=cmd.indexOf('"',pos+1);args.push(cmd.slice(pos+1,e===-1?cmd.length:e));pos=(e===-1?cmd.length:e)+1;}
    else{const e=cmd.indexOf(" ",pos);args.push(cmd.slice(pos,e===-1?cmd.length:e));pos=e===-1?cmd.length:e;}
  }
  return args.filter(a=>a.length>0);
}

// ── ffmpeg ────────────────────────────────────────────────────────
function spawnFfmpeg(xcUrl,info,dir,m3u8,startNum,safari){
  startNum=startNum||0;
  const audioOnly=info&&info.hasAudio&&!info.hasVideo;
  const fps=info&&info.fps||25;

  if(CUSTOM){
    const vars={STREAM_URL:xcUrl,ua:CFG.ua,audioBr:CFG.audioBr+"k",audioSr:String(CFG.audioSr),segSecs:String(CFG.segSecs),window:String(CFG.window)};
    let args=parseCmd(CUSTOM,vars).map(a=>{
      if(a==="./seg%06d.ts"||a.endsWith("/seg%06d.ts"))return path.join(dir,"seg%06d.ts");
      if(a==="./index.m3u8"||a==="index.m3u8")return m3u8;
      if(a==="<STREAM_URL>")return xcUrl;return a;
    });
    if(!args.includes("-start_number")&&startNum){const i=args.lastIndexOf(m3u8);if(i>-1)args.splice(i,0,"-start_number",String(startNum));}
    const si=args.indexOf("-hls_segment_filename");
    if(si>-1&&args[si+1]&&!path.isAbsolute(args[si+1]))args[si+1]=path.join(dir,"seg%06d.ts");
    return spawn("ffmpeg",args);
  }

  // ── Input flags ───────────────────────────────────────────────
  // These are applied BEFORE -i and affect how the source is opened.
  // Order matters: reconnect flags must come before -i.
  //
  // -reconnect 1                  Auto-reconnect on HTTP drop
  // -reconnect_streamed 1         Reconnect even on streamed (live) sources
  // -reconnect_on_network_error 1 Reconnect on TCP errors, not just HTTP
  // -reconnect_delay_max 5        Wait max 5s between reconnect attempts
  // -rw_timeout 10000000          Declare stream dead after 10s silence (µs)
  //                               10s is better than 15s — faster recovery
  // -thread_queue_size 4096       Input packet queue depth — absorbs jitter
  //                               from variable-bitrate live streams
  // -fflags +genpts               Re-generate PTS if missing/wrong
  //                               IPTV streams commonly have broken timestamps
  // -fflags +discardcorrupt       Skip corrupt packets silently vs crashing
  // -analyzeduration 1000000      1s to analyze stream format (µs)
  // -probesize 1000000            1MB probe — fast but enough for IPTV
  const inputArgs = [
    "-hide_banner", "-loglevel",          "error",
    "-reconnect",                         "1",
    "-reconnect_streamed",                "1",
    "-reconnect_on_network_error",        "1",
    "-reconnect_delay_max",               "5",
    "-rw_timeout",                        "10000000",
    "-thread_queue_size",                 "4096",
    "-analyzeduration",                   "1000000",
    "-probesize",                         "1000000",
    "-fflags",                            "+genpts+discardcorrupt",
    "-user_agent",                        CFG.ua,
    ...CFG.ffmpegInput,
    "-i",                                 xcUrl,
  ];

  // ── HLS output flags ──────────────────────────────────────────
  // independent_segments  Every segment decodable without prior segments
  //                       Critical — browsers must be able to start from any seg
  // omit_endlist          Never write EXT-X-ENDLIST (stream stays "live" forever)
  // append_list           Append to playlist rather than rewrite it
  //                       Smoother playlist updates, no momentary 404s
  // delete_segments       Remove segments older than window from disk
  // hls_allow_cache 0     Tell browser: never cache segments (always fresh)
  //
  // Safari gets a short list_size (4 segs) because its native HLS player
  // eagerly pre-buffers every segment in the playlist before reporting "ready".
  // 10 segs × 2s = 20s buffered = massive startup lag then catch-up stutter.
  // 4 segs × 2s = 8s — enough for smooth playback, no catch-up needed.
  const safariListSize = Math.min(4, CFG.window);
  const listSize = (safari && CFG.safariTranscode) ? safariListSize : CFG.window;

  const hlsArgs = [
    "-f",                    "hls",
    "-hls_time",             String(CFG.segSecs),
    "-hls_list_size",        String(listSize),
    "-hls_delete_threshold", String(Math.max(3, CFG.backPad)),
    "-hls_flags",            "delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_allow_cache",      "0",
    "-hls_segment_type",     "mpegts",
    "-hls_segment_filename", path.join(dir, "seg%06d.ts"),
    "-start_number",         String(startNum),
    m3u8,
  ];

  // ── Path 1: Safari / iOS — H.264 + AAC-LC transcode ──────────
  //
  // Safari's native HLS player requires specific encoding:
  //   H.264 Baseline 3.1 — widest device support, no B-frames
  //   AAC-LC (aac_low)   — NOT HE-AAC which causes Safari stalls
  //   IDR at segment boundaries — Safari cannot decode a segment that
  //                               doesn't start with an IDR frame
  //   -g = fps × segSecs        — GOP exactly one segment long
  //   -sc_threshold 0           — No extra keyframes on scene cuts
  //                               (would break IDR alignment)
  //   -bf 0                     — No B-frames (Baseline forbids them)
  //   -tune zerolatency         — Minimises encoder buffering delay
  //
  // Audio: 192k AAC-LC stereo at 48kHz — universally supported
  if (safari && CFG.safariTranscode) {
    const gop   = Math.round(fps * CFG.segSecs);
    const level = CFG.safariProfile === "baseline" ? "3.1"
                : CFG.safariProfile === "main"     ? "4.0" : "4.1";
    const vbr   = CFG.safariVbr > 0 ? ["-b:v", CFG.safariVbr+"k"] : [];
    console.log(`[ff:safari] ${CFG.safariProfile}/${level} fps=${fps} gop=${gop} seg=${CFG.segSecs}s`);
    return spawn("ffmpeg", [
      ...inputArgs,
      "-map",          "0:v:0",
      "-map",          "0:a:0",
      // Video
      "-c:v",          "libx264",
      "-profile:v",    CFG.safariProfile,
      "-level",        level,
      "-preset",       CFG.safariPreset,
      "-tune",         "zerolatency",
      "-g",            String(gop),
      "-keyint_min",   String(gop),
      "-forced_idr",   "1",
      "-sc_threshold", "0",
      "-bf",           "0",
      ...vbr,
      // Audio
      "-c:a",          "aac",
      "-profile:a",    "aac_low",
      "-b:a",          CFG.audioBr+"k",
      "-ar",           String(CFG.audioSr),
      "-ac",           "2",
      ...CFG.ffmpegExtra,
      ...hlsArgs,
    ]);
  }

  // ── Path 2: Audio-only — radio / SiriusXM ─────────────────────
  //
  // Radio streams (SiriusXM etc.) have highly variable timing — gaps,
  // duplicated frames, timestamp jumps. aresample fixes all of these:
  //   async=1000        — absorb up to 1000 samples of timing error
  //                       without artifacts (vs async=1 which artifacts)
  //   min_hard_comp=0.1 — only hard-compensate gaps >100ms
  //                       smaller gaps are handled gracefully by interpolation
  //   first_pts=0       — reset PTS to 0 so HLS.js sees clean timestamps
  //                       from the first segment
  //
  // -vn                 Strip video entirely (radio has none)
  // AAC-LC 192k stereo  Best quality for audio-only HLS
  if (audioOnly) {
    const af = CFG.aresample
      ? ["-af", "aresample=async=1000:min_hard_comp=0.100:first_pts=0"]
      : [];
    console.log("[ff:audio] audio-only stream");
    return spawn("ffmpeg", [
      ...inputArgs,
      "-vn",
      "-map",       "0:a:0",
      "-c:a",       "aac",
      "-profile:a", "aac_low",
      "-b:a",       CFG.audioBr+"k",
      "-ar",        String(CFG.audioSr),
      "-ac",        "2",
      ...af,
      ...CFG.ffmpegExtra,
      ...hlsArgs,
    ]);
  }

  // ── Path 3: Standard video — copy video, transcode audio ──────
  //
  // This is the best path for most IPTV streams:
  //   -c:v copy      Zero re-encode — no CPU, no quality loss, instant start
  //                  The source H.264/H.265 is passed straight through
  //   -c:a aac       Transcode audio to AAC-LC for browser compatibility
  //                  HLS.js requires AAC — AC3/EAC3/MP3 not supported in MSE
  //
  // aresample=async=1 — fix small PTS drift caused by video copy vs audio
  //                     transcode running at slightly different rates.
  //                     async=1 (not 1000) because video streams don't have
  //                     the large gaps that radio streams do.
  //   first_pts=0     — ensures first audio segment starts at PTS 0
  //
  // Audio: 192k 48kHz stereo — matches most source material sample rates
  const af = CFG.aresample ? ["-af", "aresample=async=1:first_pts=0"] : [];
  console.log(`[ff:video] copy-v/aac-a seg=${CFG.segSecs}s`);
  return spawn("ffmpeg", [
    ...inputArgs,
    "-map",       "0:v:0",
    "-map",       "0:a:0",
    // Video: pass through unchanged
    "-c:v",       "copy",
    // Audio: transcode to AAC-LC
    "-c:a",       "aac",
    "-profile:a", "aac_low",
    "-b:a",       CFG.audioBr+"k",
    "-ar",        String(CFG.audioSr),
    "-ac",        "2",
    ...af,
    ...CFG.ffmpegExtra,
    ...hlsArgs,
  ]);
}
// ── Sessions ──────────────────────────────────────────────────────
const sessions=new Map();
const segCount=dir=>{try{return fs.readdirSync(dir).filter(f=>f.endsWith(".ts")).length;}catch(_){return 0;}};
function killSession(sid){
  const s=sessions.get(sid);if(!s)return;s.dead=true;
  clearTimeout(s.idleTimer);clearInterval(s.watchdog);
  try{s.ff.kill("SIGKILL");}catch(_){}
  try{if(fs.existsSync(s.dir)){fs.readdirSync(s.dir).forEach(f=>{try{fs.unlinkSync(path.join(s.dir,f));}catch(_){}});fs.rmdirSync(s.dir);}}catch(_){}
  sessions.delete(sid);
}
function resetIdle(sid){const s=sessions.get(sid);if(!s)return;clearTimeout(s.idleTimer);s.idleTimer=setTimeout(()=>killSession(sid),CFG.idle);}

// ── API ───────────────────────────────────────────────────────────
app.post("/api/login",async(req,res)=>{
  const{username,password}=req.body||{};if(!username||!password)return res.status(400).json({error:"Missing credentials"});
  try{
    const d=await xfetch(xurl(username,password,null));
    if(d.user_info&&d.user_info.auth==1)res.json({ok:true,status:d.user_info.status,expiry:d.user_info.exp_date,connections:d.user_info.active_cons+"/"+d.user_info.max_connections});
    else res.status(401).json({error:"Invalid credentials"});
  }catch(e){res.status(502).json({error:e.message});}
});

const ALLOWED=new Set(["get_live_categories","get_live_streams","get_vod_categories","get_vod_streams","get_short_epg","get_epg"]);
app.get("/api/xc/:action",async(req,res)=>{
  const{username,password}=req.query;if(!username||!password)return res.status(401).json({error:"Missing credentials"});
  const{action}=req.params;if(!ALLOWED.has(action))return res.status(403).json({error:"Not allowed"});
  const extra={};Object.entries(req.query).forEach(([k,v])=>{if(k!=="username"&&k!=="password")extra[k]=v;});
  try{res.json(await xfetch(xurl(username,password,action,extra)));}catch(e){res.status(502).json({error:e.message});}
});

app.get("/api/epg/:id",async(req,res)=>{
  const{username,password}=req.query;if(!username||!password)return res.status(401).json({error:"Missing credentials"});
  try{res.json(await xfetch(xurl(username,password,"get_short_epg",{stream_id:req.params.id,limit:8})));}catch(_){res.json({epg_listings:[]});}
});

app.get("/api/favs/:u",(req,res)=>res.json(ruser(req.params.u.trim(),"favs",[])));
app.post("/api/favs/:u",(req,res)=>{wuser(req.params.u.trim(),"favs",Array.isArray(req.body)?req.body:[]);res.json({ok:true});});
app.get("/api/prefs/:u",(req,res)=>res.json(ruser(req.params.u.trim(),"prefs",{timezone:"America/Toronto"})));
app.post("/api/prefs/:u",(req,res)=>{wuser(req.params.u.trim(),"prefs",req.body||{});res.json({ok:true});});

app.post("/api/settings",(req,res)=>{
  const s=req.body||{};
  const pl=v=>typeof v==="string"&&v.trim()?v.trim().split(/\s+/).filter(Boolean):[];
  const bool=(v,d)=>v===undefined?d:(v!==false&&v!=="false"&&v!=="0");
  const int=(v,d,m=0)=>Math.max(m,parseInt(v)||d);
  CFG.ua=UA_MAP[s.ua]||UA_MAP.chrome;
  CFG.segSecs=int(s.segSecs,2,1);CFG.prebuf=int(s.prebuf,2,1);CFG.window=int(s.window,10,5);
  CFG.idle=int(s.idle,20,5)*1000;CFG.stallRestart=int(s.stallRestart,10,2)*1000;
  CFG.forwardPad=int(s.forwardPad,3,1);CFG.backPad=int(s.backPad,2,0);
  CFG.forceAac=bool(s.forceAac,false);CFG.audioBr=int(s.audioBr,192,64);
  CFG.audioSr=s.audioSr==="44100"?44100:48000;
  CFG.aresample=bool(s.aresample,true);CFG.audioPrebuf=int(s.audioPrebuf,4,1);
  CFG.safariTranscode=bool(s.safariTranscode,true);
  CFG.safariProfile=["baseline","main","high"].includes(s.safariProfile)?s.safariProfile:"baseline";
  CFG.safariPreset=["ultrafast","superfast","veryfast","faster"].includes(s.safariPreset)?s.safariPreset:"ultrafast";
  CFG.safariVbr=int(s.safariVbr,0,0);
  CFG.genpts=bool(s.genpts,true);CFG.discardCorrupt=bool(s.discardCorrupt,true);
  CFG.ffmpegInput=pl(s.ffmpegInput);CFG.ffmpegExtra=pl(s.ffmpegExtra);
  console.log("[settings]",JSON.stringify(CFG));
  res.json({ok:true});
});

app.get("/api/ffcmd",(req,res)=>{
  const cmd=["ffmpeg","-hide_banner","-loglevel","error","-reconnect","1","-user_agent",CFG.ua,"-i","<stream_url>","-map","0:v:0","-map","0:a:0","-c:v","copy","-c:a","aac","-profile:a","aac_low","-b:a",CFG.audioBr+"k","-ar",String(CFG.audioSr),"-ac","2","-fflags",fflags(),"-f","hls","-hls_time",String(CFG.segSecs),"-hls_list_size",String(CFG.window),"-hls_flags","delete_segments+append_list+omit_endlist+independent_segments","-hls_segment_type","mpegts","-hls_segment_filename","<dir>/seg%06d.ts","<dir>/index.m3u8"];
  res.json({cmd,cmdStr:cmd.join(" ")});
});

app.get("/api/ffcmd/custom",(req,res)=>{
  const current=readCmd(),isCustom=!!CUSTOM;
  try{res.json({current,default:fs.readFileSync(DEF_CMD,"utf8"),isCustom});}catch(_){res.json({current,default:current,isCustom});}
});
app.post("/api/ffcmd/custom",(req,res)=>{
  const{cmd,enabled}=req.body||{};
  if(typeof cmd==="string"){fs.writeFileSync(CUS_CMD,cmd);CUSTOM=enabled!==false?cmd:null;}else{CUSTOM=enabled!==false?readCmd():null;}
  res.json({ok:true,enabled:!!CUSTOM});
});
app.post("/api/ffcmd/reset",(req,res)=>{
  try{fs.unlinkSync(CUS_CMD);}catch(_){}CUSTOM=null;
  res.json({ok:true,default:fs.existsSync(DEF_CMD)?fs.readFileSync(DEF_CMD,"utf8"):""});
});

app.post("/api/stream/start",(req,res)=>{
  const{username,password,streamId,sessionId:old,safari}=req.body||{};
  if(!username||!password||!streamId)return res.status(400).json({error:"Missing params"});
  if(old)killSession(old);

  const sid=Date.now().toString(36)+Math.random().toString(36).slice(2);
  const dir=path.join(HLS_DIR,sid);
  const m3u8=path.join(dir,"index.m3u8");
  fs.mkdirSync(dir,{recursive:true});

  const urlTs=`${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.ts`;
  const urlM3u8=`${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.m3u8`;

  let info=detectStream(urlTs);
  const xcUrl=(info.hasVideo||info.hasAudio)?urlTs:urlM3u8;
  if(xcUrl===urlM3u8)info=detectStream(urlM3u8);
  const audioOnly=info.hasAudio&&!info.hasVideo;
  console.log(`[stream] ${sid.slice(0,8)} → ${streamId} video=${info.hasVideo} audio=${info.hasAudio} safari=${!!safari}`);

  const SKIP=/frame size not set|PES packet|Packet corrupt|Last message repeated|non monotonous|non-existing SPS|non-existing PPS|no frame!|Could not find ref|Error constructing|\[h264 @|\[hevc @|\[aac @|\[mp3 @/i;
  let ff=spawnFfmpeg(xcUrl,info,dir,m3u8,0,safari);
  ff.stderr.on("data",d=>{const m=d.toString().trim();if(m&&!SKIP.test(m))console.error(`[ff:${sid.slice(0,8)}]`,m);});

  const restart=(code)=>{
    const s=sessions.get(sid);if(!s||s.dead)return;
    const next=segCount(dir);
    ff=spawnFfmpeg(xcUrl,info,dir,m3u8,next,safari);
    ff.stderr.on("data",d=>{const m=d.toString().trim();if(m&&!SKIP.test(m))console.error(`[ff:${sid.slice(0,8)}]`,m);});
    ff.on("close",restart);s.ff=ff;
  };
  ff.on("close",restart);ff.on("error",e=>console.error("[ff] spawn:",e.message));

  // Watchdog: restart if no new segments for stallRestart ms
  let lastN=0,lastT=Date.now(),armed=false;
  const watchdog=setInterval(()=>{
    const s=sessions.get(sid);if(!s||s.dead){clearInterval(watchdog);return;}
    const n=segCount(dir);
    if(n>lastN){lastN=n;lastT=Date.now();if(n>=CFG.prebuf)armed=true;}
    else if(armed&&Date.now()-lastT>CFG.stallRestart){lastT=Date.now();try{s.ff.kill("SIGKILL");}catch(_){}}
  },1000);

  const idleTimer=setTimeout(()=>killSession(sid),CFG.idle);
  sessions.set(sid,{ff,dir,idleTimer,watchdog,dead:false});

  // Safari needs more pre-buffered segments before playback starts
  // (native player is strict about having full segments ready)
  const prebuf = audioOnly ? CFG.audioPrebuf
               : (safari && CFG.safariTranscode) ? Math.max(CFG.prebuf, 3)
               : CFG.prebuf;
  const t0=Date.now();
  const poll=setInterval(()=>{
    if(!sessions.has(sid)){clearInterval(poll);if(!res.headersSent)res.status(502).json({error:"Stream failed"});return;}
    if(segCount(dir)>=prebuf&&fs.existsSync(m3u8)&&fs.statSync(m3u8).size>0){
      clearInterval(poll);
      console.log(`[stream] ${sid.slice(0,8)} ready (${segCount(dir)} segs)`);
      res.json({ok:true,sessionId:sid,url:`/hls/${sid}/index.m3u8`,audioOnly,
        hlsCfg:{segSecs:CFG.segSecs,forwardPad:CFG.forwardPad,backPad:CFG.backPad,
          prebuf,audioOnly,safari:!!safari}});
    }else if(Date.now()-t0>30000){
      clearInterval(poll);killSession(sid);
      if(!res.headersSent)res.status(504).json({error:"Stream timed out"});
    }
  },300);
});

app.post("/api/stream/heartbeat/:sid",(req,res)=>{
  if(!sessions.has(req.params.sid))return res.status(404).json({error:"Gone"});
  resetIdle(req.params.sid);res.json({ok:true});
});
app.post("/api/stream/stop/:sid",(req,res)=>{killSession(req.params.sid);res.json({ok:true});});
app.post("/api/stream/stopall",(req,res)=>{
  const sids=[...sessions.keys()];sids.forEach(killSession);
  res.json({ok:true,stopped:sids.length});
});

// Serve m3u8 — rewrite relative segment paths to absolute URLs
// Safari gets a trimmed playlist (3 segs) to prevent aggressive pre-buffering
function serveM3u8(fp, sid, res, N){
  // N = max segments to include (0 = all). Safari gets N=3 to prevent over-buffering.
  try {
    const raw = fs.readFileSync(fp, "utf8");
    // Rewrite bare filenames → absolute paths
    const content = raw.replace(/^(seg\d+\.ts)$/mg, "/hls/"+sid+"/$1");

    if (!N) { res.send(content); return; }

    // Parse out header lines and segment pairs (#EXTINF + URL)
    const lines = content.split("\n");
    const headerLines = [];
    const segPairs = [];   // each entry = ["#EXTINF:...,", "/hls/sid/segXXX.ts"]
    let extinf = null;
    for (const line of lines) {
      const t = line.trim();
      if (!t) continue;
      if (t.startsWith("#EXTINF")) {
        extinf = t;
      } else if (extinf) {
        segPairs.push([extinf, t]);
        extinf = null;
      } else {
        headerLines.push(t);
      }
    }

    // Take last N segments
    const keep = segPairs.slice(-N);
    const seqMatch = content.match(/#EXT-X-MEDIA-SEQUENCE:(\d+)/);
    const origSeq  = seqMatch ? parseInt(seqMatch[1]) : 0;
    const newSeq   = origSeq + segPairs.length - keep.length;

    // Rebuild header — replace old MEDIA-SEQUENCE with new one
    const header = headerLines
      .filter(l => !l.startsWith("#EXT-X-MEDIA-SEQUENCE"))
      .join("\n")
      .replace("#EXTM3U", "#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:"+newSeq);

    const body = keep.map(([inf,url]) => inf+"\n"+url).join("\n");
    res.send(header + "\n" + body + "\n");
  } catch(e) {
    console.error("[m3u8]", e.message);
    res.status(500).end();
  }
}

// safari.m3u8 now just serves index.m3u8 — HLS.js handles buffering
app.get("/hls/:sid/safari.m3u8",(req,res)=>{
  const fp=path.join(HLS_DIR,req.params.sid,"index.m3u8");
  if(!fs.existsSync(fp))return res.status(404).send("Not found");
  res.setHeader("Access-Control-Allow-Origin","*");
  res.setHeader("Content-Type","application/vnd.apple.mpegurl");
  res.setHeader("Cache-Control","no-cache, no-store, must-revalidate");
  serveM3u8(fp, req.params.sid, res, 0);
});

app.get("/hls/:sid/:file",(req,res)=>{
  const fp=path.join(HLS_DIR,req.params.sid,req.params.file);
  if(!fs.existsSync(fp))return res.status(404).send("Not found");
  res.setHeader("Access-Control-Allow-Origin","*");
  if(req.params.file.endsWith(".m3u8")){
    res.setHeader("Content-Type","application/vnd.apple.mpegurl");
    res.setHeader("Cache-Control","no-cache, no-store, must-revalidate");
    res.setHeader("Pragma","no-cache");
    serveM3u8(fp, req.params.sid, res, 0);
  }else{
    res.setHeader("Content-Type","video/mp2t");
    res.setHeader("Cache-Control","public, max-age=30");
    res.sendFile(fp);
  }
});

app.get("/logo",async(req,res)=>{
  const url=req.query.url;if(!url||!/^https?:\/\//i.test(url))return res.status(400).end();
  try{
    const p=new URL(url),lib=p.protocol==="https:"?https:http;
    const r=lib.request({hostname:p.hostname,port:p.port||(p.protocol==="https:"?443:80),path:p.pathname+p.search,method:"GET",headers:{"User-Agent":"Mozilla/5.0","Accept":"image/*,*/*"}},pr=>{
      res.setHeader("Content-Type",pr.headers["content-type"]||"image/png");res.setHeader("Cache-Control","public,max-age=86400");pr.pipe(res,{end:true});
    });
    r.on("error",()=>res.status(502).end());r.setTimeout(5000,()=>{r.destroy();res.status(504).end();});r.end();
  }catch(_){res.status(400).end();}
});

app.use(express.static(path.join(__dirname,"../static")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../static/index.html")));
process.on("SIGTERM",()=>{[...sessions.keys()].forEach(killSession);process.exit(0);});
app.listen(PORT,()=>console.log(`Stream :${PORT}  XC: ${XC_HOST}`));
