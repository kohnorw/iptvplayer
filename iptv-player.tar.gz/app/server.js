"use strict";

const express = require("express");
const http    = require("http");
const https   = require("https");
const path    = require("path");
const fs      = require("fs");

const app      = express();
const PORT     = process.env.PORT || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const SETTINGS_FILE   = path.join(DATA_DIR, "settings.json");
const FAVOURITES_FILE = path.join(DATA_DIR, "favourites.json");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "../static")));

function load(file)       { try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch(_){ return null; } }
function save(file, data) { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }

app.get("/api/settings", (req, res) => res.json(load(SETTINGS_FILE) || {}));

app.post("/api/settings", (req, res) => {
  let { host, username, password } = req.body || {};
  if (!host || !username || !password)
    return res.status(400).json({ error: "host, username, password required" });
  host = host.trim().replace(/\/+$/, "");
  if (!/^https?:\/\//i.test(host)) host = "http://" + host;
  save(SETTINGS_FILE, { host, username: username.trim(), password: password.trim() });
  res.json({ ok: true });
});

app.get("/api/favourites",  (req, res) => res.json(load(FAVOURITES_FILE) || []));
app.post("/api/favourites", (req, res) => { save(FAVOURITES_FILE, req.body); res.json({ ok: true }); });

// Stream proxy - only video bytes proxied here
// All XC API calls go browser -> XC-Menu directly (avoids IP allowlist issues)
app.get("/proxy/stream/:type/:id", (req, res) => {
  const s = load(SETTINGS_FILE);
  if (!s || !s.host) return res.status(401).send("Not configured");
  const { type, id } = req.params;
  const dot      = id.lastIndexOf(".");
  const streamId = dot > 0 ? id.slice(0, dot) : id;
  const ext      = dot > 0 ? id.slice(dot + 1) : "ts";
  pipeStream(`${s.host}/${type}/${s.username}/${s.password}/${streamId}.${ext}`, req, res);
});

function pipeStream(targetUrl, req, res) {
  let parsed;
  try { parsed = new URL(targetUrl); } catch(_){ return res.status(400).send("Bad URL"); }
  const lib  = parsed.protocol === "https:" ? https : http;
  const opts = {
    hostname: parsed.hostname,
    port:     parsed.port || (parsed.protocol === "https:" ? 443 : 80),
    path:     parsed.pathname + parsed.search,
    method:   "GET",
    headers:  { "User-Agent": "Mozilla/5.0", Range: req.headers.range || "" },
  };
  const up = lib.request(opts, (uRes) => {
    const fwd  = ["content-type","content-length","content-range","accept-ranges","cache-control"];
    const hdrs = { "Access-Control-Allow-Origin": "*" };
    fwd.forEach(h => { if (uRes.headers[h]) hdrs[h] = uRes.headers[h]; });
    res.writeHead(uRes.statusCode, hdrs);
    uRes.pipe(res, { end: true });
  });
  up.on("error", err => { if (!res.headersSent) res.status(502).send(err.message); });
  req.on("close", () => up.destroy());
  up.end();
}

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../static/index.html")));

app.listen(PORT, () => console.log(`IPTV Player on http://localhost:${PORT}  data=${DATA_DIR}`));
