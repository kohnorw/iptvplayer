"use strict";
const express  = require("express");
const path     = require("path");
const fs       = require("fs");
const http     = require("http");
const https    = require("https");
const os       = require("os");
const { spawn, spawnSync } = require("child_process");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
const XC_HOST  = (process.env.XC_HOST || "http://192.168.1.124:3000").replace(/\/+$/, "");
const HLS_DIR  = path.join(os.tmpdir(), "iptv-hls");

[DATA_DIR, HLS_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));
app.use(express.json({ limit: "10mb" }));

// ── Config ────────────────────────────────────────────────────────
const UA = {
  chrome:   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
  vlc:      "VLC/3.0.20 LibVLC/3.0.20",
  tivimate: "TiviMate/4.7.0",
};

let C = {
  ua: UA.chrome,
  segSecs: 2, prebuf: 2, window: 10, idle: 20000, stallRestart: 10000,
  forwardPad: 3, backPad: 2,
  forceAac: false, audioBr: 192, audioSr: 48000, aresample: true, audioPrebuf: 4,
  safariTranscode: true, safariProfile: "baseline", safariPreset: "ultrafast", safariVbr: 0,
  genpts: true, discardCorrupt: true, ffmpegInput: [], ffmpegExtra: [],
};

// ── Helpers ───────────────────────────────────────────────────────
const ufile = (u, t) => path.join(DATA_DIR, `${t}_${u.replace(/[^a-zA-Z0-9_\-.]/g,"_")}.json`);
const ruser = (u, t, d) => { try { return JSON.parse(fs.readFileSync(ufile(u,t),"utf8")); } catch(_) { return d; } };
const wuser = (u, t, d) => fs.writeFileSync(ufile(u,t), JSON.stringify(d));

function xfetch(url, ms=15000) {
  return new Promise((res, rej) => {
    const p = new URL(url), lib = p.protocol === "https:" ? https : http;
    const req = lib.request({
      hostname: p.hostname, port: p.port || (p.protocol === "https:" ? 443 : 80),
      path: p.pathname + p.search, method: "GET", headers: { "User-Agent": "Mozilla/5.0" }
    }, r => {
      let b = ""; r.on("data", c => b += c);
      r.on("end", () => { try { res(JSON.parse(b)); } catch(_) { rej(new Error("Non-JSON")); } });
    });
    req.on("error", rej);
    req.setTimeout(ms, () => { req.destroy(); rej(new Error("Timeout")); });
    req.end();
  });
}

function xurl(u, p, action, extra = {}) {
  const url = new URL(`${XC_HOST}/player_api.php`);
  url.searchParams.set("username", u);
  url.searchParams.set("password", p);
  if (action) url.searchParams.set("action", action);
  Object.entries(extra).forEach(([k,v]) => url.searchParams.set(k,v));
  return url.toString();
}

function detectStream(url) {
  const r = spawnSync("ffprobe", [
    "-v", "quiet", "-user_agent", "Mozilla/5.0",
    "-show_entries", "stream=codec_type,r_frame_rate",
    "-of", "json", url
  ], { timeout: 6000, encoding: "utf8" });
  try {
    const streams = (JSON.parse(r.stdout || "{}").streams) || [];
    const v = streams.find(s => s.codec_type === "video");
    const a = streams.find(s => s.codec_type === "audio");
    let fps = 25;
    if (v?.r_frame_rate) {
      const [n,d] = v.r_frame_rate.split("/").map(Number);
      if (d > 0) fps = Math.round(n/d);
    }
    return { hasVideo: !!v, hasAudio: !!a, fps };
  } catch(_) { return { hasVideo: true, hasAudio: true, fps: 25 }; }
}

// ── Custom command ────────────────────────────────────────────────
const DEF_CMD = path.join(__dirname, "ffmpeg-default.txt");
const CUS_CMD = path.join(DATA_DIR, "ffmpeg-custom.txt");
let CUSTOM = null;

function readCmd() {
  try { return fs.readFileSync(CUS_CMD, "utf8"); } catch(_) {}
  try { return fs.readFileSync(DEF_CMD, "utf8"); } catch(_) { return ""; }
}

function parseCmd(tmpl, vars) {
  let cmd = tmpl.replace(/\{(\w+)\}/g, (_,k) => vars[k] ?? `{${k}}`);
  cmd = cmd.replace(/^\s*ffmpeg\s*/, "");
  const lines = cmd.split("\n"), joined = [];
  for (const line of lines)
    joined.push(line.trimEnd().endsWith("\\") ? line.trimEnd().slice(0,-1)+" " : line+" ");
  cmd = joined.join("").trim();
  const args = []; let pos = 0;
  while (pos < cmd.length) {
    while (pos < cmd.length && cmd[pos] === " ") pos++;
    if (pos >= cmd.length || cmd[pos] === "#") break;
    if (cmd[pos] === '"') {
      const e = cmd.indexOf('"', pos+1);
      args.push(cmd.slice(pos+1, e === -1 ? cmd.length : e));
      pos = (e === -1 ? cmd.length : e) + 1;
    } else {
      const e = cmd.indexOf(" ", pos);
      args.push(cmd.slice(pos, e === -1 ? cmd.length : e));
      pos = e === -1 ? cmd.length : e;
    }
  }
  return args.filter(a => a.length > 0);
}

// ── ffmpeg ────────────────────────────────────────────────────────
function spawnFfmpeg(url, info, dir, m3u8, startNum, safari) {
  startNum = startNum || 0;
  const audioOnly = info?.hasAudio && !info?.hasVideo;
  const fps = info?.fps || 25;

  // Custom command override
  if (CUSTOM) {
    const vars = { STREAM_URL: url, ua: C.ua, audioBr: C.audioBr+"k",
      audioSr: String(C.audioSr), segSecs: String(C.segSecs), window: String(C.window) };
    let args = parseCmd(CUSTOM, vars).map(a => {
      if (a === "./seg%06d.ts" || a.endsWith("/seg%06d.ts")) return path.join(dir,"seg%06d.ts");
      if (a === "./index.m3u8" || a === "index.m3u8") return m3u8;
      if (a === "<STREAM_URL>") return url;
      return a;
    });
    if (!args.includes("-start_number") && startNum) {
      const i = args.lastIndexOf(m3u8);
      if (i > -1) args.splice(i, 0, "-start_number", String(startNum));
    }
    const si = args.indexOf("-hls_segment_filename");
    if (si > -1 && args[si+1] && !path.isAbsolute(args[si+1]))
      args[si+1] = path.join(dir, "seg%06d.ts");
    return spawn("ffmpeg", args);
  }

  // Input flags — applied before -i
  // These settings are proven for IPTV live streams:
  const fflags = [
    C.genpts        ? "genpts"        : null,
    C.discardCorrupt? "discardcorrupt": null,
  ].filter(Boolean).join("+");

  const inputArgs = [
    "-hide_banner", "-loglevel",            "error",
    "-reconnect",                           "1",
    "-reconnect_streamed",                  "1",
    "-reconnect_on_network_error",          "1",
    "-reconnect_delay_max",                 "5",
    "-rw_timeout",                          "10000000",   // 10s
    "-thread_queue_size",                   "4096",
    "-analyzeduration",                     "1000000",    // 1s
    "-probesize",                           "1000000",    // 1MB
    ...(fflags ? ["-fflags", "+"+fflags] : []),
    "-user_agent",                          C.ua,
    ...C.ffmpegInput,
    "-i",                                   url,
  ];

  // HLS output flags
  // Safari native player buffers the entire playlist eagerly.
  // Short window (4 segs) = ~8s pre-buffered, no catch-up stutter.
  const safariListSize = Math.min(4, C.window);
  const listSize = (safari && C.safariTranscode) ? safariListSize : C.window;

  const hlsArgs = [
    "-f",                    "hls",
    "-hls_time",             String(C.segSecs),
    "-hls_list_size",        String(listSize),
    "-hls_delete_threshold", String(Math.max(3, C.backPad)),
    "-hls_flags",            "delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_allow_cache",      "0",
    "-hls_segment_type",     "mpegts",
    "-hls_segment_filename", path.join(dir, "seg%06d.ts"),
    "-start_number",         String(startNum),
    m3u8,
  ];

  // ── Safari/iOS: H.264 + AAC-LC ───────────────────────────────
  // Safari native HLS requires IDR frames at every segment boundary.
  // -forced_idr 1 + -g=fps×seg + -sc_threshold 0 guarantees this.
  if (safari && C.safariTranscode) {
    const gop   = Math.round(fps * C.segSecs);
    const level = C.safariProfile === "baseline" ? "3.1"
                : C.safariProfile === "main"     ? "4.0" : "4.1";
    const vbr   = C.safariVbr > 0 ? ["-b:v", C.safariVbr+"k"] : [];
    console.log(`[ff:safari] ${C.safariProfile}/${level} fps=${fps} gop=${gop} seg=${C.segSecs}s`);
    return spawn("ffmpeg", [
      ...inputArgs,
      "-map", "0:v:0", "-map", "0:a:0",
      "-c:v",          "libx264",
      "-profile:v",    C.safariProfile,
      "-level",        level,
      "-preset",       C.safariPreset,
      "-tune",         "zerolatency",
      "-g",            String(gop),
      "-keyint_min",   String(gop),
      "-forced_idr",   "1",
      "-sc_threshold", "0",
      "-bf",           "0",
      ...vbr,
      "-c:a",          "aac",
      "-profile:a",    "aac_low",
      "-b:a",          C.audioBr+"k",
      "-ar",           String(C.audioSr),
      "-ac",           "2",
      ...C.ffmpegExtra,
      ...hlsArgs,
    ]);
  }

  // ── Audio-only: radio / SiriusXM ─────────────────────────────
  // async=1000 absorbs large timing gaps without audible artifacts.
  if (audioOnly) {
    const af = C.aresample
      ? ["-af", "aresample=async=1000:min_hard_comp=0.100:first_pts=0"]
      : [];
    console.log("[ff:audio] audio-only");
    return spawn("ffmpeg", [
      ...inputArgs,
      "-vn", "-map", "0:a:0",
      "-c:a",       "aac",
      "-profile:a", "aac_low",
      "-b:a",       C.audioBr+"k",
      "-ar",        String(C.audioSr),
      "-ac",        "2",
      ...af,
      ...C.ffmpegExtra,
      ...hlsArgs,
    ]);
  }

  // ── Standard video: copy video, transcode audio ───────────────
  // -c:v copy = zero CPU, zero quality loss, instant start.
  // aresample=async=1 fixes PTS drift from copy-v vs transcode-a.
  const af = C.aresample ? ["-af", "aresample=async=1:first_pts=0"] : [];
  console.log(`[ff:video] copy-v/aac-a seg=${C.segSecs}s`);
  return spawn("ffmpeg", [
    ...inputArgs,
    "-map", "0:v:0", "-map", "0:a:0",
    "-c:v",       "copy",
    "-c:a",       "aac",
    "-profile:a", "aac_low",
    "-b:a",       C.audioBr+"k",
    "-ar",        String(C.audioSr),
    "-ac",        "2",
    ...af,
    ...C.ffmpegExtra,
    ...hlsArgs,
  ]);
}

// ── Sessions ──────────────────────────────────────────────────────
const sessions = new Map();
const segCount = dir => {
  try { return fs.readdirSync(dir).filter(f => f.endsWith(".ts")).length; }
  catch(_) { return 0; }
};

function killSession(sid) {
  const s = sessions.get(sid);
  if (!s) return;
  s.dead = true;
  clearTimeout(s.idleTimer);
  clearInterval(s.watchdog);
  try { s.ff.kill("SIGKILL"); } catch(_) {}
  try {
    if (fs.existsSync(s.dir)) {
      fs.readdirSync(s.dir).forEach(f => { try { fs.unlinkSync(path.join(s.dir,f)); } catch(_) {} });
      fs.rmdirSync(s.dir);
    }
  } catch(_) {}
  sessions.delete(sid);
}

function resetIdle(sid) {
  const s = sessions.get(sid);
  if (!s) return;
  clearTimeout(s.idleTimer);
  s.idleTimer = setTimeout(() => killSession(sid), C.idle);
}

// ── Routes ────────────────────────────────────────────────────────
app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "Missing credentials" });
  try {
    const d = await xfetch(xurl(username, password, null));
    if (d.user_info?.auth == 1)
      res.json({ ok: true, status: d.user_info.status, expiry: d.user_info.exp_date,
        connections: `${d.user_info.active_cons}/${d.user_info.max_connections}` });
    else res.status(401).json({ error: "Invalid credentials" });
  } catch(e) { res.status(502).json({ error: e.message }); }
});

const ALLOWED = new Set(["get_live_categories","get_live_streams","get_vod_categories",
  "get_vod_streams","get_short_epg","get_epg"]);

app.get("/api/xc/:action", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  const { action } = req.params;
  if (!ALLOWED.has(action)) return res.status(403).json({ error: "Not allowed" });
  const extra = {};
  Object.entries(req.query).forEach(([k,v]) => { if (k!=="username"&&k!=="password") extra[k]=v; });
  try { res.json(await xfetch(xurl(username, password, action, extra))); }
  catch(e) { res.status(502).json({ error: e.message }); }
});

app.get("/api/epg/:id", async (req, res) => {
  const { username, password } = req.query;
  if (!username || !password) return res.status(401).json({ error: "Missing credentials" });
  try { res.json(await xfetch(xurl(username, password, "get_short_epg", { stream_id: req.params.id, limit: 8 }))); }
  catch(_) { res.json({ epg_listings: [] }); }
});

app.get("/api/favs/:u",  (req,res) => res.json(ruser(req.params.u.trim(),"favs",[])));
app.post("/api/favs/:u", (req,res) => { wuser(req.params.u.trim(),"favs",Array.isArray(req.body)?req.body:[]); res.json({ok:true}); });
app.get("/api/prefs/:u",  (req,res) => res.json(ruser(req.params.u.trim(),"prefs",{timezone:"America/Toronto"})));
app.post("/api/prefs/:u", (req,res) => { wuser(req.params.u.trim(),"prefs",req.body||{}); res.json({ok:true}); });

app.post("/api/settings", (req, res) => {
  const s = req.body || {};
  const pl   = v => typeof v==="string"&&v.trim() ? v.trim().split(/\s+/).filter(Boolean) : [];
  const bool = (v,d) => v===undefined ? d : (v!==false && v!=="false" && v!=="0");
  const int  = (v,d,m=0) => Math.max(m, parseInt(v)||d);
  C.ua             = UA[s.ua] || UA.chrome;
  C.segSecs        = int(s.segSecs,2,1);
  C.prebuf         = int(s.prebuf,2,1);
  C.window         = int(s.window,10,3);
  C.idle           = int(s.idle,20,5) * 1000;
  C.stallRestart   = int(s.stallRestart,10,2) * 1000;
  C.forwardPad     = int(s.forwardPad,3,1);
  C.backPad        = int(s.backPad,2,0);
  C.forceAac       = bool(s.forceAac,false);
  C.audioBr        = int(s.audioBr,192,64);
  C.audioSr        = s.audioSr==="44100" ? 44100 : 48000;
  C.aresample      = bool(s.aresample,true);
  C.audioPrebuf    = int(s.audioPrebuf,4,1);
  C.safariTranscode= bool(s.safariTranscode,true);
  C.safariProfile  = ["baseline","main","high"].includes(s.safariProfile) ? s.safariProfile : "baseline";
  C.safariPreset   = ["ultrafast","superfast","veryfast","faster"].includes(s.safariPreset) ? s.safariPreset : "ultrafast";
  C.safariVbr      = int(s.safariVbr,0,0);
  C.genpts         = bool(s.genpts,true);
  C.discardCorrupt = bool(s.discardCorrupt,true);
  C.ffmpegInput    = pl(s.ffmpegInput);
  C.ffmpegExtra    = pl(s.ffmpegExtra);
  console.log("[settings]", JSON.stringify(C));
  res.json({ ok: true });
});

app.get("/api/ffcmd", (req, res) => {
  const fflags = [C.genpts?"genpts":null, C.discardCorrupt?"discardcorrupt":null].filter(Boolean).join("+");
  const cmd = ["ffmpeg","-hide_banner","-loglevel","error","-reconnect","1","-reconnect_streamed","1",
    "-reconnect_on_network_error","1","-reconnect_delay_max","5","-rw_timeout","10000000",
    "-thread_queue_size","4096","-analyzeduration","1000000","-probesize","1000000",
    ...(fflags?["-fflags","+"+fflags]:[]),"-user_agent",C.ua,"-i","<stream_url>",
    "-map","0:v:0","-map","0:a:0","-c:v","copy","-c:a","aac","-profile:a","aac_low",
    "-b:a",C.audioBr+"k","-ar",String(C.audioSr),"-ac","2",
    "-f","hls","-hls_time",String(C.segSecs),"-hls_list_size",String(C.window),
    "-hls_flags","delete_segments+append_list+omit_endlist+independent_segments",
    "-hls_segment_type","mpegts","-hls_segment_filename","<dir>/seg%06d.ts","<dir>/index.m3u8"];
  res.json({ cmd, cmdStr: cmd.join(" ") });
});

app.get("/api/ffcmd/custom", (req, res) => {
  const current = readCmd(), isCustom = !!CUSTOM;
  try { res.json({ current, default: fs.readFileSync(DEF_CMD,"utf8"), isCustom }); }
  catch(_) { res.json({ current, default: current, isCustom }); }
});
app.post("/api/ffcmd/custom", (req, res) => {
  const { cmd, enabled } = req.body || {};
  if (typeof cmd === "string") { fs.writeFileSync(CUS_CMD, cmd); CUSTOM = enabled!==false ? cmd : null; }
  else { CUSTOM = enabled!==false ? readCmd() : null; }
  res.json({ ok: true, enabled: !!CUSTOM });
});
app.post("/api/ffcmd/reset", (req, res) => {
  try { fs.unlinkSync(CUS_CMD); } catch(_) {}
  CUSTOM = null;
  res.json({ ok: true, default: fs.existsSync(DEF_CMD) ? fs.readFileSync(DEF_CMD,"utf8") : "" });
});

// ── Stream start ──────────────────────────────────────────────────
app.post("/api/stream/start", (req, res) => {
  const { username, password, streamId, sessionId: oldSid, safari } = req.body || {};
  if (!username || !password || !streamId) return res.status(400).json({ error: "Missing params" });
  if (oldSid) killSession(oldSid);

  const sid  = Date.now().toString(36) + Math.random().toString(36).slice(2);
  const dir  = path.join(HLS_DIR, sid);
  const m3u8 = path.join(dir, "index.m3u8");
  fs.mkdirSync(dir, { recursive: true });

  const urlTs   = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.ts`;
  const urlM3u8 = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.m3u8`;

  let info = detectStream(urlTs);
  const xcUrl = (info.hasVideo || info.hasAudio) ? urlTs : urlM3u8;
  if (xcUrl === urlM3u8) info = detectStream(urlM3u8);
  const audioOnly = info.hasAudio && !info.hasVideo;

  console.log(`[stream] ${sid.slice(0,8)} → ${streamId} video=${info.hasVideo} audio=${info.hasAudio} safari=${!!safari}`);

  const SKIP = /frame size not set|PES packet|Packet corrupt|Last message repeated|non monotonous|non-existing SPS|non-existing PPS|no frame!|Could not find ref|Error constructing|\[h264 @|\[hevc @|\[aac @|\[mp3 @/i;

  let ff = spawnFfmpeg(xcUrl, info, dir, m3u8, 0, safari);
  const onErr = d => { const m = d.toString().trim(); if (m && !SKIP.test(m)) console.error(`[ff:${sid.slice(0,8)}]`, m); };
  ff.stderr.on("data", onErr);

  const restart = () => {
    const s = sessions.get(sid);
    if (!s || s.dead) return;
    const next = segCount(dir);
    ff = spawnFfmpeg(xcUrl, info, dir, m3u8, next, safari);
    ff.stderr.on("data", onErr);
    ff.on("close", restart);
    s.ff = ff;
  };
  ff.on("close", restart);
  ff.on("error", e => console.error("[ff] spawn:", e.message));

  // Watchdog: kill ffmpeg if no new segments for stallRestart ms
  let lastN = 0, lastT = Date.now(), armed = false;
  const watchdog = setInterval(() => {
    const s = sessions.get(sid);
    if (!s || s.dead) { clearInterval(watchdog); return; }
    const n = segCount(dir);
    if (n > lastN) { lastN = n; lastT = Date.now(); if (n >= C.prebuf) armed = true; }
    else if (armed && Date.now()-lastT > C.stallRestart) {
      lastT = Date.now();
      try { s.ff.kill("SIGKILL"); } catch(_) {}
    }
  }, 1000);

  const idleTimer = setTimeout(() => killSession(sid), C.idle);
  sessions.set(sid, { ff, dir, idleTimer, watchdog, dead: false });

  // Wait for prebuf segments
  const prebuf = audioOnly ? C.audioPrebuf
               : (safari && C.safariTranscode) ? Math.max(C.prebuf, 3)
               : C.prebuf;
  const t0 = Date.now();
  const poll = setInterval(() => {
    if (!sessions.has(sid)) {
      clearInterval(poll);
      if (!res.headersSent) res.status(502).json({ error: "Stream failed" });
      return;
    }
    if (segCount(dir) >= prebuf && fs.existsSync(m3u8) && fs.statSync(m3u8).size > 0) {
      clearInterval(poll);
      console.log(`[stream] ${sid.slice(0,8)} ready (${segCount(dir)} segs)`);
      res.json({
        ok: true, sessionId: sid,
        url: `/hls/${sid}/index.m3u8`,
        audioOnly,
        hlsCfg: {
          segSecs:    C.segSecs,
          forwardPad: C.forwardPad,
          backPad:    C.backPad,
        },
      });
    } else if (Date.now()-t0 > 30000) {
      clearInterval(poll); killSession(sid);
      if (!res.headersSent) res.status(504).json({ error: "Stream timed out" });
    }
  }, 300);
});

app.post("/api/stream/heartbeat/:sid", (req, res) => {
  if (!sessions.has(req.params.sid)) return res.status(404).json({ error: "Gone" });
  resetIdle(req.params.sid);
  res.json({ ok: true });
});

app.post("/api/stream/stop/:sid", (req, res) => {
  killSession(req.params.sid);
  res.json({ ok: true });
});

app.post("/api/stream/stopall", (req, res) => {
  const sids = [...sessions.keys()];
  sids.forEach(killSession);
  console.log(`[stream] stopped all: ${sids.length}`);
  res.json({ ok: true, stopped: sids.length });
});

// ── HLS serving ───────────────────────────────────────────────────
function serveM3u8(fp, sid, res) {
  try {
    const raw = fs.readFileSync(fp, "utf8");
    res.send(raw.replace(/^(seg\d+\.ts)$/mg, `/hls/${sid}/$1`));
  } catch(_) { res.status(500).end(); }
}

app.get("/hls/:sid/:file", (req, res) => {
  const fp = path.join(HLS_DIR, req.params.sid, req.params.file);
  if (!fs.existsSync(fp)) return res.status(404).send("Not found");
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (req.params.file.endsWith(".m3u8")) {
    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    serveM3u8(fp, req.params.sid, res);
  } else {
    res.setHeader("Content-Type", "video/mp2t");
    res.setHeader("Cache-Control", "public, max-age=30");
    res.sendFile(fp);
  }
});

// ── Logo proxy ────────────────────────────────────────────────────
app.get("/logo", async (req, res) => {
  const url = req.query.url;
  if (!url || !/^https?:\/\//i.test(url)) return res.status(400).end();
  try {
    const p = new URL(url), lib = p.protocol === "https:" ? https : http;
    const r = lib.request({
      hostname: p.hostname, port: p.port||(p.protocol==="https:"?443:80),
      path: p.pathname+p.search, method: "GET",
      headers: { "User-Agent": "Mozilla/5.0", "Accept": "image/*,*/*" }
    }, pr => {
      res.setHeader("Content-Type", pr.headers["content-type"]||"image/png");
      res.setHeader("Cache-Control", "public,max-age=86400");
      pr.pipe(res, { end: true });
    });
    r.on("error", () => res.status(502).end());
    r.setTimeout(5000, () => { r.destroy(); res.status(504).end(); });
    r.end();
  } catch(_) { res.status(400).end(); }
});

// ── Direct stream proxy (no ffmpeg, no lag) ──────────────────────
// For Chrome/Firefox: pipe upstream m3u8/ts through our server for CORS.
// Zero transcoding — browser decodes whatever the upstream sends.
// M3U8 proxy — rewrite line by line to avoid buffering entire playlist in memory
app.get("/proxy/stream", (req, res) => {
  const { user, pass, id } = req.query;
  if (!user || !pass || !id) { console.log("[proxy] missing params"); return res.status(400).end(); }
  const upUrl = `${XC_HOST}/live/${encodeURIComponent(user)}/${encodeURIComponent(pass)}/${id}.m3u8`;
  console.log(`[proxy] ${id} → ${upUrl.slice(-30)}`);
  try {
    const p = new URL(upUrl);
    const lib = p.protocol === "https:" ? https : http;
    const upReq = lib.request({
      hostname: p.hostname, port: p.port || (p.protocol === "https:" ? 443 : 80),
      path: p.pathname + p.search, method: "GET",
      headers: { "User-Agent": "Mozilla/5.0" }
    }, upRes => {
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
      res.setHeader("Cache-Control", "no-cache, no-store");

      // Process line by line — never buffer the whole playlist
      const base = `${XC_HOST}/live/${encodeURIComponent(user)}/${encodeURIComponent(pass)}/`;

      let buf = "";
      upRes.on("data", chunk => {
        buf += chunk.toString();
        const lines = buf.split("\n");
        buf = lines.pop(); // keep incomplete last line
        lines.forEach(line => {
          const t = line.trim();
          if (t.endsWith(".ts")) {
            const full = t.startsWith("http") ? t : base + t;
            res.write(`/proxy/ts?url=${encodeURIComponent(full)}\n`);

          } else {
            res.write(line + "\n");
          }
        });
      });
      upRes.on("end", () => {
        if (buf.trim().endsWith(".ts")) {
          const full = buf.trim().startsWith("http") ? buf.trim() : base + buf.trim();
          res.write(`/proxy/ts?url=${encodeURIComponent(full)}\n`);
        } else if (buf) {
          res.write(buf + "\n");
        }
        res.end();
      });
      upRes.on("error", () => { if (!res.headersSent) res.status(502).end(); else res.end(); });
    });
    upReq.on("error", () => { if (!res.headersSent) res.status(502).end(); });
    upReq.setTimeout(10000, () => { upReq.destroy(); if (!res.headersSent) res.status(504).end(); });
    upReq.end();
  } catch(_) { res.status(500).end(); }
});

// TS segment proxy — pipe directly, never buffer in memory
app.get("/proxy/ts", (req, res) => {
  const url = req.query.url;
  // Also handle direct stream_id requests
  if (!url && req.query.user && req.query.id) {
    req.query.url = `${XC_HOST}/live/${encodeURIComponent(req.query.user)}/${encodeURIComponent(req.query.pass)}/${req.query.id}.ts`;
  }
  if (!url || !/^https?:\/\//i.test(url)) return res.status(400).end();
  try {
    const p = new URL(url);
    const lib = p.protocol === "https:" ? https : http;
    const upReq = lib.request({
      hostname: p.hostname, port: p.port || (p.protocol === "https:" ? 443 : 80),
      path: p.pathname + p.search, method: "GET",
      headers: { "User-Agent": "Mozilla/5.0" }
    }, upRes => {
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Content-Type", "video/mp2t");
      res.setHeader("Cache-Control", "public, max-age=10");
      upRes.pipe(res, { end: true });
    });
    upReq.on("error", () => { if (!res.headersSent) res.status(502).end(); });
    upReq.setTimeout(15000, () => { upReq.destroy(); if (!res.headersSent) res.status(504).end(); });
    upReq.end();
  } catch(_) { res.status(400).end(); }
});

app.use(express.static(path.join(__dirname, "../static")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../static/index.html")));
process.on("SIGTERM", () => { [...sessions.keys()].forEach(killSession); process.exit(0); });
app.listen(PORT, () => console.log(`Stream :${PORT}  XC: ${XC_HOST}`));
