"use strict";

const express              = require("express");
const path                 = require("path");
const fs                   = require("fs");
const http                 = require("http");
const https                = require("https");
const { spawn, spawnSync } = require("child_process");

const app      = express();
const PORT     = process.env.PORT     || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "../data");
const XC_HOST  = (process.env.XC_HOST || "http://192.168.1.124:3000").replace(/\/+$/, "");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
app.use(express.json({ limit: "10mb" }));

// ── Per-user data ─────────────────────────────────────────────────
function userFile(u, type) {
  return path.join(DATA_DIR, `${type}_${u.replace(/[^a-zA-Z0-9_\-\.]/g,"_")}.json`);
}
function readUser(u, type, def) {
  try { return JSON.parse(fs.readFileSync(userFile(u,type),"utf8")); } catch(_){ return def; }
}
function writeUser(u, type, d) { fs.writeFileSync(userFile(u,type), JSON.stringify(d)); }

// ── XC API fetch ──────────────────────────────────────────────────
async function xcFetch(url, ms=15000) {
  return new Promise((resolve, reject) => {
    const p   = new URL(url);
    const lib = p.protocol==="https:" ? https : http;
    const req = lib.request({
      hostname: p.hostname, port: p.port||(p.protocol==="https:"?443:80),
      path: p.pathname+p.search, method: "GET",
      headers: {"User-Agent":"Mozilla/5.0"},
    }, res => {
      let body="";
      res.on("data",c=>body+=c);
      res.on("end",()=>{ try{resolve(JSON.parse(body));}catch(_){reject(new Error(`Non-JSON HTTP ${res.statusCode}`));} });
    });
    req.on("error",reject);
    req.setTimeout(ms,()=>{ req.destroy(); reject(new Error("Timeout")); });
    req.end();
  });
}

function buildXcUrl(u,p,action,extra={}) {
  const url=new URL(`${XC_HOST}/player_api.php`);
  url.searchParams.set("username",u); url.searchParams.set("password",p);
  if (action) url.searchParams.set("action",action);
  for (const [k,v] of Object.entries(extra)) url.searchParams.set(k,v);
  return url.toString();
}

// ── Auth ──────────────────────────────────────────────────────────
app.post("/api/login", async (req,res) => {
  const {username,password}=req.body||{};
  if (!username||!password) return res.status(400).json({error:"username and password required"});
  try {
    const d=await xcFetch(buildXcUrl(username,password,null));
    if (d.user_info&&d.user_info.auth==1) {
      res.json({ok:true,status:d.user_info.status,expiry:d.user_info.exp_date,
        connections:`${d.user_info.active_cons}/${d.user_info.max_connections}`});
    } else { res.status(401).json({error:"Invalid username or password"}); }
  } catch(e){ res.status(502).json({error:"Cannot reach server: "+e.message}); }
});

// ── XC API proxy ──────────────────────────────────────────────────
const ALLOWED=new Set(["get_live_categories","get_live_streams","get_vod_categories","get_vod_streams","get_short_epg","get_epg"]);
app.get("/api/xc/:action", async (req,res) => {
  const {username,password}=req.query;
  if (!username||!password) return res.status(401).json({error:"Missing credentials"});
  const {action}=req.params;
  if (!ALLOWED.has(action)) return res.status(403).json({error:"Not allowed"});
  const extra={};
  for (const [k,v] of Object.entries(req.query)) if (k!=="username"&&k!=="password") extra[k]=v;
  try { res.json(await xcFetch(buildXcUrl(username,password,action,extra))); }
  catch(e){ res.status(502).json({error:e.message}); }
});

app.get("/api/epg/:streamId", async (req,res) => {
  const {username,password}=req.query;
  if (!username||!password) return res.status(401).json({error:"Missing credentials"});
  try { res.json(await xcFetch(buildXcUrl(username,password,"get_short_epg",{stream_id:req.params.streamId,limit:8}))); }
  catch(_){ res.json({epg_listings:[]}); }
});

// ── Favourites + Prefs ────────────────────────────────────────────
app.get("/api/favs/:u",   (req,res)=>res.json(readUser(req.params.u.trim(),"favs",[])));
app.post("/api/favs/:u",  (req,res)=>{ writeUser(req.params.u.trim(),"favs",Array.isArray(req.body)?req.body:[]); res.json({ok:true}); });
app.get("/api/prefs/:u",  (req,res)=>res.json(readUser(req.params.u.trim(),"prefs",{timezone:"America/Toronto"})));
app.post("/api/prefs/:u", (req,res)=>{ writeUser(req.params.u.trim(),"prefs",req.body||{}); res.json({ok:true}); });

// ── Audio detection with caching ──────────────────────────────────
const probeCache = new Map();
const PROBE_TTL  = 3600000; // 1 hour

function detectAudio(url) {
  const cached = probeCache.get(url);
  if (cached && Date.now() - cached.ts < PROBE_TTL) return cached.audioCodec;
  try {
    const r = spawnSync("ffprobe",[
      "-v","error","-user_agent","Mozilla/5.0",
      "-select_streams","a:0",
      "-show_entries","stream=codec_name",
      "-of","default=noprint_wrappers=1:nokey=1", url,
    ],{timeout:8000,encoding:"utf8"});
    const audioCodec = (r.stdout||"").trim().split("\n")[0].toLowerCase();
    probeCache.set(url, {audioCodec, ts:Date.now()});
    return audioCodec;
  } catch(_){ return ""; }
}

// ── Active streams ────────────────────────────────────────────────
const active = new Map();
function killActive(key) {
  const ff = active.get(key);
  if (!ff) return;
  try { ff.kill("SIGKILL"); } catch(_) {}
  active.delete(key);
}

// ── Stream: ffmpeg straight proxy, audio transcode only if needed ─
app.get("/stream/:username/:password/:streamId", (req,res) => {
  const {username,password,streamId} = req.params;
  const key = `${username}_${streamId}`;
  killActive(key);

  const urlTs   = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.ts`;
  const urlM3u8 = `${XC_HOST}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${streamId}.m3u8`;

  // Probe audio codec on .ts, fall back to .m3u8
  let audioCodec = detectAudio(urlTs);
  const xcUrl    = audioCodec ? urlTs : urlM3u8;
  if (!audioCodec) audioCodec = detectAudio(urlM3u8);

  const UNSUPPORTED = ["ac3","eac3","mp2","dts","truehd","mlp","pcm"];
  const needsTranscode = UNSUPPORTED.some(c=>audioCodec.includes(c));

  console.log(`[stream] ${key} audio="${audioCodec||"?"}" transcode=${needsTranscode}`);

  res.setHeader("Content-Type","video/mp2t");
  res.setHeader("Cache-Control","no-cache");
  res.setHeader("Access-Control-Allow-Origin","*");
  res.setHeader("X-Accel-Buffering","no");

  // ffmpeg: straight passthrough (-c:v copy -c:a copy) or transcode audio if unsupported
  const ff = spawn("ffmpeg",[
    "-user_agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "-i",          xcUrl,
    "-c:v",        "copy",
    "-c:a",        needsTranscode ? "aac" : "copy",
    ...(needsTranscode ? ["-b:a","192k","-ar","48000","-ac","2"] : []),
    "-f",          "mpegts",
    "pipe:1",
  ]);

  active.set(key, ff);
  ff.stdout.pipe(res, {end:true});

  ff.stderr.on("data", d => {
    const m = d.toString().trim();
    if (m && !/frame size not set|PES packet|Packet corrupt|non monotonous|SPS|PPS|no frame/i.test(m))
      console.error(`[ff:${key}]`, m);
  });

  ff.on("error", ()=>{ if (!res.headersSent) res.status(502).end(); });
  ff.on("close", ()=>{ active.delete(key); if (!res.writableEnded) res.end(); });
  req.on("close", ()=>killActive(key));
});

// ── Logo proxy ────────────────────────────────────────────────────
app.get("/logo", async (req,res) => {
  const url=req.query.url;
  if (!url||!/^https?:\/\//i.test(url)) return res.status(400).end();
  try {
    const p=new URL(url),lib=p.protocol==="https:"?https:http;
    const preq=lib.request({hostname:p.hostname,port:p.port||(p.protocol==="https:"?443:80),
      path:p.pathname+p.search,method:"GET",
      headers:{"User-Agent":"Mozilla/5.0","Referer":p.origin,"Accept":"image/*,*/*"}},
      pres=>{
        res.setHeader("Content-Type",pres.headers["content-type"]||"image/png");
        res.setHeader("Cache-Control","public,max-age=86400");
        res.setHeader("Access-Control-Allow-Origin","*");
        pres.pipe(res,{end:true});
      });
    preq.on("error",()=>res.status(502).end());
    preq.setTimeout(5000,()=>{preq.destroy();res.status(504).end();});
    preq.end();
  } catch(_){res.status(400).end();}
});

// ── Static + SPA ──────────────────────────────────────────────────
app.use(express.static(path.join(__dirname,"../static")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../static/index.html")));
process.on("SIGTERM",()=>{ active.forEach((_,k)=>killActive(k)); process.exit(0); });
app.listen(PORT,()=>console.log(`Stream :${PORT}  XC: ${XC_HOST}`));
