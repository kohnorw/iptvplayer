"use strict";

// ── State ─────────────────────────────────────────────────────────
const P = { sessionId:null, lastSessionId:null, heartbeat:null };
const S = {
  username:"", password:"",
  categories:[], channels:[], filtered:[],
  currentChannel:null, favourites:[],
  epgCache:{}, guideData:[],
  prefs:{ timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC" },
};

const $   = id => document.getElementById(id);
const esc = s  => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const mob = () => window.innerWidth <= 700;
const b64 = s => { try { return decodeURIComponent(atob(s).split("").map(c=>"%"+c.charCodeAt(0).toString(16).padStart(2,"0")).join("")); } catch(_) { try { return atob(s); } catch(_) { return s||""; } } };
const creds = () => "username="+encodeURIComponent(S.username)+"&password="+encodeURIComponent(S.password);

function fmtTime(v) {
  if (!v) return "";
  try {
    const d = typeof v==="number" ? new Date(v*1000) : new Date(String(v).replace(" ","T")+(String(v).includes("Z")||String(v).includes("+")?"":"Z"));
    return d.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit",timeZone:S.prefs.timezone,hour12:false});
  } catch(_) { return String(v).slice(11,16); }
}

// ── Boot ──────────────────────────────────────────────────────────
window.addEventListener("DOMContentLoaded", () => {
  bindEvents();
  populateTimezones();
  showScreen("login");
});

function showScreen(n) {
  $("login-screen").classList.toggle("active", n==="login");
  $("app-screen").classList.toggle("active",   n==="app");
}
function showLoading() { $("loading-overlay").classList.remove("hidden"); }
function hideLoading() { $("loading-overlay").classList.add("hidden"); }
function setProgress(pct, msg, detail) {
  $("progress-bar").style.width = pct+"%";
  if (msg    !== undefined) $("load-msg").textContent    = msg;
  if (detail !== undefined) $("load-detail").textContent = detail||"\u00a0";
}

// ── Events ────────────────────────────────────────────────────────
function bindEvents() {
  $("btn-login").addEventListener("click", doLogin);
  ["inp-user","inp-pass"].forEach(id => $(id).addEventListener("keydown", e => e.key==="Enter" && doLogin()));
  $("btn-logout").addEventListener("click", doLogout);
  document.querySelectorAll(".nav-btn").forEach(b => b.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(x => x.classList.remove("active"));
    b.classList.add("active");
    openTab(b.dataset.tab);
  }));
  const si = $("search-input");        if (si) si.addEventListener("input", e => filterChannels(e.target.value));
  const ms = $("mobile-search-input"); if (ms) ms.addEventListener("input", e => filterChannels(e.target.value));
  $("btn-fav").addEventListener("click", toggleFav);
  $("guide-search").addEventListener("input", e => filterGuide(e.target.value));
  window.addEventListener("beforeunload", () => stopStream());
}

// ── Tabs ──────────────────────────────────────────────────────────
function openTab(tab) {
  ["favourites","guide","settings","categories"].forEach(t => $("tab-"+t)?.classList.add("hidden"));
  if (tab === "live") { if (mob()) setMobileView("channels"); return; }
  const el = $("tab-"+tab); if (el) el.classList.remove("hidden");
  if (tab === "favourites") renderFavourites();
  if (tab === "guide")      loadGuide();
  if (tab === "settings")   loadSettingsTab();
  if (tab === "categories") renderMobileCategories();
  if (mob()) setMobileView("channels");
}

function closeTab(tab) {
  $("tab-"+tab)?.classList.add("hidden");
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.tab==="live"));
  document.querySelectorAll(".bnav-btn").forEach(b => b.classList.toggle("active", b.dataset.view==="channels"));
}
window.closeTab = closeTab;

// ── Mobile ────────────────────────────────────────────────────────
function setMobileView(view) {
  const body = $("app-body"); if (!body) return;
  body.classList.remove("view-channels","view-player");
  body.classList.add(view==="player" ? "view-player" : "view-channels");
}

function mobileNav(view) {
  document.querySelectorAll(".bnav-btn").forEach(b => b.classList.toggle("active", b.dataset.view===view));
  if (view === "channels") {
    ["favourites","guide","settings","categories"].forEach(t => $("tab-"+t)?.classList.add("hidden"));
    document.querySelectorAll(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.tab==="live"));
    setMobileView("channels");
  } else if (view === "player") {
    ["favourites","guide","settings","categories"].forEach(t => $("tab-"+t)?.classList.add("hidden"));
    setMobileView("player");
  } else {
    setMobileView("channels");
    ["favourites","guide","settings","categories"].forEach(t => $("tab-"+t)?.classList.add("hidden"));
    const el = $("tab-"+view); if (el) el.classList.remove("hidden");
    if (view === "favourites") renderFavourites();
    if (view === "guide")      loadGuide();
    if (view === "settings")   loadSettingsTab();
    if (view === "categories") renderMobileCategories();
  }
}
window.mobileNav = mobileNav;

function renderMobileCategories() {
  const body = $("cat-body"); if (!body) return;
  const items = [{id:"all",name:"All Channels"}].concat(S.categories.map(c => ({id:c.category_id,name:c.category_name})));
  body.innerHTML = items.map(item => '<div class="mob-cat-item" data-cat="'+esc(String(item.id))+'">'+esc(item.name)+'</div>').join("");
  body.onclick = function(e) {
    const el = e.target.closest(".mob-cat-item"); if (!el) return;
    const catId = el.dataset.cat;
    S.filtered = catId==="all" ? S.channels : S.channels.filter(ch => String(ch.category_id)===String(catId));
    renderChannels(S.filtered);
    if ($("search-input")) $("search-input").value = "";
    if ($("mobile-search-input")) $("mobile-search-input").value = "";
    closeTab("categories"); mobileNav("channels");
  };
}

// ── Login ─────────────────────────────────────────────────────────
async function doLogin() {
  const username = $("inp-user").value.trim(), password = $("inp-pass").value.trim();
  const errEl = $("login-error"), btn = $("btn-login");
  if (!username||!password) { errEl.textContent="Fill in all fields."; errEl.classList.remove("hidden"); return; }
  btn.disabled=true; btn.textContent="Connecting…";
  errEl.classList.add("hidden"); showLoading(); setProgress(5,"Authenticating…","");
  try {
    const auth = await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username,password})}).then(r=>r.json());
    if (!auth.ok) throw new Error(auth.error||"Login failed");
    S.username=username; S.password=password;

    setProgress(15,"Loading preferences…","");
    const prefs = await fetch("/api/prefs/"+encodeURIComponent(username)).then(r=>r.json()).catch(()=>({}));
    S.prefs = {...S.prefs,...prefs};
    if (S.prefs.advanced) fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.prefs.advanced)}).catch(()=>{});

    setProgress(30,"Fetching categories…","");
    S.categories = await fetch("/api/xc/get_live_categories?"+creds()).then(r=>r.json()).then(d=>d||[]).catch(()=>[]);

    setProgress(60,"Fetching channels…",S.categories.length+" categories");
    S.channels = await fetch("/api/xc/get_live_streams?"+creds()).then(r=>r.json()).then(d=>d||[]).catch(()=>[]);
    S.filtered = S.channels;

    setProgress(80,"Loading favourites…","");
    S.favourites = await fetch("/api/favs/"+encodeURIComponent(username)).then(r=>r.json()).catch(()=>[]);

    setProgress(100,"Ready — "+S.channels.length+" channels","");
    await new Promise(r=>setTimeout(r,300));
    hideLoading(); showScreen("app");
    renderCategories(); renderChannels(S.channels);
    fetchAllEpg();
    if (mob()) setMobileView("channels");
  } catch(err) {
    hideLoading(); errEl.textContent=err.message; errEl.classList.remove("hidden");
    S.username=""; S.password="";
  } finally { btn.disabled=false; btn.textContent="Connect"; }
}

function doLogout() {
  stopStream();
  Object.assign(S,{username:"",password:"",categories:[],channels:[],filtered:[],currentChannel:null,epgCache:{},guideData:[],favourites:[]});
  $("inp-user").value=""; $("inp-pass").value="";
  $("login-error").classList.add("hidden");
  showScreen("login");
}

// ── Categories ────────────────────────────────────────────────────
function renderCategories() {
  const list = $("category-list"); list.innerHTML="";
  const all = makeCatEl({category_id:"all",category_name:"All Channels"});
  all.classList.add("active"); list.appendChild(all);
  S.categories.forEach(c => list.appendChild(makeCatEl(c)));
}
function makeCatEl(cat) {
  const el = document.createElement("div"); el.className="cat-item";
  el.innerHTML = '<span class="cat-dot"></span>'+esc(cat.category_name);
  el.addEventListener("click", () => {
    document.querySelectorAll(".cat-item").forEach(c=>c.classList.remove("active"));
    el.classList.add("active");
    S.filtered = cat.category_id==="all" ? S.channels : S.channels.filter(c=>String(c.category_id)===String(cat.category_id));
    renderChannels(S.filtered);
    if ($("search-input")) $("search-input").value="";
    if ($("mobile-search-input")) $("mobile-search-input").value="";
  });
  return el;
}

// ── Channels ──────────────────────────────────────────────────────
function renderChannels(list) {
  const el = $("channel-list");
  if (!list.length) { el.innerHTML='<div class="empty">No channels found</div>'; return; }
  el.innerHTML = list.map(ch => {
    const logo = ch.stream_icon
      ? '<img src="/logo?url='+encodeURIComponent(ch.stream_icon)+'" onerror="this.style.display=\'none\'" loading="lazy"/>'
      : '<span>'+esc((ch.name||"?")[0].toUpperCase())+'</span>';
    const active = S.currentChannel?.stream_id==ch.stream_id ? " active" : "";
    const epg = S.epgCache[ch.stream_id];
    const now = Date.now()/1000;
    const np = epg ? epg.find(ep=>parseInt(ep.start_timestamp||0)<=now&&now<=parseInt(ep.stop_timestamp||0)) : null;
    const npt = np ? b64(np.title||"").trim() : "";
    return '<div class="ch-item'+active+'" data-id="'+ch.stream_id+'">'+
      '<div class="ch-logo">'+logo+'</div>'+
      '<div class="ch-info">'+
        '<div class="ch-name">'+esc(ch.name||"Channel")+'</div>'+
        '<div class="ch-num">#'+(ch.num||ch.stream_id)+(npt?' · <span class="ch-now">'+esc(npt)+'</span>':"")+
      '</div></div><span class="ch-live"></span></div>';
  }).join("");
  el.querySelectorAll(".ch-item").forEach(el => {
    el.addEventListener("click", () => {
      selectChannel(el.dataset.id);
      if (mob()) {
        setMobileView("player");
        document.querySelectorAll(".bnav-btn").forEach(b => b.classList.toggle("active",b.dataset.view==="player"));
      }
    });
  });
}

function filterChannels(q) {
  q = q.toLowerCase();
  S.filtered = q ? S.channels.filter(c=>(c.name||"").toLowerCase().includes(q)) : S.channels;
  renderChannels(S.filtered);
  if ($("search-input") && $("search-input").value!==q) $("search-input").value=q;
  if ($("mobile-search-input") && $("mobile-search-input").value!==q) $("mobile-search-input").value=q;
}

// ── Player ────────────────────────────────────────────────────────
var _hlsInstance = null;
var _isSafari = /Safari/i.test(navigator.userAgent) && !/Chrome|CriOS|FxiOS|EdgiOS|android/i.test(navigator.userAgent);

let _selectTimer = null;
function selectChannel(id) {
  if (S.currentChannel?.stream_id==id && _hlsInstance) return;
  clearTimeout(_selectTimer);
  _selectTimer = setTimeout(() => _doSelectChannel(id), 150);
}

async function _doSelectChannel(id) {
  const ch = S.channels.find(c=>c.stream_id==id) || S.favourites.find(c=>c.stream_id==id);
  if (!ch) return;
  stopStream();
  S.currentChannel = ch;
  document.querySelectorAll(".ch-item").forEach(el => el.classList.toggle("active",el.dataset.id==id));

  // Show buffering state
  $("player-placeholder").style.display = "flex";
  $("player-placeholder").innerHTML = '<span class="ph-icon" style="animation:pulse 1.2s ease-in-out infinite">⏳</span><span>Buffering…</span>';
  $("video").style.display = "none";
  $("now-playing").style.display = "flex";
  $("np-name").textContent = ch.name||"";
  $("np-epg").textContent = "";
  updateFavBtn();

  try {
    const oldSid = P.lastSessionId; P.lastSessionId = null;
    const r = await fetch("/api/stream/start",{
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({username:S.username,password:S.password,streamId:ch.stream_id,sessionId:oldSid||null,safari:_isSafari})
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error||"Stream failed");
    P.sessionId = d.sessionId; P.lastSessionId = d.sessionId;
    startHeartbeat(d.sessionId);

    if (d.audioOnly) {
      $("player-placeholder").style.display = "flex";
      $("player-placeholder").innerHTML = '<span class="ph-icon">🎵</span><span>'+esc(ch.name||"Audio Stream")+'</span>';
      $("video").style.display = "none";
    } else {
      $("player-placeholder").style.display = "none";
      $("video").style.display = "block";
    }
    playStream(d.url, d.audioOnly||false, d.hlsCfg||{});
  } catch(err) {
    $("player-placeholder").style.display = "flex";
    $("player-placeholder").innerHTML = '<span class="ph-icon">⚠</span><span>'+esc(err.message)+'</span>';
    $("video").style.display = "none";
    $("np-epg").textContent = "Unavailable";
  }
  loadEpg(ch.stream_id);
}

function playStream(url, audioOnly, serverCfg) {
  serverCfg = serverCfg || {};
  stopHls();
  const vid = $("video");

  if (Hls.isSupported()) {
    const hls = new Hls({
      enableWorker:                true,
      lowLatencyMode:              false,
      liveSyncDurationCount:       Math.max(1, Math.round((serverCfg.liveSyncSeconds||6)/2)),
      liveMaxLatencyDurationCount: 10,
      maxBufferLength:             serverCfg.maxBufferLength  || 30,
      maxMaxBufferLength:          (serverCfg.maxBufferLength || 30) * 2,
      backBufferLength:            serverCfg.backBufferLength || 0,
      fragLoadingTimeOut:          20000,
      fragLoadingMaxRetry:         6,
      fragLoadingRetryDelay:       1000,
      manifestLoadingTimeOut:      15000,
      levelLoadingTimeOut:         15000,
      nudgeMaxRetry:               10,
      nudgeOffset:                 0.5,
      maxStarvationDelay:          serverCfg.maxStarvationDelay || 8,
    });
    hls.loadSource(url);
    hls.attachMedia(vid);
    hls.on(Hls.Events.MANIFEST_PARSED, () => vid.play().catch(()=>{}));
    if (serverCfg.snapLive !== false) {
      hls.on(Hls.Events.LEVEL_UPDATED, (_, data) => {
        if (!data.details?.live) return;
        const live = hls.liveSyncPosition;
        if (live && isFinite(live) && vid.currentTime < live-(data.details.targetduration||4)) vid.currentTime = live;
      });
    }
    hls.on(Hls.Events.ERROR, (_, d) => {
      if (d.fatal) {
        if (d.type===Hls.ErrorTypes.NETWORK_ERROR) setTimeout(()=>hls.startLoad(),2000);
        else if (d.type===Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError();
      }
    });
    _hlsInstance = hls;
  } else if (vid.canPlayType("application/vnd.apple.mpegurl")) {
    vid.src = url;
    vid.addEventListener("loadedmetadata", () => vid.play().catch(()=>{}), {once:true});
  }
}

function stopHls() {
  if (_hlsInstance) { _hlsInstance.destroy(); _hlsInstance = null; }
  const vid = $("video");
  vid.pause(); vid.removeAttribute("src"); vid.load();
  vid.style.display = "none";
}

function stopStream() {
  stopHls();
  clearInterval(P.heartbeat); P.heartbeat = null;
  if (P.sessionId) {
    const sid = P.sessionId; P.lastSessionId = sid; P.sessionId = null;
    fetch("/api/stream/stop/"+sid,{method:"POST"}).catch(()=>{});
  }
  $("epg-strip").innerHTML = "";
}

function startHeartbeat(sid) {
  clearInterval(P.heartbeat);
  P.heartbeat = setInterval(() => {
    if (P.sessionId===sid) fetch("/api/stream/heartbeat/"+sid,{method:"POST"}).catch(()=>{});
    else clearInterval(P.heartbeat);
  }, 5000);
}

// ── EPG ───────────────────────────────────────────────────────────
async function fetchAllEpg() {
  const BATCH = 20;
  for (let i = 0; i < S.channels.length; i += BATCH) {
    await Promise.allSettled(S.channels.slice(i,i+BATCH).map(async ch => {
      if (S.epgCache[ch.stream_id]) return;
      try {
        const d = await fetch("/api/epg/"+ch.stream_id+"?"+creds()).then(r=>r.json());
        S.epgCache[ch.stream_id] = d.epg_listings||[];
        updateChannelNowPlaying(ch.stream_id);
      } catch(_) {}
    }));
    await new Promise(r=>setTimeout(r,200));
  }
}

async function loadEpg(id) {
  if (S.epgCache[id]) { renderEpg(S.epgCache[id]); return; }
  try {
    const d = await fetch("/api/epg/"+id+"?"+creds()).then(r=>r.json());
    S.epgCache[id] = d.epg_listings||[];
    renderEpg(S.epgCache[id]);
    updateChannelNowPlaying(id);
  } catch(_) {}
}

function updateChannelNowPlaying(id) {
  const el = document.querySelector('.ch-item[data-id="'+id+'"] .ch-num'); if (!el) return;
  const epg = S.epgCache[id]; if (!epg) return;
  const now = Date.now()/1000;
  const np = epg.find(ep=>parseInt(ep.start_timestamp||0)<=now&&now<=parseInt(ep.stop_timestamp||0));
  const npt = np ? b64(np.title||"").trim() : "";
  const ch = S.channels.find(c=>c.stream_id==id)||S.favourites.find(c=>c.stream_id==id);
  el.innerHTML = "#"+((ch&&(ch.num||ch.stream_id))||id)+(npt?' · <span class="ch-now">'+esc(npt)+'</span>':"");
}

function renderEpg(listings) {
  const now = Date.now()/1000;
  $("epg-strip").innerHTML = listings.slice(0,8).map(ep => {
    const start=parseInt(ep.start_timestamp||0), stop=parseInt(ep.stop_timestamp||0);
    const isNow = start<=now&&now<=stop;
    const startT = fmtTime(ep.start);
    const stopT  = stop ? fmtTime(new Date(stop*1000).toISOString().replace("T"," ").slice(0,19)) : "";
    const range  = stopT ? startT+" – "+stopT : startT;
    const title  = b64(ep.title||"").trim();
    if (isNow) $("np-epg").textContent = range+"  "+title;
    return '<div class="epg-card'+(isNow?" now":"")+'"><div class="epg-time">'+esc(range)+'</div><div class="epg-title">'+esc(title||"—")+'</div></div>';
  }).join("");
}

// ── Favourites ────────────────────────────────────────────────────
function updateFavBtn() {
  const ch = S.currentChannel; if (!ch) return;
  const isFav = S.favourites.some(f=>f.stream_id==ch.stream_id);
  $("btn-fav").textContent = isFav?"★":"☆";
  $("btn-fav").classList.toggle("active",isFav);
}
function toggleFav() {
  const ch = S.currentChannel; if (!ch) return;
  const idx = S.favourites.findIndex(f=>f.stream_id==ch.stream_id);
  if (idx===-1) S.favourites.push({stream_id:ch.stream_id,name:ch.name,stream_icon:ch.stream_icon,num:ch.num,category_id:ch.category_id});
  else S.favourites.splice(idx,1);
  updateFavBtn();
  fetch("/api/favs/"+encodeURIComponent(S.username),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.favourites)});
}
function renderFavourites() {
  const body = $("fav-body");
  if (!S.favourites.length) { body.innerHTML='<div class="empty">No favourites yet.<br>Press ☆ while watching a channel.</div>'; return; }
  const grid = document.createElement("div"); grid.className="fav-grid";
  grid.innerHTML = S.favourites.map(ch => {
    const logo = ch.stream_icon
      ? '<img src="/logo?url='+encodeURIComponent(ch.stream_icon)+'" onerror="this.style.display=\'none\'" loading="lazy"/>'
      : '<span>'+esc((ch.name||"?")[0].toUpperCase())+'</span>';
    return '<div class="fav-card" data-id="'+ch.stream_id+'"><button class="fav-remove" data-id="'+ch.stream_id+'">✕</button><div class="ch-logo">'+logo+'</div><div class="ch-name">'+esc(ch.name||"")+'</div></div>';
  }).join("");
  body.innerHTML=""; body.appendChild(grid);
  grid.querySelectorAll(".fav-card").forEach(card => card.addEventListener("click",e=>{
    if (e.target.classList.contains("fav-remove")) return;
    const ch = S.favourites.find(f=>f.stream_id==card.dataset.id);
    if (ch) { selectChannel(ch.stream_id); closeTab("favourites"); if(mob()){setMobileView("player");document.querySelectorAll(".bnav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view==="player"));} }
  }));
  grid.querySelectorAll(".fav-remove").forEach(btn => btn.addEventListener("click",e=>{
    e.stopPropagation();
    S.favourites = S.favourites.filter(f=>f.stream_id!=btn.dataset.id);
    fetch("/api/favs/"+encodeURIComponent(S.username),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.favourites)});
    renderFavourites();
  }));
}

// ── Guide ─────────────────────────────────────────────────────────
async function loadGuide() {
  const body = $("guide-body");
  if (!S.favourites.length) { body.innerHTML='<div class="empty">Add channels to favourites to see the guide.</div>'; return; }
  body.innerHTML='<div class="spinner">Loading guide…</div>';
  const rows = await Promise.allSettled(S.favourites.map(async ch => {
    let listings = S.epgCache[ch.stream_id];
    if (!listings) {
      try { const d=await fetch("/api/epg/"+ch.stream_id+"?"+creds()).then(r=>r.json()); listings=d.epg_listings||[]; S.epgCache[ch.stream_id]=listings; }
      catch(_) { listings=[]; }
    }
    return {ch,listings};
  }));
  S.guideData = rows.filter(r=>r.status==="fulfilled").map(r=>r.value);
  renderGuide(S.guideData);
}
function renderGuide(data) {
  const body = $("guide-body");
  if (!data.length) { body.innerHTML='<div class="empty">No guide data for your favourites.</div>'; return; }
  const now = Date.now()/1000;
  const grid = document.createElement("div"); grid.className="guide-grid";
  grid.innerHTML = data.map(({ch,listings}) => {
    const logo = ch.stream_icon
      ? '<img src="/logo?url='+encodeURIComponent(ch.stream_icon)+'" onerror="this.style.display=\'none\'" loading="lazy"/>'
      : '<span>'+esc((ch.name||"?")[0].toUpperCase())+'</span>';
    const progs = listings.slice(0,8).map(ep => {
      const start=parseInt(ep.start_timestamp||0),stop=parseInt(ep.stop_timestamp||0);
      const isNow=start<=now&&now<=stop;
      const startT=fmtTime(ep.start);
      const stopT=ep.stop?fmtTime(ep.stop):(stop?fmtTime(new Date(stop*1000).toISOString().replace("T"," ").slice(0,19)):"");
      const range=stopT?startT+" – "+stopT:startT;
      const title=b64(ep.title||"").trim();
      return '<div class="guide-program'+(isNow?" now":"")+'"><div class="gp-time">'+esc(range)+'</div><div class="gp-title">'+esc(title||"—")+'</div></div>';
    }).join("")||'<div class="guide-program"><div class="gp-time">—</div><div class="gp-title">No data</div></div>';
    return '<div class="guide-row"><div class="guide-ch" data-id="'+ch.stream_id+'"><div class="guide-ch-logo">'+logo+'</div><span class="guide-ch-name">'+esc(ch.name||"")+'</span><span class="guide-ch-watch">▶</span></div><div class="guide-programs">'+progs+'</div></div>';
  }).join("");
  body.innerHTML=""; body.appendChild(grid);
  grid.querySelectorAll(".guide-ch").forEach(el => el.addEventListener("click",()=>{
    const row = data.find(d=>d.ch.stream_id==el.dataset.id);
    if (row) { selectChannel(row.ch.stream_id); closeTab("guide"); if(mob()){setMobileView("player");document.querySelectorAll(".bnav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view==="player"));} }
  }));
}
function filterGuide(q) {
  q = q.toLowerCase();
  renderGuide(q ? S.guideData.filter(d=>(d.ch.name||"").toLowerCase().includes(q)) : S.guideData);
}

// ── Settings helpers ──────────────────────────────────────────────
function setVal(id,v){ const el=$(id); if(el) el.value=v; }
function setChk(id,v){ const el=$(id); if(el) el.checked=!!v; }
function getVal(id,def){ const el=$(id); return el?el.value:(def||""); }
function getChk(id,def){ const el=$(id); return el?el.checked:(!!def); }

function populateTimezones() {
  const sel = $("pref-timezone"); if (!sel) return;
  ["America/Vancouver","America/Edmonton","America/Regina","America/Winnipeg",
   "America/Toronto","America/Halifax","America/St_Johns",
   "America/Los_Angeles","America/Denver","America/Phoenix","America/Chicago","America/New_York",
   "Pacific/Honolulu","America/Anchorage",
   "Europe/London","Europe/Paris","Europe/Berlin","Europe/Helsinki","Europe/Moscow",
   "Asia/Dubai","Asia/Kolkata","Asia/Singapore","Asia/Tokyo","Australia/Sydney","Pacific/Auckland","UTC"]
  .forEach(z => { const o=document.createElement("option"); o.value=z; o.textContent=z.replace(/_/g," "); sel.appendChild(o); });
}

function switchStab(btn) {
  document.querySelectorAll(".stab-btn").forEach(b=>b.classList.remove("active"));
  document.querySelectorAll(".stab-panel").forEach(p=>p.classList.remove("active"));
  btn.classList.add("active");
  const panel = $("stab-"+btn.dataset.stab); if (panel) panel.classList.add("active");
  if (btn.dataset.stab==="command") loadCmdTab();
  if (btn.dataset.stab==="ffmpeg")  loadFfCmd();
}
window.switchStab = switchStab;

async function loadFfCmd() {
  const el = $("ffcmd-preview"); if (!el) return;
  try {
    const d = await fetch("/api/ffcmd").then(r=>r.json());
    el.textContent = "ffmpeg \\\n" + d.cmd.slice(1).map(a=>"  "+a).join(" \\\n");
  } catch(_) { if(el) el.textContent="Could not load command."; }
}

async function loadSettingsTab() {
  try {
    const r = await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:S.username,password:S.password})}).then(r=>r.json());
    const exp = r.expiry ? new Date(parseInt(r.expiry)*1000).toLocaleDateString() : "—";
    $("acct-info").innerHTML = "<b>"+esc(S.username)+"</b><br>Status: "+(r.status||"—")+"<br>Connections: "+r.connections+"<br>Expires: "+exp;
  } catch(_) { $("acct-info").textContent="Could not load account info."; }
  const a = S.prefs.advanced||{};
  setVal("pref-timezone",       S.prefs.timezone||"UTC");
  setVal("adv-ua",              a.ua||"chrome");
  setVal("adv-seg-secs",        a.segSecs||"2");
  setVal("adv-prebuf",          a.prebuf||"2");
  setVal("adv-window",          a.window||"60");
  setVal("adv-idle",            a.idle||"20");
  setVal("adv-stall-restart",   a.stallRestart||"10");
  setVal("adv-max-restarts",    a.maxRestarts!==undefined?String(a.maxRestarts):"5");
  setVal("adv-hlsbuf",          a.hlsBuf||"30");
  setVal("adv-backbuf",         a.backBuf!==undefined?String(a.backBuf):"0");
  setVal("adv-livesync",        a.liveSync||"6");
  setVal("adv-stalldelay",      a.stallDelay||"8");
  setChk("adv-snap-live",       a.snapLive!==false);
  setChk("adv-safari-transcode",a.safariTranscode!==false);
  setVal("adv-safari-profile",  a.safariProfile||"baseline");
  setVal("adv-safari-preset",   a.safariPreset||"ultrafast");
  setVal("adv-safari-vbr",      a.safariVbr||"0");
  setChk("adv-force-aac",       !!a.forceAac);
  setVal("adv-audio-br",        a.audioBr||"192");
  setVal("adv-audio-sr",        a.audioSr||"48000");
  setVal("adv-audio-prebuf",    a.audioPrebuf||"4");
  setChk("adv-aresample",       a.aresample!==false);
  setVal("adv-ffmpeg-input",    a.ffmpegInput||"");
  setVal("adv-probesize",       a.probeSize||"1000000");
  setVal("adv-analyzedur",      a.analyzeDur||"1500000");
  setVal("adv-thread-queue",    a.threadQueue||"8192");
  setVal("adv-ffmpeg-extra",    a.ffmpegExtra||"");
  setChk("adv-discard-corrupt", a.discardCorrupt!==false);
  setChk("adv-genpts",          a.genpts!==false);
  setChk("adv-ignore-err",      !!a.ignoreErr);
  setChk("adv-nobuffer",        !!a.noBuffer);
  setChk("adv-reconnect",       a.reconnect!==false);
  setChk("adv-reconnect-net",   a.reconnectNet!==false);
  setVal("adv-reconnect-delay", a.reconnectDelay||"5");
  setVal("adv-rwtimeout",       a.rwTimeout||"15000000");
  loadFfCmd();
}

async function savePrefs() {
  S.prefs.timezone = getVal("pref-timezone","UTC");
  S.prefs.advanced = {
    ua:             getVal("adv-ua","chrome"),
    segSecs:        getVal("adv-seg-secs","2"),
    prebuf:         getVal("adv-prebuf","2"),
    window:         getVal("adv-window","60"),
    idle:           getVal("adv-idle","20"),
    stallRestart:   getVal("adv-stall-restart","10"),
    maxRestarts:    parseInt(getVal("adv-max-restarts","5"))||5,
    hlsBuf:         getVal("adv-hlsbuf","30"),
    backBuf:        parseInt(getVal("adv-backbuf","0"))||0,
    liveSync:       getVal("adv-livesync","6"),
    stallDelay:     getVal("adv-stalldelay","8"),
    snapLive:       getChk("adv-snap-live",true),
    safariTranscode:getChk("adv-safari-transcode",true),
    safariProfile:  getVal("adv-safari-profile","baseline"),
    safariPreset:   getVal("adv-safari-preset","ultrafast"),
    safariVbr:      getVal("adv-safari-vbr","0"),
    forceAac:       getChk("adv-force-aac",false),
    audioBr:        getVal("adv-audio-br","192"),
    audioSr:        getVal("adv-audio-sr","48000"),
    audioPrebuf:    getVal("adv-audio-prebuf","4"),
    aresample:      getChk("adv-aresample",true),
    ffmpegInput:    getVal("adv-ffmpeg-input",""),
    probeSize:      getVal("adv-probesize","1000000"),
    analyzeDur:     getVal("adv-analyzedur","1500000"),
    threadQueue:    getVal("adv-thread-queue","8192"),
    ffmpegExtra:    getVal("adv-ffmpeg-extra",""),
    discardCorrupt: getChk("adv-discard-corrupt",true),
    genpts:         getChk("adv-genpts",true),
    ignoreErr:      getChk("adv-ignore-err",false),
    noBuffer:       getChk("adv-nobuffer",false),
    reconnect:      getChk("adv-reconnect",true),
    reconnectNet:   getChk("adv-reconnect-net",true),
    reconnectDelay: getVal("adv-reconnect-delay","5"),
    rwTimeout:      getVal("adv-rwtimeout","15000000"),
  };
  const msg = $("prefs-msg");
  try {
    await fetch("/api/prefs/"+encodeURIComponent(S.username),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.prefs)});
    await fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.prefs.advanced)});
    const cmdToggle=$("cmd-enabled"), cmdEditor=$("cmd-editor");
    if (cmdEditor && cmdEditor.value) {
      fetch("/api/ffcmd/custom",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({cmd:cmdEditor.value,enabled:cmdToggle?cmdToggle.checked:false})}).catch(()=>{});
    }
    msg.style.color="var(--green)"; msg.textContent="✓ Saved!"; msg.classList.remove("hidden");
    setTimeout(()=>msg.classList.add("hidden"),2000);
    loadFfCmd();
    S.epgCache={}; $("epg-strip").innerHTML="";
    if (S.currentChannel) loadEpg(S.currentChannel.stream_id);
  } catch(e) { msg.style.color="var(--red)"; msg.textContent="Error: "+e.message; msg.classList.remove("hidden"); }
}
window.savePrefs = savePrefs;

// ── Custom command ────────────────────────────────────────────────
async function loadCmdTab() {
  const ta=$("cmd-editor"), tog=$("cmd-enabled"); if(!ta) return;
  ta.value="Loading…";
  try {
    const d = await fetch("/api/ffcmd/custom").then(r=>r.json());
    ta.value=d.current||d.default||""; if(tog) tog.checked=!!d.isCustom;
  } catch(e) { ta.value="Error: "+e.message; }
}
async function saveCmd() {
  const ta=$("cmd-editor"), msg=$("cmd-msg"), tog=$("cmd-enabled"); if(!ta) return;
  msg.classList.add("hidden");
  try {
    const d = await fetch("/api/ffcmd/custom",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({cmd:ta.value,enabled:tog?tog.checked:true})}).then(r=>r.json());
    msg.style.color="var(--green)"; msg.textContent=d.enabled?"✓ Custom command active":"✓ Saved (disabled)";
    msg.classList.remove("hidden"); setTimeout(()=>msg.classList.add("hidden"),3000);
  } catch(e) { msg.style.color="var(--red)"; msg.textContent="Error: "+e.message; msg.classList.remove("hidden"); }
}
async function resetCmd() {
  const ta=$("cmd-editor"), msg=$("cmd-msg"), tog=$("cmd-enabled"); if(!ta) return;
  if (!confirm("Reset to default ffmpeg command?")) return;
  try {
    const d = await fetch("/api/ffcmd/reset",{method:"POST"}).then(r=>r.json());
    ta.value=d.default||""; if(tog) tog.checked=false;
    msg.style.color="var(--green)"; msg.textContent="✓ Reset to default";
    msg.classList.remove("hidden"); setTimeout(()=>msg.classList.add("hidden"),3000);
  } catch(e) { msg.style.color="var(--red)"; msg.textContent="Error: "+e.message; msg.classList.remove("hidden"); }
}
async function loadDefaultCmd() {
  const ta=$("cmd-editor"); if(!ta) return;
  try { const d=await fetch("/api/ffcmd/custom").then(r=>r.json()); ta.value=d.default||""; } catch(_) {}
}
window.resetCmd=resetCmd; window.loadDefaultCmd=loadDefaultCmd; window.saveCmd=saveCmd;

// ── Stop all ──────────────────────────────────────────────────────
async function stopAllStreams() {
  const msg = $("stopall-msg");
  try {
    stopStream();
    S.currentChannel=null;
    $("now-playing").style.display="none";
    $("player-placeholder").style.display="flex";
    $("player-placeholder").innerHTML='<span class="ph-icon">▶</span><span>Select a channel to watch</span>';
    document.querySelectorAll(".ch-item").forEach(el=>el.classList.remove("active"));
    const d = await fetch("/api/stream/stopall",{method:"POST"}).then(r=>r.json());
    msg.style.color="var(--green)";
    msg.textContent=d.stopped>0?"Stopped "+d.stopped+" stream"+(d.stopped===1?"":"s"):"No active streams";
    msg.classList.remove("hidden"); setTimeout(()=>msg.classList.add("hidden"),3000);
  } catch(e) { msg.style.color="var(--red)"; msg.textContent="Error: "+e.message; msg.classList.remove("hidden"); }
}
window.stopAllStreams=stopAllStreams;
