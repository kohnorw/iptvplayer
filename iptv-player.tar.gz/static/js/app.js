"use strict";

// ── HLS.js (loaded on demand) ─────────────────────────────────────
let HLS = null;
function loadHls() {
  return new Promise(resolve => {
    if (window.Hls) { HLS = window.Hls; return resolve(); }
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/hls.js@latest/dist/hls.min.js";
    s.onload = () => { HLS = window.Hls; resolve(); };
    s.onerror = () => resolve();
    document.head.appendChild(s);
  });
}

// ── State ─────────────────────────────────────────────────────────
const S = {
  host:"", username:"", password:"",
  categories:[], channels:[], filtered:[],
  currentChannel:null, favourites:[], epgCache:{}, guideData:[],
  hlsInstance:null, format:"ts",
};

const $  = id => document.getElementById(id);
const esc = s => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const b64 = s => { try { return atob(s); } catch(_){ return s; } };

// ── Boot ──────────────────────────────────────────────────────────
(async () => {
  await loadHls();
  bindEvents();
  await tryAutoLogin();
})();

async function tryAutoLogin() {
  try {
    const r = await fetch("/api/settings");
    const s = await r.json();
    if (s.host && s.username && s.password) {
      S.host = s.host; S.username = s.username; S.password = s.password;
      await xtreamTest();   // throws if bad
      await bootApp();
      return;
    }
  } catch(_) {}
  showScreen("login");
}

async function bootApp() {
  showScreen("app");
  loadPrefs();
  try { S.favourites = await fetch("/api/favourites").then(r=>r.json()); } catch(_){ S.favourites=[]; }
  await loadCategories();
}

// ── XC API — called DIRECTLY from browser to XC-Menu ─────────────
async function xcGet(action, params={}) {
  const u = new URL(`${S.host}/player_api.php`);
  u.searchParams.set("username", S.username);
  u.searchParams.set("password", S.password);
  if (action) u.searchParams.set("action", action);
  for (const [k,v] of Object.entries(params)) u.searchParams.set(k,v);
  const r = await fetch(u.toString());
  const txt = await r.text();
  try { return JSON.parse(txt); }
  catch(_) { throw new Error("Provider returned non-JSON. Check URL and credentials.\n\n" + txt.slice(0,150)); }
}

async function xtreamTest() {
  const d = await xcGet(null);
  if (!d.user_info) throw new Error("Credentials rejected by server.");
  return d.user_info;
}

// ── Screens ───────────────────────────────────────────────────────
function showScreen(name) {
  $("login-screen").classList.toggle("active", name==="login");
  $("app-screen").classList.toggle("active",   name==="app");
}

// ── Events ────────────────────────────────────────────────────────
function bindEvents() {
  $("btn-login").addEventListener("click", doLogin);
  ["inp-host","inp-user","inp-pass"].forEach(id => $(id).addEventListener("keydown", e => e.key==="Enter" && doLogin()));
  $("btn-logout").addEventListener("click", doLogout);
  document.querySelectorAll(".nav-btn").forEach(b => b.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(x=>x.classList.remove("active"));
    b.classList.add("active");
    openTab(b.dataset.tab);
  }));
  $("search-input").addEventListener("input", e => filterChannels(e.target.value));
  $("btn-fav").addEventListener("click", toggleFav);
  $("guide-search").addEventListener("input", e => filterGuide(e.target.value));
  $("pref-format").addEventListener("change", savePrefs);
}

// ── Login / Logout ────────────────────────────────────────────────
async function doLogin() {
  let host = $("inp-host").value.trim().replace(/\/+$/,"");
  const username = $("inp-user").value.trim();
  const password = $("inp-pass").value.trim();
  const errEl = $("login-error"), btn = $("btn-login");

  if (!host||!username||!password) {
    errEl.textContent="Please fill in all fields."; errEl.classList.remove("hidden"); return;
  }
  if (!/^https?:\/\//i.test(host)) host = "http://"+host;

  btn.disabled=true; btn.textContent="Connecting…"; errEl.classList.add("hidden");
  S.host=host; S.username=username; S.password=password;

  try {
    await xtreamTest();
    await fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({host,username,password})});
    await bootApp();
  } catch(err) {
    errEl.textContent = err.message;
    errEl.classList.remove("hidden");
    S.host=""; S.username=""; S.password="";
  } finally {
    btn.disabled=false; btn.textContent="Connect";
  }
}

function doLogout() {
  fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({host:"",username:"",password:""})});
  S.host=""; S.username=""; S.password="";
  stopPlayer();
  showScreen("login");
}

// ── Categories ────────────────────────────────────────────────────
async function loadCategories() {
  const list = $("category-list");
  list.innerHTML = '<div class="spinner">Loading…</div>';
  try {
    S.categories = await xcGet("get_live_categories") || [];
    list.innerHTML = "";
    const all = makeCatEl({category_id:"all", category_name:"All Channels"});
    all.classList.add("active");
    list.appendChild(all);
    S.categories.forEach(c => list.appendChild(makeCatEl(c)));
    await loadChannels("all");
  } catch(e) {
    list.innerHTML = `<div class="empty">${esc(e.message)}</div>`;
  }
}

function makeCatEl(cat) {
  const el = document.createElement("div");
  el.className = "cat-item";
  el.dataset.id = cat.category_id;
  el.innerHTML = `<span class="cat-dot"></span>${esc(cat.category_name)}`;
  el.addEventListener("click", async () => {
    document.querySelectorAll(".cat-item").forEach(c=>c.classList.remove("active"));
    el.classList.add("active");
    await loadChannels(cat.category_id);
  });
  return el;
}

// ── Channels ──────────────────────────────────────────────────────
async function loadChannels(catId) {
  const list = $("channel-list");
  list.innerHTML = '<div class="spinner">Loading…</div>';
  S.currentCat = catId;
  try {
    const params = catId==="all" ? {} : {category_id: catId};
    S.channels = await xcGet("get_live_streams", params) || [];
    S.filtered = S.channels;
    renderChannels(S.filtered);
  } catch(e) {
    list.innerHTML = `<div class="empty">${esc(e.message)}</div>`;
  }
}

function renderChannels(list) {
  const el = $("channel-list");
  if (!list.length) { el.innerHTML='<div class="empty">No channels found</div>'; return; }
  el.innerHTML = list.map(ch => {
    const logo = ch.stream_icon
      ? `<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'"/>`
      : esc((ch.name||"?")[0]);
    const active = S.currentChannel?.stream_id==ch.stream_id?" active":"";
    return `<div class="ch-item${active}" data-id="${ch.stream_id}">
      <div class="ch-logo">${logo}</div>
      <div class="ch-info"><div class="ch-name">${esc(ch.name||"Channel")}</div><div class="ch-num">#${ch.num||ch.stream_id}</div></div>
      <span class="ch-live"></span>
    </div>`;
  }).join("");
  el.querySelectorAll(".ch-item").forEach(el => el.addEventListener("click", () => selectChannel(el.dataset.id)));
}

function filterChannels(q) {
  q = q.toLowerCase();
  S.filtered = q ? S.channels.filter(c=>(c.name||"").toLowerCase().includes(q)) : S.channels;
  renderChannels(S.filtered);
}

// ── Player ────────────────────────────────────────────────────────
async function selectChannel(id) {
  const ch = S.channels.find(c=>c.stream_id==id) || S.favourites.find(c=>c.stream_id==id);
  if (!ch) return;
  S.currentChannel = ch;
  document.querySelectorAll(".ch-item").forEach(el=>el.classList.toggle("active",el.dataset.id==id));

  // Stream URL goes through our Docker proxy so browser doesn't need direct access
  const streamUrl = `/proxy/stream/live/${id}.${S.format}`;
  playStream(streamUrl, ch);
  loadEpg(ch.stream_id);
}

function playStream(url, ch) {
  stopPlayer();
  $("player-placeholder").style.display="none";
  const vid = $("video");
  vid.classList.add("visible");

  if (HLS && HLS.isSupported() && (S.format==="m3u8"||url.endsWith(".m3u8"))) {
    const hls = new HLS({ enableWorker:false, lowLatencyMode:true });
    hls.loadSource(url);
    hls.attachMedia(vid);
    hls.on(HLS.Events.MANIFEST_PARSED, ()=>vid.play().catch(()=>{}));
    S.hlsInstance = hls;
  } else {
    vid.src = url;
    vid.play().catch(()=>{});
  }

  $("now-playing").style.display="flex";
  $("np-name").textContent = ch.name||"";
  $("np-epg").textContent = "Loading…";

  const isFav = S.favourites.some(f=>f.stream_id==ch.stream_id);
  $("btn-fav").textContent = isFav?"★":"☆";
  $("btn-fav").classList.toggle("active", isFav);
}

function stopPlayer() {
  if (S.hlsInstance) { S.hlsInstance.destroy(); S.hlsInstance=null; }
  const vid = $("video");
  vid.pause(); vid.src=""; vid.classList.remove("visible");
}

// ── EPG ───────────────────────────────────────────────────────────
async function loadEpg(streamId) {
  $("epg-strip").innerHTML="";
  if (S.epgCache[streamId]) { renderEpg(S.epgCache[streamId]); return; }
  try {
    const d = await xcGet("get_short_epg", {stream_id:streamId, limit:6});
    const listings = d.epg_listings||[];
    S.epgCache[streamId]=listings;
    renderEpg(listings);
  } catch(_){}
}

function renderEpg(listings) {
  const now = Date.now()/1000;
  const strip = $("epg-strip");
  strip.innerHTML = listings.slice(0,8).map(ep => {
    const start = parseInt(ep.start_timestamp||0);
    const stop  = parseInt(ep.stop_timestamp||0);
    const isNow = start<=now && now<=stop;
    const time  = ep.start ? ep.start.slice(11,16) : "";
    const title = b64(ep.title||"").trim();
    if (isNow) $("np-epg").textContent = `${time} — ${title}`;
    return `<div class="epg-card${isNow?" now":""}"><div class="epg-time">${esc(time)}</div><div class="epg-title">${esc(title)}</div></div>`;
  }).join("");
}

// ── Favourites ────────────────────────────────────────────────────
function toggleFav() {
  const ch = S.currentChannel; if (!ch) return;
  const idx = S.favourites.findIndex(f=>f.stream_id==ch.stream_id);
  if (idx===-1) {
    S.favourites.push({stream_id:ch.stream_id,name:ch.name,stream_icon:ch.stream_icon,num:ch.num});
    $("btn-fav").textContent="★"; $("btn-fav").classList.add("active");
  } else {
    S.favourites.splice(idx,1);
    $("btn-fav").textContent="☆"; $("btn-fav").classList.remove("active");
  }
  fetch("/api/favourites",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.favourites)});
}

function renderFavourites() {
  const body = $("fav-body");
  if (!S.favourites.length) { body.innerHTML='<div class="empty">No favourites yet.<br>Press ☆ while watching a channel.</div>'; return; }
  const grid = document.createElement("div"); grid.className="fav-grid";
  grid.innerHTML = S.favourites.map(ch => {
    const logo = ch.stream_icon ? `<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'"/>` : esc((ch.name||"?")[0]);
    return `<div class="fav-card" data-id="${ch.stream_id}">
      <button class="fav-remove" data-id="${ch.stream_id}">✕</button>
      <div class="ch-logo">${logo}</div>
      <div class="ch-name">${esc(ch.name||"")}</div>
    </div>`;
  }).join("");
  body.innerHTML=""; body.appendChild(grid);
  grid.querySelectorAll(".fav-card").forEach(card => card.addEventListener("click", e => {
    if (e.target.classList.contains("fav-remove")) return;
    const ch = S.favourites.find(f=>f.stream_id==card.dataset.id);
    if (ch) { if (!S.channels.find(c=>c.stream_id==ch.stream_id)) S.channels.push(ch); selectChannel(ch.stream_id); closeTab("favourites"); }
  }));
  grid.querySelectorAll(".fav-remove").forEach(btn => btn.addEventListener("click", e => {
    e.stopPropagation();
    S.favourites = S.favourites.filter(f=>f.stream_id!=btn.dataset.id);
    fetch("/api/favourites",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.favourites)});
    renderFavourites();
  }));
}

// ── Guide ─────────────────────────────────────────────────────────
async function loadGuide() {
  const body = $("guide-body");
  body.innerHTML = '<div class="spinner">Loading guide…</div>';
  const channels = S.channels.length ? S.channels.slice(0,40) : [];
  const now = Date.now()/1000;

  const rows = await Promise.allSettled(channels.map(async ch => {
    let listings = S.epgCache[ch.stream_id];
    if (!listings) {
      try { const d = await xcGet("get_short_epg",{stream_id:ch.stream_id,limit:5}); listings=d.epg_listings||[]; S.epgCache[ch.stream_id]=listings; }
      catch(_){ listings=[]; }
    }
    return { ch, listings };
  }));

  S.guideData = rows.filter(r=>r.status==="fulfilled").map(r=>r.value).filter(r=>r.listings.length);
  renderGuide(S.guideData);
}

function renderGuide(data) {
  const body = $("guide-body");
  if (!data.length) { body.innerHTML='<div class="empty">No guide data from provider.</div>'; return; }
  const now = Date.now()/1000;
  const grid = document.createElement("div"); grid.className="guide-grid";
  grid.innerHTML = data.map(({ch,listings}) => {
    const progs = listings.slice(0,5).map(ep => {
      const start=parseInt(ep.start_timestamp||0),stop=parseInt(ep.stop_timestamp||0);
      const isNow=start<=now&&now<=stop;
      const time=ep.start?ep.start.slice(11,16):"";
      const title=b64(ep.title||"").trim();
      return `<div class="guide-program${isNow?" now":""}"><div class="gp-time">${esc(time)}</div><div class="gp-title">${esc(title)}</div></div>`;
    }).join("");
    return `<div class="guide-row">
      <div class="guide-ch" data-id="${ch.stream_id}"><span class="guide-ch-name">${esc(ch.name||"")}</span><span style="font-size:11px;color:var(--text3)">▶ Watch</span></div>
      <div class="guide-programs">${progs}</div>
    </div>`;
  }).join("");
  body.innerHTML=""; body.appendChild(grid);
  grid.querySelectorAll(".guide-ch").forEach(el => el.addEventListener("click", () => {
    const ch = data.find(d=>d.ch.stream_id==el.dataset.id)?.ch;
    if (ch) { if (!S.channels.find(c=>c.stream_id==ch.stream_id)) S.channels.push(ch); selectChannel(ch.stream_id); closeTab("guide"); }
  }));
}

function filterGuide(q) {
  q = q.toLowerCase();
  renderGuide(q ? S.guideData.filter(d=>(d.ch.name||"").toLowerCase().includes(q)) : S.guideData);
}

// ── Tabs ──────────────────────────────────────────────────────────
function openTab(tab) {
  ["favourites","guide","settings"].forEach(t => $(`tab-${t}`)?.classList.add("hidden"));
  if (tab==="live") return;
  $(`tab-${tab}`)?.classList.remove("hidden");
  if (tab==="favourites") renderFavourites();
  if (tab==="guide")      loadGuide();
  if (tab==="settings")   loadSettingsTab();
}
function closeTab(tab) {
  $(`tab-${tab}`)?.classList.add("hidden");
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.tab==="live"));
}
window.closeTab = closeTab;

// ── Settings tab ──────────────────────────────────────────────────
async function loadSettingsTab() {
  $("s-host").value = S.host; $("s-user").value = S.username; $("s-pass").value = S.password;
  try {
    const info = await xtreamTest();
    const exp = info.exp_date ? new Date(parseInt(info.exp_date)*1000).toLocaleDateString() : "—";
    $("acct-info").innerHTML = `Status: <b>${info.status||"—"}</b><br>Connections: <b>${info.active_cons}/${info.max_connections}</b><br>Expires: <b>${exp}</b>`;
  } catch(_) { $("acct-info").textContent="Could not fetch account info."; }
}

async function saveSettings() {
  let host=$("s-host").value.trim().replace(/\/+$/,""), username=$("s-user").value.trim(), password=$("s-pass").value.trim();
  const msg=$("settings-msg");
  if (!host||!username||!password) { msg.textContent="All fields required."; msg.classList.remove("hidden"); return; }
  if (!/^https?:\/\//i.test(host)) host="http://"+host;
  S.host=host; S.username=username; S.password=password;
  try {
    await xtreamTest();
    await fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({host,username,password})});
    msg.style.color="var(--green)"; msg.textContent="✓ Saved!"; msg.classList.remove("hidden");
    setTimeout(()=>{ closeTab("settings"); loadCategories(); }, 800);
  } catch(e) { msg.style.color="var(--red)"; msg.textContent=e.message; msg.classList.remove("hidden"); }
}
window.saveSettings = saveSettings;

// ── Prefs ─────────────────────────────────────────────────────────
function loadPrefs() {
  try { const p=JSON.parse(localStorage.getItem("iptv_prefs")||"{}"); S.format=p.format||"ts"; } catch(_){}
  $("pref-format").value = S.format;
}
function savePrefs() {
  S.format = $("pref-format").value;
  localStorage.setItem("iptv_prefs", JSON.stringify({format:S.format}));
}
