"use strict";

let HLS = null;
function loadHls() {
  return new Promise(resolve => {
    if (window.Hls) { HLS = window.Hls; return resolve(); }
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/hls.js@latest/dist/hls.min.js";
    s.onload = () => { HLS = window.Hls; resolve(); };
    s.onerror = () => resolve();
    document.head.appendChild(s);
  });
}

const S = {
  categories:[], channels:[], filtered:[],
  currentChannel:null, favourites:[], epgCache:{}, guideData:[],
  hlsInstance:null, format:"m3u8",
};

const $   = id => document.getElementById(id);
const esc = s  => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const b64 = s  => { try { return atob(s); } catch(_){ return s; } };

// ── Boot ──────────────────────────────────────────────────────────
(async () => {
  await loadHls();
  bindEvents();
  await tryAutoLogin();
})();

async function tryAutoLogin() {
  try {
    const s = await fetch("/api/settings").then(r => r.json());
    if (s.host && s.username) {
      // Try loading from cache first
      const cache = await fetch("/api/cache").then(r => r.ok ? r.json() : null).catch(() => null);
      if (cache && cache.channels && cache.channels.length) {
        S.categories = cache.categories || [];
        S.channels   = cache.channels;
        S.filtered   = S.channels;
        await bootApp();
        return;
      }
      // No cache — fetch with progress
      showLoadingOverlay();
      await fetchChannelsWithProgress();
      return;
    }
  } catch(_) {}
  showScreen("login");
}

// ── Loading overlay ───────────────────────────────────────────────
function showLoadingOverlay() {
  $("loading-overlay").classList.remove("hidden");
  $("login-box") && ($("login-box").style.opacity = "0.3");
}

function hideLoadingOverlay() {
  $("loading-overlay").classList.add("hidden");
  $("login-box") && ($("login-box").style.opacity = "1");
}

function setProgress(pct, msg, detail) {
  $("progress-bar").style.width = pct + "%";
  if (msg)    $("load-msg").textContent    = msg;
  if (detail) $("load-detail").textContent = detail;
}

// ── SSE channel loader ────────────────────────────────────────────
function fetchChannelsWithProgress() {
  return new Promise((resolve, reject) => {
    const es = new EventSource("/api/load-channels");

    es.onmessage = e => {
      const msg = JSON.parse(e.data);

      if (msg.type === "progress") {
        setProgress(msg.pct, msg.msg, "");
      } else if (msg.type === "done") {
        es.close();
        S.categories = msg.categories || [];
        S.channels   = msg.channels   || [];
        S.filtered   = S.channels;
        setProgress(100, `Loaded ${S.channels.length} channels`, "");
        setTimeout(() => { hideLoadingOverlay(); bootApp(); resolve(); }, 400);
      } else if (msg.type === "error") {
        es.close();
        hideLoadingOverlay();
        showError(msg.msg);
        reject(new Error(msg.msg));
      }
    };

    es.onerror = () => {
      es.close();
      hideLoadingOverlay();
      showScreen("login");
      reject(new Error("Connection lost"));
    };
  });
}

function showError(msg) {
  showScreen("login");
  const el = $("login-error");
  el.textContent = msg;
  el.classList.remove("hidden");
}

async function bootApp() {
  showScreen("app");
  loadPrefs();
  try { S.favourites = await fetch("/api/favourites").then(r => r.json()); } catch(_){ S.favourites = []; }
  renderCategories();
  renderChannels(S.channels);
}

function showScreen(name) {
  $("login-screen").classList.toggle("active", name === "login");
  $("app-screen").classList.toggle("active",   name === "app");
}

// ── Events ────────────────────────────────────────────────────────
function bindEvents() {
  $("btn-login").addEventListener("click", doLogin);
  ["inp-host","inp-user","inp-pass"].forEach(id =>
    $(id).addEventListener("keydown", e => e.key === "Enter" && doLogin())
  );
  $("btn-logout").addEventListener("click", doLogout);
  document.querySelectorAll(".nav-btn").forEach(b => b.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(x => x.classList.remove("active"));
    b.classList.add("active");
    openTab(b.dataset.tab);
  }));
  $("search-input").addEventListener("input", e => filterChannels(e.target.value));
  $("btn-fav").addEventListener("click", toggleFav);
  $("guide-search").addEventListener("input", e => filterGuide(e.target.value));
  $("pref-format").addEventListener("change", savePrefs);
}

// ── Login ─────────────────────────────────────────────────────────
async function doLogin() {
  const host     = $("inp-host").value.trim();
  const username = $("inp-user").value.trim();
  const password = $("inp-pass").value.trim();
  const errEl    = $("login-error");
  const btn      = $("btn-login");

  if (!host || !username || !password) {
    errEl.textContent = "Please fill in all fields.";
    errEl.classList.remove("hidden"); return;
  }

  btn.disabled = true; btn.textContent = "Connecting…";
  errEl.classList.add("hidden");

  try {
    const r = await fetch("/api/login", {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ host, username, password }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || "Login failed");

    // Show progress overlay and stream channels
    showLoadingOverlay();
    setProgress(10, "Authenticated! Fetching channels…", `Connected to ${d.host}`);
    await fetchChannelsWithProgress();
  } catch(err) {
    errEl.textContent = err.message;
    errEl.classList.remove("hidden");
    hideLoadingOverlay();
  } finally {
    btn.disabled = false; btn.textContent = "Connect";
  }
}

function doLogout() {
  fetch("/api/settings", { method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({host:"",username:"",password:""}) });
  S.channels = []; S.categories = []; S.filtered = [];
  stopPlayer();
  showScreen("login");
}

// ── Categories & Channels ─────────────────────────────────────────
function renderCategories() {
  const list = $("category-list");
  list.innerHTML = "";

  const all = makeCatEl({ category_id:"all", category_name:"All Channels" });
  all.classList.add("active");
  list.appendChild(all);
  S.categories.forEach(c => list.appendChild(makeCatEl(c)));
}

function makeCatEl(cat) {
  const el = document.createElement("div");
  el.className = "cat-item";
  el.dataset.id = cat.category_id;
  el.innerHTML = `<span class="cat-dot"></span>${esc(cat.category_name)}`;
  el.addEventListener("click", () => {
    document.querySelectorAll(".cat-item").forEach(c => c.classList.remove("active"));
    el.classList.add("active");
    const filtered = cat.category_id === "all"
      ? S.channels
      : S.channels.filter(c => String(c.category_id) === String(cat.category_id));
    S.filtered = filtered;
    renderChannels(filtered);
  });
  return el;
}

function renderChannels(list) {
  const el = $("channel-list");
  if (!list.length) { el.innerHTML = '<div class="empty">No channels found</div>'; return; }
  el.innerHTML = list.map(ch => {
    const logo = ch.stream_icon
      ? `<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    const active = S.currentChannel?.stream_id == ch.stream_id ? " active" : "";
    return `<div class="ch-item${active}" data-id="${ch.stream_id}">
      <div class="ch-logo">${logo}</div>
      <div class="ch-info">
        <div class="ch-name">${esc(ch.name||"Channel")}</div>
        <div class="ch-num">#${ch.num||ch.stream_id}</div>
      </div>
      <span class="ch-live"></span>
    </div>`;
  }).join("");
  el.querySelectorAll(".ch-item").forEach(el =>
    el.addEventListener("click", () => selectChannel(el.dataset.id))
  );
}

function filterChannels(q) {
  q = q.toLowerCase();
  S.filtered = q ? S.channels.filter(c => (c.name||"").toLowerCase().includes(q)) : S.channels;
  renderChannels(S.filtered);
}

// ── Player ────────────────────────────────────────────────────────
async function selectChannel(id) {
  const ch = S.channels.find(c => c.stream_id == id) || S.favourites.find(c => c.stream_id == id);
  if (!ch) return;
  S.currentChannel = ch;
  document.querySelectorAll(".ch-item").forEach(el => el.classList.toggle("active", el.dataset.id == id));
  playStream(`/proxy/stream/live/${id}.${S.format}`, ch);
  loadEpg(id);
}

function playStream(url, ch) {
  stopPlayer();
  $("player-placeholder").style.display = "none";
  const vid = $("video");
  vid.classList.add("visible");

  if (HLS && HLS.isSupported()) {
    const hls = new HLS({ enableWorker:false, lowLatencyMode:true, debug:false });
    hls.loadSource(url);
    hls.attachMedia(vid);
    hls.on(HLS.Events.MANIFEST_PARSED, () => vid.play().catch(() => {}));
    hls.on(HLS.Events.ERROR, (_, d) => {
      if (d.fatal) { console.error("HLS fatal error", d); }
    });
    S.hlsInstance = hls;
  } else if (vid.canPlayType("application/vnd.apple.mpegurl")) {
    // Safari native HLS
    vid.src = url;
    vid.play().catch(() => {});
  } else {
    vid.src = url;
    vid.play().catch(() => {});
  }

  $("now-playing").style.display = "flex";
  $("np-name").textContent = ch.name || "";
  $("np-epg").textContent  = "Loading programme info…";

  const isFav = S.favourites.some(f => f.stream_id == ch.stream_id);
  $("btn-fav").textContent = isFav ? "★" : "☆";
  $("btn-fav").classList.toggle("active", isFav);
}

function stopPlayer() {
  if (S.hlsInstance) { S.hlsInstance.destroy(); S.hlsInstance = null; }
  const vid = $("video");
  vid.pause(); vid.src = ""; vid.classList.remove("visible");
}

// ── EPG ───────────────────────────────────────────────────────────
async function loadEpg(streamId) {
  $("epg-strip").innerHTML = "";
  if (S.epgCache[streamId]) { renderEpg(S.epgCache[streamId]); return; }
  try {
    const d = await fetch(`/api/epg/${streamId}`).then(r => r.json());
    const listings = d.epg_listings || [];
    S.epgCache[streamId] = listings;
    renderEpg(listings);
  } catch(_) {}
}

function renderEpg(listings) {
  const now = Date.now() / 1000;
  $("epg-strip").innerHTML = listings.slice(0,8).map(ep => {
    const start = parseInt(ep.start_timestamp||0);
    const stop  = parseInt(ep.stop_timestamp||0);
    const isNow = start <= now && now <= stop;
    const time  = ep.start ? ep.start.slice(11,16) : "";
    const title = b64(ep.title||"").trim();
    if (isNow) $("np-epg").textContent = `${time} — ${title}`;
    return `<div class="epg-card${isNow?" now":""}">
      <div class="epg-time">${esc(time)}</div>
      <div class="epg-title">${esc(title)}</div>
    </div>`;
  }).join("");
}

// ── Favourites ────────────────────────────────────────────────────
function toggleFav() {
  const ch = S.currentChannel; if (!ch) return;
  const idx = S.favourites.findIndex(f => f.stream_id == ch.stream_id);
  if (idx === -1) {
    S.favourites.push({ stream_id:ch.stream_id, name:ch.name, stream_icon:ch.stream_icon, num:ch.num });
    $("btn-fav").textContent = "★"; $("btn-fav").classList.add("active");
  } else {
    S.favourites.splice(idx, 1);
    $("btn-fav").textContent = "☆"; $("btn-fav").classList.remove("active");
  }
  fetch("/api/favourites", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(S.favourites) });
}

function renderFavourites() {
  const body = $("fav-body");
  if (!S.favourites.length) {
    body.innerHTML = '<div class="empty">No favourites yet.<br>Press ☆ while watching a channel.</div>'; return;
  }
  const grid = document.createElement("div"); grid.className = "fav-grid";
  grid.innerHTML = S.favourites.map(ch => {
    const logo = ch.stream_icon
      ? `<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    return `<div class="fav-card" data-id="${ch.stream_id}">
      <button class="fav-remove" data-id="${ch.stream_id}">✕</button>
      <div class="ch-logo">${logo}</div>
      <div class="ch-name">${esc(ch.name||"")}</div>
    </div>`;
  }).join("");
  body.innerHTML = ""; body.appendChild(grid);
  grid.querySelectorAll(".fav-card").forEach(card => card.addEventListener("click", e => {
    if (e.target.classList.contains("fav-remove")) return;
    const ch = S.favourites.find(f => f.stream_id == card.dataset.id);
    if (ch) { if (!S.channels.find(c => c.stream_id == ch.stream_id)) S.channels.push(ch); selectChannel(ch.stream_id); closeTab("favourites"); }
  }));
  grid.querySelectorAll(".fav-remove").forEach(btn => btn.addEventListener("click", e => {
    e.stopPropagation();
    S.favourites = S.favourites.filter(f => f.stream_id != btn.dataset.id);
    fetch("/api/favourites",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.favourites)});
    renderFavourites();
  }));
}

// ── Guide ─────────────────────────────────────────────────────────
async function loadGuide() {
  const body = $("guide-body");
  body.innerHTML = '<div class="spinner">Loading guide…</div>';

  // Use already-loaded channels (no extra fetch needed)
  const channels = S.channels.slice(0, 50);
  const now = Date.now() / 1000;

  const rows = await Promise.allSettled(channels.map(async ch => {
    let listings = S.epgCache[ch.stream_id];
    if (!listings) {
      try {
        const d = await fetch(`/api/epg/${ch.stream_id}`).then(r => r.json());
        listings = d.epg_listings || [];
        S.epgCache[ch.stream_id] = listings;
      } catch(_) { listings = []; }
    }
    return { ch, listings };
  }));

  S.guideData = rows
    .filter(r => r.status === "fulfilled")
    .map(r => r.value)
    .filter(r => r.listings.length);

  renderGuide(S.guideData);
}

function renderGuide(data) {
  const body = $("guide-body");
  if (!data.length) { body.innerHTML = '<div class="empty">No guide data available from your provider.</div>'; return; }
  const now = Date.now() / 1000;
  const grid = document.createElement("div"); grid.className = "guide-grid";

  grid.innerHTML = data.map(({ ch, listings }) => {
    const logo = ch.stream_icon
      ? `<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;

    const progs = listings.slice(0, 6).map(ep => {
      const start = parseInt(ep.start_timestamp||0);
      const stop  = parseInt(ep.stop_timestamp||0);
      const isNow = start <= now && now <= stop;
      const time  = ep.start ? ep.start.slice(11,16) : "";
      const title = b64(ep.title||"").trim();
      return `<div class="guide-program${isNow?" now":""}">
        <div class="gp-time">${esc(time)}</div>
        <div class="gp-title">${esc(title||"—")}</div>
      </div>`;
    }).join("");

    return `<div class="guide-row">
      <div class="guide-ch" data-id="${ch.stream_id}">
        <div class="guide-ch-logo">${logo}</div>
        <span class="guide-ch-name">${esc(ch.name||"")}</span>
        <span style="font-size:11px;color:var(--text3);flex-shrink:0">▶</span>
      </div>
      <div class="guide-programs">${progs}</div>
    </div>`;
  }).join("");

  body.innerHTML = ""; body.appendChild(grid);

  grid.querySelectorAll(".guide-ch").forEach(el => el.addEventListener("click", () => {
    const ch = data.find(d => d.ch.stream_id == el.dataset.id)?.ch;
    if (ch) { if (!S.channels.find(c => c.stream_id == ch.stream_id)) S.channels.push(ch); selectChannel(ch.stream_id); closeTab("guide"); }
  }));
}

function filterGuide(q) {
  q = q.toLowerCase();
  renderGuide(q ? S.guideData.filter(d => (d.ch.name||"").toLowerCase().includes(q)) : S.guideData);
}

// ── Tabs ──────────────────────────────────────────────────────────
function openTab(tab) {
  ["favourites","guide","settings"].forEach(t => $(`tab-${t}`)?.classList.add("hidden"));
  if (tab === "live") return;
  $(`tab-${tab}`)?.classList.remove("hidden");
  if (tab === "favourites") renderFavourites();
  if (tab === "guide")      loadGuide();
  if (tab === "settings")   loadSettingsTab();
}
function closeTab(tab) {
  $(`tab-${tab}`)?.classList.add("hidden");
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === "live"));
}
window.closeTab = closeTab;

// ── Settings ──────────────────────────────────────────────────────
async function loadSettingsTab() {
  try {
    const s = await fetch("/api/settings").then(r => r.json());
    $("s-host").value = s.host||""; $("s-user").value = s.username||""; $("s-pass").value = s.password||"";
    const info = await fetch("/api/test").then(r => r.json());
    const exp  = info.expiry ? new Date(parseInt(info.expiry)*1000).toLocaleDateString() : "—";
    $("acct-info").innerHTML = `Status: <b>${info.status||"—"}</b><br>Connections: <b>${info.connections}</b><br>Expires: <b>${exp}</b>`;
  } catch(e) { $("acct-info").textContent = "Could not fetch account info."; }
}

async function saveSettings() {
  const host=$("s-host").value.trim(), username=$("s-user").value.trim(), password=$("s-pass").value.trim();
  const msg = $("settings-msg");
  if (!host||!username||!password) { msg.textContent="All fields required."; msg.classList.remove("hidden"); return; }
  try {
    const r = await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({host,username,password})});
    const d = await r.json();
    if (!r.ok) throw new Error(d.error);
    msg.style.color="var(--green)"; msg.textContent="✓ Saved! Reloading channels…"; msg.classList.remove("hidden");
    setTimeout(async () => {
      closeTab("settings");
      showLoadingOverlay();
      await fetchChannelsWithProgress();
    }, 800);
  } catch(e) { msg.style.color="var(--red)"; msg.textContent=e.message; msg.classList.remove("hidden"); }
}
window.saveSettings = saveSettings;

// ── Prefs ─────────────────────────────────────────────────────────
function loadPrefs() {
  try { const p=JSON.parse(localStorage.getItem("iptv_prefs")||"{}"); S.format=p.format||"m3u8"; } catch(_){}
  $("pref-format").value = S.format;
}
function savePrefs() {
  S.format = $("pref-format").value;
  localStorage.setItem("iptv_prefs", JSON.stringify({format:S.format}));
}
