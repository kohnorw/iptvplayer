"use strict";

const P = { sessionId:null, lastSessionId:null, heartbeat:null };
const S = {
  username:"", password:"",
  categories:[], channels:[], filtered:[],
  currentChannel:null, favourites:[],
  epgCache:{}, guideData:[],
  hlsInstance:null,
  prefs:{ timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC" },
};

const $    = id => document.getElementById(id);
const esc  = s  => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const b64 = s => {
  if (!s) return s;
  try {
    // Decode base64, then decode as UTF-8 to handle accented/special characters
    return decodeURIComponent(atob(s).split("").map(ch=>"%" + ch.charCodeAt(0).toString(16).padStart(2,"0")).join(""));
  } catch(_) {
    try { return atob(s); } catch(_) { return s; }
  }
};
const mob  = ()  => window.innerWidth <= 700;

function creds() { return `username=${encodeURIComponent(S.username)}&password=${encodeURIComponent(S.password)}`; }

function fmtTime(utcStr) {
  if (!utcStr) return "";
  try {
    // Handle "2026-05-10 18:00:00" or ISO format or numeric timestamp
    let d;
    if (typeof utcStr === "number") d = new Date(utcStr * 1000);
    else d = new Date(utcStr.replace(" ","T") + (utcStr.includes("Z") || utcStr.includes("+") ? "" : "Z"));
    return d.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit",timeZone:S.prefs.timezone,hour12:false});
  } catch(_){ return String(utcStr).slice(11,16); }
}

function logoUrl(url) {
  if (!url) return null;
  return `/logo?url=${encodeURIComponent(url)}`;
}

async function apiGet(url) {
  const r = await fetch(url);
  if (!r.ok){ const e=await r.json().catch(()=>{}); throw new Error((e&&e.error)||`Error ${r.status}`); }
  return r.json();
}
async function xcGet(action, extra={}) {
  let url=`/api/xc/${action}?${creds()}`;
  for (const [k,v] of Object.entries(extra)) url+=`&${k}=${encodeURIComponent(v)}`;
  return apiGet(url);
}

// ── Boot ──────────────────────────────────────────────────────────
window.addEventListener("DOMContentLoaded", () => {
  bindEvents();
  populateTimezones();
  showScreen("login");
});

function showScreen(n) {
  $("login-screen").classList.toggle("active", n==="login");
  $("app-screen").classList.toggle("active",   n==="app");
}
function showLoading(){ $("loading-overlay").classList.remove("hidden"); }
function hideLoading(){ $("loading-overlay").classList.add("hidden"); }
function setProgress(pct,msg,detail){
  $("progress-bar").style.width=pct+"%";
  if (msg!==undefined)    $("load-msg").textContent=msg;
  if (detail!==undefined) $("load-detail").textContent=detail||"\u00a0";
}

// ── Events ────────────────────────────────────────────────────────
function bindEvents() {
  $("btn-login").addEventListener("click", doLogin);
  ["inp-user","inp-pass"].forEach(id=>$(id).addEventListener("keydown",e=>e.key==="Enter"&&doLogin()));
  $("btn-logout").addEventListener("click", doLogout);

  // Desktop nav buttons
  document.querySelectorAll(".nav-btn").forEach(b=>b.addEventListener("click",()=>{
    document.querySelectorAll(".nav-btn").forEach(x=>x.classList.remove("active"));
    b.classList.add("active");
    openTab(b.dataset.tab);
  }));

  // Desktop search
  const si=$("search-input");
  if (si) si.addEventListener("input",e=>filterChannels(e.target.value));

  // Mobile search
  const ms=$("mobile-search-input");
  if (ms) ms.addEventListener("input",e=>filterChannels(e.target.value));

  $("btn-fav").addEventListener("click", toggleFav);
  $("guide-search").addEventListener("input",e=>filterGuide(e.target.value));
  window.addEventListener("beforeunload",()=>stopStream());
}

// ── Tabs ──────────────────────────────────────────────────────────
function openTab(tab) {
  // Close all overlays
  ["favourites","guide","settings","categories"].forEach(t=>$(`tab-${t}`)?.classList.add("hidden"));

  if (tab==="live") {
    // Desktop: already on live, nothing to do
    // Mobile: go to channels view
    if (mob()) setMobileView("channels");
    return;
  }

  // Open the requested tab overlay
  const el = $(`tab-${tab}`);
  if (el) el.classList.remove("hidden");

  if (tab==="favourites") renderFavourites();
  if (tab==="guide")      loadGuide();
  if (tab==="settings")   loadSettingsTab();

  // Mobile: show channels pane beneath the overlay
  if (mob()) setMobileView("channels");
}

function closeTab(tab) {
  $(`tab-${tab}`)?.classList.add("hidden");
  // Reset nav to live/channels
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.tab==="live"));
  document.querySelectorAll(".bnav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view==="channels"));
}
window.closeTab=closeTab;

// ── Mobile view switching ─────────────────────────────────────────
function setMobileView(view) {
  const body=$("app-body");
  if (!body) return;
  body.classList.remove("view-channels","view-player");
  body.classList.add(view==="player"?"view-player":"view-channels");
}

function mobileNav(view) {
  // Update bottom nav active state
  document.querySelectorAll(".bnav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view===view));

  if (view==="channels") {
    // Close any overlays, show channel list
    ["favourites","guide","settings","categories"].forEach(t=>$(`tab-${t}`)?.classList.add("hidden"));
    document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.tab==="live"));
    setMobileView("channels");
  } else if (view==="player") {
    ["favourites","guide","settings","categories"].forEach(t=>$(`tab-${t}`)?.classList.add("hidden"));
    setMobileView("player");
  } else {
    // Guide, Favourites, Settings — show as overlay on top of channels
    setMobileView("channels");
    openTabOverlayOnly(view);
  }
}
window.mobileNav=mobileNav;

// Open overlay without triggering mobile view switch (called from mobileNav)
function openTabOverlayOnly(tab) {
  ["favourites","guide","settings","categories"].forEach(t=>$(`tab-${t}`)?.classList.add("hidden"));
  const el=$(`tab-${tab}`);
  if (el) el.classList.remove("hidden");
  if (tab==="favourites")  renderFavourites();
  if (tab==="guide")       loadGuide();
  if (tab==="settings")    loadSettingsTab();
  if (tab==="categories")  renderMobileCategories();
}

// ── Login ─────────────────────────────────────────────────────────
async function doLogin() {
  const username=$("inp-user").value.trim(), password=$("inp-pass").value.trim();
  const errEl=$("login-error"), btn=$("btn-login");
  if (!username||!password){errEl.textContent="Fill in all fields.";errEl.classList.remove("hidden");return;}
  btn.disabled=true; btn.textContent="Connecting…";
  errEl.classList.add("hidden"); showLoading(); setProgress(5,"Authenticating…","");
  try {
    const auth=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username,password})}).then(r=>r.json());
    if (!auth.ok) throw new Error(auth.error||"Login failed");
    S.username=username; S.password=password;

    setProgress(15,"Loading preferences…","");
    const prefs=await fetch(`/api/prefs/${encodeURIComponent(username)}`).then(r=>r.json()).catch(()=>({}));
    S.prefs={...S.prefs,...prefs};

    if(S.prefs.advanced)fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.prefs.advanced)}).catch(()=>{});
    setProgress(30,"Fetching categories…","");
    S.categories=await xcGet("get_live_categories")||[];

    setProgress(60,"Fetching channels…",`${S.categories.length} categories`);
    S.channels=await xcGet("get_live_streams")||[];
    S.filtered=S.channels;

    setProgress(80,"Loading favourites…","");
    S.favourites=await fetch(`/api/favs/${encodeURIComponent(username)}`).then(r=>r.json()).catch(()=>[]);

    setProgress(100,`Ready — ${S.channels.length} channels`,"");
    await new Promise(r=>setTimeout(r,300));
    hideLoading(); showScreen("app");
    renderCategories(); renderChannels(S.channels);

    // Fetch EPG for all channels in background after UI is shown
    fetchAllEpg();

    // Mobile starts on channels view
    if (mob()) setMobileView("channels");
  } catch(err){
    hideLoading(); errEl.textContent=err.message; errEl.classList.remove("hidden");
    S.username=""; S.password="";
  } finally { btn.disabled=false; btn.textContent="Connect"; }
}

function doLogout(){
  stopStream();
  S.username=""; S.password=""; S.categories=[]; S.channels=[]; S.filtered=[];
  S.currentChannel=null; S.epgCache={}; S.guideData=[]; S.favourites=[];
  $("inp-user").value=""; $("inp-pass").value="";
  $("login-error").classList.add("hidden");
  showScreen("login");
}

// ── Categories ────────────────────────────────────────────────────
function renderCategories(){
  const list=$("category-list"); list.innerHTML="";
  const all=makeCatEl({category_id:"all",category_name:"All Channels"});
  all.classList.add("active"); list.appendChild(all);
  S.categories.forEach(c=>list.appendChild(makeCatEl(c)));
}
function makeCatEl(cat){
  const el=document.createElement("div"); el.className="cat-item";
  el.innerHTML=`<span class="cat-dot"></span>${esc(cat.category_name)}`;
  el.addEventListener("click",()=>{
    document.querySelectorAll(".cat-item").forEach(c=>c.classList.remove("active"));
    el.classList.add("active");
    S.filtered=cat.category_id==="all"?S.channels:S.channels.filter(c=>String(c.category_id)===String(cat.category_id));
    renderChannels(S.filtered);
    $("search-input")&&($("search-input").value="");
    $("mobile-search-input")&&($("mobile-search-input").value="");
  });
  return el;
}

// ── Channels ──────────────────────────────────────────────────────
function renderChannels(list){
  const el=$("channel-list");
  if (!list.length){el.innerHTML='<div class="empty">No channels found</div>';return;}
  el.innerHTML=list.map(ch=>{
    const logo=ch.stream_icon?`<img src="${esc(logoUrl(ch.stream_icon))}" onerror="this.style.display='none'" loading="lazy"/>`:`<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    const active=S.currentChannel?.stream_id==ch.stream_id?" active":"";
    // Show current programme from EPG cache if available
    const epg = S.epgCache[ch.stream_id];
    const now = Date.now()/1000;
    const nowPlaying = epg ? epg.find(ep=>parseInt(ep.start_timestamp||0)<=now&&now<=parseInt(ep.stop_timestamp||0)) : null;
    const nowTitle = nowPlaying ? b64(nowPlaying.title||"").trim() : "";
    return `<div class="ch-item${active}" data-id="${ch.stream_id}">
      <div class="ch-logo">${logo}</div>
      <div class="ch-info">
        <div class="ch-name">${esc(ch.name||"Channel")}</div>
        <div class="ch-num">#${ch.num||ch.stream_id}${nowTitle?` · <span class="ch-now">${esc(nowTitle)}</span>`:""}</div>
      </div>
      <span class="ch-live"></span>
    </div>`;
  }).join("");
  el.querySelectorAll(".ch-item").forEach(el=>{
    el.addEventListener("click", ()=>{
      selectChannel(el.dataset.id);
      if (mob()) {
        setMobileView("player");
        document.querySelectorAll(".bnav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view==="player"));
      }
    });
  });
}
function filterChannels(q){
  q=q.toLowerCase();
  S.filtered=q?S.channels.filter(c=>(c.name||"").toLowerCase().includes(q)):S.channels;
  renderChannels(S.filtered);
  // Sync both search inputs
  if($("search-input")&&$("search-input").value!==q) $("search-input").value=q;
  if($("mobile-search-input")&&$("mobile-search-input").value!==q) $("mobile-search-input").value=q;
}

// ── Player ────────────────────────────────────────────────────────
let _selectDebounce = null;
async function selectChannel(id){
  if (S.currentChannel?.stream_id == id && S.hlsInstance) return;
  clearTimeout(_selectDebounce);
  _selectDebounce = setTimeout(() => _doSelectChannel(id), 150);
}
async function _doSelectChannel(id){
  const ch=S.channels.find(c=>c.stream_id==id)||S.favourites.find(c=>c.stream_id==id);
  if (!ch) return;
  stopStream();
  S.currentChannel=ch;
  document.querySelectorAll(".ch-item").forEach(el=>el.classList.toggle("active",el.dataset.id==id));
  $("player-placeholder").style.display="flex";
  $("player-placeholder").innerHTML=`<span class="ph-icon" style="animation:pulse 1.2s ease-in-out infinite">⏳</span><span>Buffering…</span>`;
  $("video").style.display="none";
  $("now-playing").style.display="flex";
  $("np-name").textContent=ch.name||"";
  $("np-epg").textContent="";
  updateFavBtn();
  try {
    const oldSid=P.lastSessionId; P.lastSessionId=null;
    const r=await fetch("/api/stream/start",{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username:S.username,password:S.password,streamId:ch.stream_id,sessionId:oldSid||null,safari:/Safari/i.test(navigator.userAgent)&&!/Chrome|CriOS|FxiOS|EdgiOS|OPiOS|android/i.test(navigator.userAgent)})
    });
    const d=await r.json();
    if(!r.ok) throw new Error(d.error||"Stream failed");
    P.sessionId=d.sessionId; P.lastSessionId=d.sessionId;
    startHeartbeat(d.sessionId);
    if(d.audioOnly){
      $("player-placeholder").style.display="flex";
      $("player-placeholder").innerHTML=`<span class="ph-icon">🎵</span><span>${esc(ch.name||"Audio Stream")}</span>`;
      $("video").style.display="none";
    } else {
      $("player-placeholder").style.display="none";
      $("video").style.display="block";
    }
    playStream(d.url, d.audioOnly||false, d.hlsCfg||{});
  } catch(err){
    $("player-placeholder").innerHTML=`<span class="ph-icon">⚠</span><span>${esc(err.message)}</span>`;
    $("video").style.display="none";
    $("np-epg").textContent="Unavailable";
  }
  loadEpg(ch.stream_id);
}

// Use HLS.js on ALL browsers including Safari — identical behaviour everywhere.
// HLS.js supports Safari via overrideNative since v1.0.
// This eliminates the two-code-path problem that caused inconsistent playback.
// ── Player ───────────────────────────────────────────────────────
var _ua       = navigator.userAgent;
var _isIOS    = /iPhone|iPad|iPod/i.test(_ua);
var _isSafari = _isIOS || (/Safari/i.test(_ua) && !/Chrome|CriOS|FxiOS|EdgiOS|android/i.test(_ua));

function playStream(url, audioOnly, hlsCfg) {
  stopHls();
  audioOnly = !!audioOnly;
  hlsCfg    = hlsCfg || {};

  var vid      = $("video");
  vid.style.display = "block";
  vid.playsInline   = true;
  vid.muted         = false;

  var segSecs  = hlsCfg.segSecs    || 2;
  var fwdPad   = hlsCfg.forwardPad || 3;
  var backPad  = hlsCfg.backPad    || 2;

  function tryPlay() {
    var p = vid.play();
    if (p) p.catch(function() {
      // Autoplay blocked — mute and try again, then unmute
      vid.muted = true;
      vid.play().then(function() {
        setTimeout(function() { vid.muted = false; }, 300);
      }).catch(function() {});
    });
  }

  // iOS has no MSE at all — only native HLS works
  // macOS Safari: use native HLS too — HLS.js MSE on Safari is unreliable for live
  if (_isSafari) {
    console.log("[player] native HLS (" + (_isIOS ? "iOS" : "macOS Safari") + ")");
    vid.src = url;
    vid.load();
    vid.addEventListener("canplay", function onCP() {
      vid.removeEventListener("canplay", onCP);
      tryPlay();
    });

    // Stall + drift watchdog
    var _lastT = null, _stalls = 0;
    S._nativeTimer = setInterval(function() {
      if (vid.paused || vid.ended || vid.readyState < 2) return;
      if (_lastT === null) { _lastT = vid.currentTime; return; }
      if (vid.currentTime !== _lastT) {
        _stalls = 0;
        // Drift check — snap if >4 segs behind live edge
        if (vid.seekable && vid.seekable.length) {
          var edge  = vid.seekable.end(vid.seekable.length - 1);
          var drift = edge - vid.currentTime;
          if (drift > segSecs * 4) {
            console.log("[native] drift=" + drift.toFixed(1) + "s snapping");
            vid.currentTime = Math.max(0, edge - segSecs * 1.5);
          }
        }
        _lastT = vid.currentTime;
      } else if (++_stalls >= 3) {
        console.warn("[native] stall — reloading");
        _lastT = null; _stalls = 0;
        vid.src = url; vid.load();
        vid.addEventListener("canplay", function onR() {
          vid.removeEventListener("canplay", onR);
          tryPlay();
        });
      }
    }, segSecs * 1000);
    return;
  }

  // Chrome / Firefox / Edge — HLS.js
  if (!Hls.isSupported()) {
    vid.src = url; tryPlay(); return;
  }

  console.log("[player] HLS.js");
  var hls = new Hls({
    enableWorker:               true,
    lowLatencyMode:             false,
    // Forward buffer — seconds ahead of playhead
    maxBufferLength:            audioOnly ? 60  : fwdPad * segSecs,
    maxMaxBufferLength:         audioOnly ? 120 : fwdPad * segSecs * 2,
    // Back buffer — seconds behind playhead for stall recovery
    backBufferLength:           audioOnly ? 30  : backPad * segSecs,
    // Live sync — target this many segments behind live edge
    liveSyncDurationCount:        fwdPad,
    liveMaxLatencyDurationCount:  fwdPad + backPad + 1,
    liveSyncOnStallEnabled:       true,
    // Fragment loading
    fragLoadingTimeOut:           20000,
    fragLoadingMaxRetry:          6,
    fragLoadingRetryDelay:        500,
    fragLoadingMaxRetryTimeout:   4000,
    // Stall recovery
    nudgeMaxRetry:                8,
    nudgeOffset:                  0.2,
    maxStarvationDelay:           audioOnly ? 20 : Math.max(backPad * segSecs, 4),
    // Manifest
    manifestLoadingTimeOut:       15000,
    manifestLoadingMaxRetry:      4,
    levelLoadingTimeOut:          15000,
    levelLoadingMaxRetry:         4,
  });
  hls.loadSource(url);
  hls.attachMedia(vid);
  hls.on(Hls.Events.MANIFEST_PARSED, function() { tryPlay(); });
  hls.on(Hls.Events.ERROR, function(_, d) {
    if (!d.fatal) return;
    console.warn("[hls] fatal", d.type, d.details);
    if      (d.type === Hls.ErrorTypes.NETWORK_ERROR) setTimeout(function() { hls.startLoad(); }, 2000);
    else if (d.type === Hls.ErrorTypes.MEDIA_ERROR)   hls.recoverMediaError();
    else { hls.destroy(); S.hlsInstance = null; }
  });
  S.hlsInstance = hls;
}

function stopHls() {
  if (S.hlsInstance)  { S.hlsInstance.destroy(); S.hlsInstance = null; }
  if (S._nativeTimer) { clearInterval(S._nativeTimer); S._nativeTimer = null; }
  var vid = $("video");
  vid.pause(); vid.removeAttribute("src"); vid.load();
  vid.style.display = "none";
}

function stopStream(){
  stopHls();
  clearInterval(P.heartbeat); P.heartbeat=null;
  if(P.sessionId){
    const sid=P.sessionId; P.lastSessionId=sid; P.sessionId=null;
    fetch(`/api/stream/stop/${sid}`,{method:"POST"}).catch(()=>{});
  }
  $("epg-strip").innerHTML="";
}
function startHeartbeat(sid){
  clearInterval(P.heartbeat);
  P.heartbeat=setInterval(()=>{
    if(P.sessionId===sid) fetch(`/api/stream/heartbeat/${sid}`,{method:"POST"}).catch(()=>{});
    else clearInterval(P.heartbeat);
  },5000);
}

// ── Background EPG fetch for all channels ────────────────────────
async function fetchAllEpg() {
  // Fetch EPG in small batches to avoid hammering the server
  const BATCH = 20;
  const channels = S.channels;
  for (let i = 0; i < channels.length; i += BATCH) {
    const batch = channels.slice(i, i + BATCH);
    await Promise.allSettled(batch.map(async ch => {
      if (S.epgCache[ch.stream_id]) return; // already cached
      try {
        const d = await apiGet(`/api/epg/${ch.stream_id}?${creds()}`);
        S.epgCache[ch.stream_id] = d.epg_listings || [];
        // Update channel list item with now-playing if visible
        updateChannelNowPlaying(ch.stream_id);
      } catch(_) {}
    }));
    // Small pause between batches to avoid overwhelming XC-Menu
    await new Promise(r => setTimeout(r, 200));
  }
}

// ── EPG ───────────────────────────────────────────────────────────
async function loadEpg(streamId){
  if (S.epgCache[streamId]){renderEpg(S.epgCache[streamId]);return;}
  try {
    const d=await apiGet(`/api/epg/${streamId}?${creds()}`);
    S.epgCache[streamId]=d.epg_listings||[];
    renderEpg(S.epgCache[streamId]);
    // Update the channel list item to show now playing
    updateChannelNowPlaying(streamId);
  } catch(_){}
}

function updateChannelNowPlaying(streamId) {
  const el = document.querySelector(`.ch-item[data-id="${streamId}"] .ch-num`);
  if (!el) return;
  const epg = S.epgCache[streamId];
  if (!epg) return;
  const now = Date.now()/1000;
  const nowPlaying = epg.find(ep=>parseInt(ep.start_timestamp||0)<=now&&now<=parseInt(ep.stop_timestamp||0));
  const nowTitle = nowPlaying ? b64(nowPlaying.title||"").trim() : "";
  const ch = S.channels.find(c=>c.stream_id==streamId)||S.favourites.find(c=>c.stream_id==streamId);
  el.innerHTML = `#${(ch&&(ch.num||ch.stream_id))||streamId}${nowTitle?` · <span class="ch-now">${esc(nowTitle)}</span>`:""}`;
}
function renderEpg(listings){
  const now=Date.now()/1000;
  $("epg-strip").innerHTML=listings.slice(0,8).map(ep=>{
    const start=parseInt(ep.start_timestamp||0),stop=parseInt(ep.stop_timestamp||0);
    const isNow=start<=now&&now<=stop;
    const startTime=fmtTime(ep.start);
    const stopTime=stop?fmtTime(new Date(stop*1000).toISOString().replace("T"," ").slice(0,19)):"";
    const timeRange=stopTime?`${startTime} – ${stopTime}`:startTime;
    const title=b64(ep.title||"").trim();
    if (isNow) $("np-epg").textContent=`${timeRange}  ${title}`;
    return `<div class="epg-card${isNow?" now":""}">
      <div class="epg-time">${esc(timeRange)}</div>
      <div class="epg-title">${esc(title||"—")}</div>
    </div>`;
  }).join("");
}

// ── Favourites ────────────────────────────────────────────────────
function updateFavBtn(){
  const ch=S.currentChannel; if (!ch) return;
  const isFav=S.favourites.some(f=>f.stream_id==ch.stream_id);
  $("btn-fav").textContent=isFav?"★":"☆";
  $("btn-fav").classList.toggle("active",isFav);
}
function toggleFav(){
  const ch=S.currentChannel; if (!ch) return;
  const idx=S.favourites.findIndex(f=>f.stream_id==ch.stream_id);
  if (idx===-1) S.favourites.push({stream_id:ch.stream_id,name:ch.name,stream_icon:ch.stream_icon,num:ch.num,category_id:ch.category_id});
  else S.favourites.splice(idx,1);
  updateFavBtn();
  fetch(`/api/favs/${encodeURIComponent(S.username)}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.favourites)});
}
function renderFavourites(){
  const body=$("fav-body");
  if (!S.favourites.length){body.innerHTML='<div class="empty">No favourites yet.<br>Press ☆ while watching a channel.</div>';return;}
  const grid=document.createElement("div"); grid.className="fav-grid";
  grid.innerHTML=S.favourites.map(ch=>{
    const logo=ch.stream_icon?`<img src="${esc(logoUrl(ch.stream_icon))}" onerror="this.style.display='none'" loading="lazy"/>`:`<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    return `<div class="fav-card" data-id="${ch.stream_id}"><button class="fav-remove" data-id="${ch.stream_id}">✕</button><div class="ch-logo">${logo}</div><div class="ch-name">${esc(ch.name||"")}</div></div>`;
  }).join("");
  body.innerHTML=""; body.appendChild(grid);
  grid.querySelectorAll(".fav-card").forEach(card=>card.addEventListener("click",e=>{
    if (e.target.classList.contains("fav-remove")) return;
    const ch=S.favourites.find(f=>f.stream_id==card.dataset.id);
    if (ch){ selectChannel(ch.stream_id); closeTab("favourites"); if(mob()){setMobileView("player");document.querySelectorAll(".bnav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view==="player"));} }
  }));
  grid.querySelectorAll(".fav-remove").forEach(btn=>btn.addEventListener("click",e=>{
    e.stopPropagation();
    S.favourites=S.favourites.filter(f=>f.stream_id!=btn.dataset.id);
    fetch(`/api/favs/${encodeURIComponent(S.username)}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.favourites)});
    renderFavourites();
  }));
}

// ── Guide ─────────────────────────────────────────────────────────
async function loadGuide(){
  const body=$("guide-body");
  if (!S.favourites.length){body.innerHTML='<div class="empty">Add channels to favourites to see the guide.</div>';return;}
  body.innerHTML='<div class="spinner">Loading guide…</div>';
  const now=Date.now()/1000;
  const rows=await Promise.allSettled(S.favourites.map(async ch=>{
    let listings=S.epgCache[ch.stream_id];
    if (!listings){
      try{const d=await apiGet(`/api/epg/${ch.stream_id}?${creds()}`);listings=d.epg_listings||[];S.epgCache[ch.stream_id]=listings;}
      catch(_){listings=[];}
    }
    return {ch,listings};
  }));
  S.guideData=rows.filter(r=>r.status==="fulfilled").map(r=>r.value);
  renderGuide(S.guideData);
}
function renderGuide(data){
  const body=$("guide-body");
  if (!data.length){body.innerHTML='<div class="empty">No guide data for your favourites.</div>';return;}
  const now=Date.now()/1000;
  const grid=document.createElement("div"); grid.className="guide-grid";
  grid.innerHTML=data.map(({ch,listings})=>{
    const logo=ch.stream_icon?`<img src="${esc(logoUrl(ch.stream_icon))}" onerror="this.style.display='none'" loading="lazy"/>`:`<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    const progs=listings.slice(0,8).map(ep=>{
      const start=parseInt(ep.start_timestamp||0),stop=parseInt(ep.stop_timestamp||0);
      const isNow=start<=now&&now<=stop;
      const startTime=fmtTime(ep.start);
      // Build end time from stop_timestamp
      const stopTime=ep.stop ? fmtTime(ep.stop) : (stop ? fmtTime(new Date(stop*1000).toISOString().replace("T"," ").slice(0,19)) : "");
      const timeRange=stopTime ? `${startTime} – ${stopTime}` : startTime;
      const title=b64(ep.title||"").trim();
      return `<div class="guide-program${isNow?" now":""}">
        <div class="gp-time">${esc(timeRange)}</div>
        <div class="gp-title">${esc(title||"—")}</div>
      </div>`;
    }).join("")||'<div class="guide-program"><div class="gp-time">—</div><div class="gp-title">No guide data</div></div>';
    return `<div class="guide-row"><div class="guide-ch" data-id="${ch.stream_id}"><div class="guide-ch-logo">${logo}</div><span class="guide-ch-name">${esc(ch.name||"")}</span><span class="guide-ch-watch">▶</span></div><div class="guide-programs">${progs}</div></div>`;
  }).join("");
  body.innerHTML=""; body.appendChild(grid);
  grid.querySelectorAll(".guide-ch").forEach(el=>el.addEventListener("click",()=>{
    const ch=data.find(d=>d.ch.stream_id==el.dataset.id)?.ch;
    if (ch){ selectChannel(ch.stream_id); closeTab("guide"); if(mob()){setMobileView("player");document.querySelectorAll(".bnav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view==="player"));} }
  }));
}
function filterGuide(q){
  q=q.toLowerCase();
  renderGuide(q?S.guideData.filter(d=>(d.ch.name||"").toLowerCase().includes(q)):S.guideData);
}

// ── Settings ──────────────────────────────────────────────────────
function populateTimezones(){
  const sel=$("pref-timezone");
  ["America/Vancouver","America/Edmonton","America/Regina","America/Winnipeg",
   "America/Toronto","America/Halifax","America/St_Johns",
   "America/Los_Angeles","America/Denver","America/Phoenix","America/Chicago","America/New_York",
   "Pacific/Honolulu","America/Anchorage",
   "Europe/London","Europe/Paris","Europe/Berlin","Europe/Helsinki","Europe/Moscow",
   "Asia/Dubai","Asia/Kolkata","Asia/Singapore","Asia/Tokyo","Australia/Sydney","Pacific/Auckland","UTC"]
  .forEach(z=>{const o=document.createElement("option");o.value=z;o.textContent=z.replace(/_/g," ");sel.appendChild(o);});
}
async function loadSettingsTab(){
  try {
    const r=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username:S.username,password:S.password})}).then(r=>r.json());
    const exp=r.expiry?new Date(parseInt(r.expiry)*1000).toLocaleDateString():"—";
    $("acct-info").innerHTML=`<b>${S.username}</b><br>Status: ${r.status||"—"}<br>Connections: ${r.connections}<br>Expires: ${exp}`;
  } catch(_){$("acct-info").textContent="Could not load account info.";}
  $("pref-timezone").value=S.prefs.timezone||"UTC";
}
async function savePrefs(){
  S.prefs.timezone=$("pref-timezone").value;
  const msg=$("prefs-msg");
  try {
    await fetch(`/api/prefs/${encodeURIComponent(S.username)}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(S.prefs)});
    msg.style.color="var(--green)"; msg.textContent="✓ Saved!"; msg.classList.remove("hidden");
    setTimeout(()=>msg.classList.add("hidden"),2000);
    S.epgCache={}; $("epg-strip").innerHTML="";
    if (S.currentChannel) loadEpg(S.currentChannel.stream_id);
  } catch(e){msg.style.color="var(--red)"; msg.textContent="Error: "+e.message; msg.classList.remove("hidden");}
}
window.savePrefs=savePrefs;

// ── Mobile categories ─────────────────────────────────────────────
function renderMobileCategories() {
  var body = $("cat-body"); if (!body) return;
  var items = [{id:"all", name:"All Channels"}].concat(
    S.categories.map(function(c) { return {id: c.category_id, name: c.category_name}; })
  );
  body.innerHTML = items.map(function(item) {
    return '<div class="mob-cat-item" data-cat="' + esc(String(item.id)) + '">' + esc(item.name) + '</div>';
  }).join("");
  body.onclick = function(e) {
    var el = e.target.closest(".mob-cat-item"); if (!el) return;
    var catId = el.dataset.cat;
    S.filtered = catId === "all" ? S.channels : S.channels.filter(function(ch) {
      return String(ch.category_id) === String(catId);
    });
    renderChannels(S.filtered);
    if ($("search-input"))        $("search-input").value = "";
    if ($("mobile-search-input")) $("mobile-search-input").value = "";
    closeTab("categories");
    mobileNav("channels");
  };
}

// ── userStop ──────────────────────────────────────────────────────
function userStop() {
  stopStream();
  S.currentChannel = null;
  $("now-playing").style.display = "none";
  $("player-placeholder").style.display = "flex";
  $("player-placeholder").innerHTML = '<span class="ph-icon">▶</span><span>Select a channel to watch</span>';
  document.querySelectorAll(".ch-item").forEach(function(el) { el.classList.remove("active"); });
}
window.userStop = userStop;

async function stopAllStreams() {
  var msg = $("stopall-msg");
  try {
    userStop();
    var d = await fetch("/api/stream/stopall", {method:"POST"}).then(function(r){return r.json();});
    if (msg) {
      msg.textContent = d.stopped > 0
        ? "Stopped " + d.stopped + " stream" + (d.stopped===1?"":"s")
        : "No active streams";
      msg.className = "stopall-msg stopall-ok";
      setTimeout(function(){ msg.className = "stopall-msg hidden"; }, 3000);
    }
  } catch(e) {
    if (msg) {
      msg.textContent = "Error: " + e.message;
      msg.className = "stopall-msg stopall-err";
      setTimeout(function(){ msg.className = "stopall-msg hidden"; }, 3000);
    }
  }
}
window.stopAllStreams = stopAllStreams;

// ── Settings tabs ─────────────────────────────────────────────────
function switchStab(btn) {
  document.querySelectorAll(".stab-btn").forEach(function(b) { b.classList.remove("active"); });
  document.querySelectorAll(".stab-panel").forEach(function(p) { p.classList.remove("active"); });
  btn.classList.add("active");
  var panel = document.getElementById("stab-" + btn.dataset.stab);
  if (panel) panel.classList.add("active");
  if (btn.dataset.stab === "ffmpeg") loadFfmpegTab();
  if (btn.dataset.stab === "stream") loadStreamSettings();
}
window.switchStab = switchStab;

// ── Stream settings tab ───────────────────────────────────────────
var _streamPrefs = {};

function loadStreamSettings() {
  var a = _streamPrefs;
  function sv(id, v) { var el = document.getElementById(id); if (el) el.value = String(v); }
  function sc(id, v) { var el = document.getElementById(id); if (el) el.checked = !!v; }
  sv("adv-ua",              a.ua              || "chrome");
  sv("adv-seg-secs",        a.segSecs         || "2");
  sv("adv-prebuf",          a.prebuf          || "2");
  sv("adv-window",          a.window          || "60");
  sv("adv-idle",            a.idle            || "20");
  sv("adv-stall-restart",   a.stallRestart    || "10");
  sv("adv-forward-pad",     a.forwardPad      || "3");
  sv("adv-back-pad",        a.backPad         || "3");
  sc("adv-force-aac",       !!a.forceAac);
  sv("adv-audio-br",        a.audioBr         || "192");
  sv("adv-audio-sr",        a.audioSr         || "48000");
  sc("adv-aresample",       a.aresample !== false);
  sv("adv-audio-prebuf",    a.audioPrebuf     || "4");
  sc("adv-safari-transcode",a.safariTranscode !== false);
  sv("adv-safari-profile",  a.safariProfile   || "baseline");
  sv("adv-safari-preset",   a.safariPreset    || "ultrafast");
  sv("adv-safari-vbr",      a.safariVbr       || "0");
  sc("adv-genpts",          a.genpts !== false);
  sc("adv-discard-corrupt", a.discardCorrupt !== false);
  sv("adv-ffmpeg-input",    a.ffmpegInput     || "");
  sv("adv-ffmpeg-extra",    a.ffmpegExtra     || "");
}

async function saveStreamSettings() {
  var msg = document.getElementById("stream-msg");
  function gv(id, d) { var el = document.getElementById(id); return el ? el.value : (d || ""); }
  function gc(id, d) { var el = document.getElementById(id); return el ? el.checked : !!d; }
  _streamPrefs = {
    ua:             gv("adv-ua",             "chrome"),
    segSecs:        gv("adv-seg-secs",       "2"),
    prebuf:         gv("adv-prebuf",         "2"),
    window:         gv("adv-window",         "60"),
    idle:           gv("adv-idle",           "20"),
    stallRestart:   gv("adv-stall-restart",  "10"),
    forwardPad:     gv("adv-forward-pad",   "3"),
    backPad:        gv("adv-back-pad",      "3"),
    forceAac:       gc("adv-force-aac",      false),
    audioBr:        gv("adv-audio-br",       "192"),
    audioSr:        gv("adv-audio-sr",       "48000"),
    aresample:      gc("adv-aresample",      true),
    audioPrebuf:    gv("adv-audio-prebuf",   "4"),
    safariTranscode:gc("adv-safari-transcode",true),
    safariProfile:  gv("adv-safari-profile", "baseline"),
    safariPreset:   gv("adv-safari-preset",  "ultrafast"),
    safariVbr:      gv("adv-safari-vbr",     "0"),
    genpts:         gc("adv-genpts",         true),
    discardCorrupt: gc("adv-discard-corrupt",true),
    ffmpegInput:    gv("adv-ffmpeg-input",   ""),
    ffmpegExtra:    gv("adv-ffmpeg-extra",   ""),
  };
  try {
    S.prefs.streamSettings = _streamPrefs;
    await fetch("/api/prefs/" + encodeURIComponent(S.username), {
      method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(S.prefs)
    });
    await fetch("/api/settings", {
      method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(_streamPrefs)
    });
    if (msg) {
      msg.style.color = "var(--green)"; msg.textContent = "✓ Saved and applied!";
      msg.classList.remove("hidden");
      setTimeout(function() { msg.classList.add("hidden"); }, 2500);
    }
  } catch(e) {
    if (msg) { msg.style.color = "var(--red)"; msg.textContent = "Error: " + e.message; msg.classList.remove("hidden"); }
  }
}
window.saveStreamSettings = saveStreamSettings;

function resetStreamSettings() {
  if (!confirm("Reset all stream settings to defaults?")) return;
  var defaults = {
    ua: "chrome",
    segSecs: "2", prebuf: "2", window: "60", idle: "20", stallRestart: "10", forwardPad: "3", backPad: "3",
    forceAac: false, audioBr: "192", audioSr: "48000",
    aresample: true, audioPrebuf: "4",
    safariTranscode: true, safariProfile: "baseline", safariPreset: "ultrafast", safariVbr: "0",
    genpts: true, discardCorrupt: true,
    ffmpegInput: "", ffmpegExtra: "",
  };
  _streamPrefs = Object.assign({}, defaults);
  loadStreamSettings();
  // Apply to server
  var msg = document.getElementById("stream-msg");
  fetch("/api/settings", {
    method: "POST", headers: {"Content-Type":"application/json"},
    body: JSON.stringify(defaults)
  }).then(function() {
    // Save to prefs too
    S.prefs.streamSettings = defaults;
    fetch("/api/prefs/" + encodeURIComponent(S.username), {
      method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(S.prefs)
    });
    if (msg) {
      msg.style.color = "var(--green)"; msg.textContent = "✓ Reset to defaults and applied";
      msg.classList.remove("hidden");
      setTimeout(function() { msg.classList.add("hidden"); }, 3000);
    }
  }).catch(function(e) {
    if (msg) { msg.style.color = "var(--red)"; msg.textContent = "Error: " + e.message; msg.classList.remove("hidden"); }
  });
}
window.resetStreamSettings = resetStreamSettings;

// ── FFmpeg command tab ────────────────────────────────────────────
async function loadFfmpegTab() {
  var el = document.getElementById("ffcmd-preview");
  if (el) {
    try {
      var d = await fetch("/api/ffcmd").then(function(r) { return r.json(); });
      el.textContent = "ffmpeg \\\n" + d.cmd.slice(1).map(function(a) { return "  " + a; }).join(" \\\n");
    } catch(e) { el.textContent = "Could not load preview."; }
  }
  var ta = document.getElementById("cmd-editor");
  var tog = document.getElementById("cmd-enabled");
  if (ta) {
    try {
      var d2 = await fetch("/api/ffcmd/custom").then(function(r) { return r.json(); });
      ta.value = d2.current || d2.default || "";
      if (tog) tog.checked = !!d2.isCustom;
    } catch(e) { ta.value = "Error: " + e.message; }
  }
}

async function saveCmd() {
  var ta = document.getElementById("cmd-editor");
  var tog = document.getElementById("cmd-enabled");
  var msg = document.getElementById("cmd-msg");
  if (!ta || !msg) return;
  msg.classList.add("hidden");
  try {
    var d = await fetch("/api/ffcmd/custom", {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({cmd: ta.value, enabled: tog ? tog.checked : true})
    }).then(function(r) { return r.json(); });
    msg.style.color = "var(--green)";
    msg.textContent = d.enabled ? "✓ Custom command active" : "✓ Saved (toggle on to activate)";
    msg.classList.remove("hidden");
    setTimeout(function() { msg.classList.add("hidden"); }, 4000);
  } catch(e) {
    msg.style.color = "var(--red)"; msg.textContent = "Error: " + e.message; msg.classList.remove("hidden");
  }
}
window.saveCmd = saveCmd;

async function resetCmd() {
  var msg = document.getElementById("cmd-msg");
  if (!confirm("Reset to default ffmpeg command and disable custom?")) return;
  try {
    var d = await fetch("/api/ffcmd/reset", {method:"POST"}).then(function(r) { return r.json(); });
    var ta = document.getElementById("cmd-editor");
    var tog = document.getElementById("cmd-enabled");
    if (ta) ta.value = d.default || "";
    if (tog) tog.checked = false;
    if (msg) {
      msg.style.color = "var(--green)"; msg.textContent = "✓ Reset to default";
      msg.classList.remove("hidden");
      setTimeout(function() { msg.classList.add("hidden"); }, 3000);
    }
    await loadFfmpegTab();
  } catch(e) {
    if (msg) { msg.style.color = "var(--red)"; msg.textContent = "Error: " + e.message; msg.classList.remove("hidden"); }
  }
}
window.resetCmd = resetCmd;

async function loadDefaultInEditor() {
  var ta = document.getElementById("cmd-editor"); if (!ta) return;
  try {
    var d = await fetch("/api/ffcmd/custom").then(function(r) { return r.json(); });
    ta.value = d.default || "";
  } catch(e) {}
}
window.loadDefaultInEditor = loadDefaultInEditor;

// ── Load stream prefs on login ────────────────────────────────────
// Patch doLogin to also restore stream settings
var _origDoLogin = window.doLogin;
// Instead: hook into the prefs load that already happens in doLogin
// We read S.prefs.streamSettings after login and apply to server
var _origHandlePrefs = null;
(function patchPrefsApply() {
  var origLoadSettingsTab = window.loadSettingsTab;
  window.loadSettingsTab = async function() {
    if (S.prefs.streamSettings) {
      _streamPrefs = S.prefs.streamSettings;
    }
    if (origLoadSettingsTab) await origLoadSettingsTab();
    loadStreamSettings();
  };
})();
