"use strict";

const S = {
  username:"", password:"",
  categories:[], channels:[], filtered:[],
  currentChannel:null, favourites:[],
  epgCache:{}, guideData:[],
  hlsInstance:null, sessionId:null, heartbeatTimer:null,
};

const $   = id => document.getElementById(id);
const esc = s  => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const b64 = s  => { try { return atob(s); } catch(_){ return s; } };

// Always use S.username at call time — never capture it in closures early
function favUrl() {
  if (!S.username) throw new Error("Not logged in");
  return `/api/favs/${encodeURIComponent(S.username)}`;
}
function saveFavourites() {
  if (!S.username) return;
  fetch(favUrl(), {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify(S.favourites),
  }).then(r=>r.json()).then(d=>console.log("[favs] saved:", d));
}
async function loadFavouritesFromServer(username) {
  const r = await fetch(`/api/favs/${encodeURIComponent(username)}`);
  const d = await r.json();
  console.log("[favs] loaded for", username, ":", d.length, "items");
  return d;
}

function creds() { return `username=${encodeURIComponent(S.username)}&password=${encodeURIComponent(S.password)}`; }

async function apiGet(url) {
  const r = await fetch(url);
  if (!r.ok) { const e = await r.json().catch(()=>{}); throw new Error((e&&e.error)||`Error ${r.status}`); }
  return r.json();
}
async function xcGet(action, extra={}) {
  let url = `/api/xc/${action}?${creds()}`;
  for (const [k,v] of Object.entries(extra)) url += `&${k}=${encodeURIComponent(v)}`;
  return apiGet(url);
}

// ── Boot ──────────────────────────────────────────────────────────
window.addEventListener("DOMContentLoaded", () => { bindEvents(); showScreen("login"); });

function showScreen(n) {
  $("login-screen").classList.toggle("active", n==="login");
  $("app-screen").classList.toggle("active",   n==="app");
}
function showLoading() { $("loading-overlay").classList.remove("hidden"); }
function hideLoading() { $("loading-overlay").classList.add("hidden"); }
function setProgress(pct, msg, detail) {
  $("progress-bar").style.width = pct + "%";
  if (msg    !== undefined) $("load-msg").textContent    = msg;
  if (detail !== undefined) $("load-detail").textContent = detail || "\u00a0";
}

function bindEvents() {
  $("btn-login").addEventListener("click", doLogin);
  ["inp-user","inp-pass"].forEach(id => $(id).addEventListener("keydown", e => e.key==="Enter" && doLogin()));
  $("btn-logout").addEventListener("click", doLogout);
  document.querySelectorAll(".nav-btn").forEach(b => b.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(x=>x.classList.remove("active"));
    b.classList.add("active"); openTab(b.dataset.tab);
  }));
  $("search-input").addEventListener("input", e => filterChannels(e.target.value));
  $("btn-fav").addEventListener("click", toggleFav);
  $("guide-search").addEventListener("input", e => filterGuide(e.target.value));
  window.addEventListener("beforeunload", () => stopStream());
}

// ── Login ─────────────────────────────────────────────────────────
async function doLogin() {
  const username = $("inp-user").value.trim();
  const password = $("inp-pass").value.trim();
  const errEl = $("login-error"), btn = $("btn-login");
  if (!username || !password) { errEl.textContent="Fill in all fields."; errEl.classList.remove("hidden"); return; }

  btn.disabled=true; btn.textContent="Connecting…";
  errEl.classList.add("hidden");
  showLoading(); setProgress(5,"Authenticating…","");

  try {
    const auth = await fetch("/api/login",{
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({username, password}),
    }).then(r=>r.json());
    if (!auth.ok) throw new Error(auth.error||"Login failed");

    // Set credentials BEFORE any further calls
    S.username = username;
    S.password = password;

    setProgress(25,"Fetching categories…",`Status: ${auth.status}`);
    S.categories = await xcGet("get_live_categories") || [];

    setProgress(55,"Fetching channels…",`${S.categories.length} categories`);
    S.channels = await xcGet("get_live_streams") || [];
    S.filtered = S.channels;

    setProgress(80,"Loading your favourites…","");
    // Load favourites for THIS user specifically
    S.favourites = await loadFavouritesFromServer(username);

    setProgress(100,`Ready — ${S.channels.length} channels`,"");
    await new Promise(r=>setTimeout(r,400));
    hideLoading(); showScreen("app");
    renderCategories(); renderChannels(S.channels);

  } catch(err) {
    hideLoading(); errEl.textContent=err.message; errEl.classList.remove("hidden");
    S.username=""; S.password="";
  } finally { btn.disabled=false; btn.textContent="Connect"; }
}

function doLogout() {
  stopStream();
  S.username=""; S.password="";
  S.categories=[]; S.channels=[]; S.filtered=[];
  S.currentChannel=null; S.epgCache={}; S.guideData=[]; S.favourites=[];
  $("inp-user").value=""; $("inp-pass").value="";
  $("login-error").classList.add("hidden");
  showScreen("login");
}

// ── Categories ────────────────────────────────────────────────────
function renderCategories() {
  const list = $("category-list"); list.innerHTML="";
  const all = makeCatEl({category_id:"all",category_name:"All Channels"});
  all.classList.add("active"); list.appendChild(all);
  S.categories.forEach(c=>list.appendChild(makeCatEl(c)));
}

function makeCatEl(cat) {
  const el = document.createElement("div");
  el.className="cat-item";
  el.innerHTML=`<span class="cat-dot"></span>${esc(cat.category_name)}`;
  el.addEventListener("click",()=>{
    document.querySelectorAll(".cat-item").forEach(c=>c.classList.remove("active"));
    el.classList.add("active");
    S.filtered = cat.category_id==="all" ? S.channels
      : S.channels.filter(c=>String(c.category_id)===String(cat.category_id));
    renderChannels(S.filtered); $("search-input").value="";
  });
  return el;
}

// ── Channels ──────────────────────────────────────────────────────
function renderChannels(list) {
  const el=$("channel-list");
  if (!list.length) { el.innerHTML='<div class="empty">No channels found</div>'; return; }
  el.innerHTML=list.map(ch=>{
    const logo=ch.stream_icon
      ?`<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      :`<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    const active=S.currentChannel?.stream_id==ch.stream_id?" active":"";
    return `<div class="ch-item${active}" data-id="${ch.stream_id}">
      <div class="ch-logo">${logo}</div>
      <div class="ch-info"><div class="ch-name">${esc(ch.name||"Channel")}</div><div class="ch-num">#${ch.num||ch.stream_id}</div></div>
      <span class="ch-live"></span>
    </div>`;
  }).join("");
  el.querySelectorAll(".ch-item").forEach(el=>el.addEventListener("click",()=>selectChannel(el.dataset.id)));
}

function filterChannels(q) {
  q=q.toLowerCase();
  S.filtered=q?S.channels.filter(c=>(c.name||"").toLowerCase().includes(q)):S.channels;
  renderChannels(S.filtered);
}

// ── Player ────────────────────────────────────────────────────────
async function selectChannel(id) {
  const ch=S.channels.find(c=>c.stream_id==id)||S.favourites.find(c=>c.stream_id==id);
  if (!ch) return;

  // Immediately kill existing stream + clear buffer before starting new one
  stopStream();

  S.currentChannel=ch;
  document.querySelectorAll(".ch-item").forEach(el=>el.classList.toggle("active",el.dataset.id==id));

  // Show buffering state
  $("player-placeholder").style.display="flex";
  $("player-placeholder").innerHTML=`<span class="ph-icon" style="animation:pulse 1s infinite">⏳</span><span>Buffering ${esc(ch.name||"")}…</span>`;
  $("video").style.display="none";
  $("now-playing").style.display="flex";
  $("np-name").textContent=ch.name||"";
  $("np-epg").textContent="Pre-buffering stream…";
  updateFavBtn();

  try {
    const r = await fetch("/api/stream/start",{
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({username:S.username, password:S.password, streamId:ch.stream_id, sessionId:S.sessionId}),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error||"Failed to start stream");
    S.sessionId=d.sessionId;
    startHeartbeat(d.sessionId);
    // Hide buffering placeholder and show video
    $("player-placeholder").style.display="none";
    $("video").style.display="block";
    playHls(d.url);
  } catch(err) {
    // Reset player placeholder on error — don't leave buffering spinner
    $("player-placeholder").style.display="flex";
    $("player-placeholder").innerHTML=`<span class="ph-icon">⚠</span><span>${err.message}</span>`;
    $("video").style.display="none";
    $("np-epg").textContent="⚠ "+err.message;
  }

  loadEpg(ch.stream_id);
}

function playHls(url) {
  stopHlsInstance();
  const vid=$("video");

  if (Hls.isSupported()) {
    const hls = new Hls({
      enableWorker:                true,
      lowLatencyMode:              false,
      startPosition:               0,      // play from start of buffered segments
      // Large buffer — server pre-fills 20s, HLS.js keeps 60s
      maxBufferLength:             60,
      maxMaxBufferLength:          120,
      backBufferLength:            30,
      // Live sync — stay 3 segments behind live edge (comfortable cushion)
      liveSyncDurationCount:       4,
      liveMaxLatencyDurationCount: 12,
      // Generous timeouts for IPTV
      fragLoadingTimeOut:          30000,
      fragLoadingMaxRetry:         8,
      fragLoadingRetryDelay:       1000,
      manifestLoadingTimeOut:      20000,
      manifestLoadingMaxRetry:     6,
      levelLoadingTimeOut:         20000,
      levelLoadingMaxRetry:        6,
      // Never give up on stalls
      maxStarvationDelay:          10,
      maxLoadingDelay:             10,
      nudgeOffset:                 0.2,
      nudgeMaxRetry:               20,
    });
    hls.loadSource(url);
    hls.attachMedia(vid);
    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      vid.play().catch(()=>{});
    });
    // Auto-recover from any error
    hls.on(Hls.Events.ERROR, (_, data) => {
      if (data.fatal) {
        console.warn("[HLS] fatal error:", data.type, data.details);
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
          setTimeout(() => hls.startLoad(), 2000);
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          hls.recoverMediaError();
        }
      }
    });
    hls.on(Hls.Events.FRAG_LOAD_EMERGENCY_ABORTED, () => {
      setTimeout(() => hls.startLoad(), 2000);
    });
    hls.on(Hls.Events.ERROR, (_,d) => {
      if (d.fatal) {
        if (d.type===Hls.ErrorTypes.NETWORK_ERROR) hls.startLoad();
        else if (d.type===Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError();
      }
    });
    S.hlsInstance=hls;
  } else if (vid.canPlayType("application/vnd.apple.mpegurl")) {
    vid.src=url; vid.play().catch(()=>{});
  }
}

function stopHlsInstance() {
  if (S.hlsInstance) { S.hlsInstance.destroy(); S.hlsInstance=null; }
  const vid=$("video");
  vid.pause(); vid.src="";
}

function stopStream() {
  stopHlsInstance();
  clearInterval(S.heartbeatTimer); S.heartbeatTimer=null;
  if (S.sessionId) {
    // Fire-and-forget — don't await, kill immediately
    const sid = S.sessionId;
    S.sessionId = null;
    fetch(`/api/stream/stop/${sid}`, {method:"POST"}).catch(()=>{});
  }
  $("epg-strip").innerHTML="";
  // Reset video element fully
  const vid = $("video");
  if (vid) { vid.pause(); vid.removeAttribute("src"); vid.load(); vid.style.display="none"; }
}

function startHeartbeat(sid) {
  clearInterval(S.heartbeatTimer);
  S.heartbeatTimer=setInterval(()=>{
    if (S.sessionId===sid) fetch(`/api/stream/heartbeat/${sid}`,{method:"POST"}).catch(()=>{});
    else clearInterval(S.heartbeatTimer);
  }, 5000);
}

// ── EPG ───────────────────────────────────────────────────────────
async function loadEpg(streamId) {
  if (S.epgCache[streamId]) { renderEpg(S.epgCache[streamId]); return; }
  try {
    const d=await apiGet(`/api/epg/${streamId}?${creds()}`);
    S.epgCache[streamId]=d.epg_listings||[];
    renderEpg(S.epgCache[streamId]);
  } catch(_) {}
}

function renderEpg(listings) {
  const now=Date.now()/1000;
  $("epg-strip").innerHTML=listings.slice(0,8).map(ep=>{
    const start=parseInt(ep.start_timestamp||0),stop=parseInt(ep.stop_timestamp||0);
    const isNow=start<=now&&now<=stop;
    const time=ep.start?ep.start.slice(11,16):"";
    const title=b64(ep.title||"").trim();
    if (isNow) $("np-epg").textContent=`${time} — ${title}`;
    return `<div class="epg-card${isNow?" now":""}"><div class="epg-time">${esc(time)}</div><div class="epg-title">${esc(title||"—")}</div></div>`;
  }).join("");
}

// ── Favourites ────────────────────────────────────────────────────
function updateFavBtn() {
  const ch=S.currentChannel; if (!ch) return;
  const isFav=S.favourites.some(f=>f.stream_id==ch.stream_id);
  $("btn-fav").textContent=isFav?"★":"☆";
  $("btn-fav").classList.toggle("active",isFav);
}

function toggleFav() {
  const ch=S.currentChannel; if (!ch) return;
  const idx=S.favourites.findIndex(f=>f.stream_id==ch.stream_id);
  if (idx===-1) {
    S.favourites.push({stream_id:ch.stream_id,name:ch.name,stream_icon:ch.stream_icon,num:ch.num,category_id:ch.category_id});
  } else {
    S.favourites.splice(idx,1);
  }
  updateFavBtn();
  saveFavourites();  // uses S.username at call time
}

function renderFavourites() {
  const body=$("fav-body");
  if (!S.favourites.length) { body.innerHTML='<div class="empty">No favourites yet.<br>Press ☆ while watching a channel.</div>'; return; }
  const grid=document.createElement("div"); grid.className="fav-grid";
  grid.innerHTML=S.favourites.map(ch=>{
    const logo=ch.stream_icon
      ?`<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      :`<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    return `<div class="fav-card" data-id="${ch.stream_id}">
      <button class="fav-remove" data-id="${ch.stream_id}">✕</button>
      <div class="ch-logo">${logo}</div>
      <div class="ch-name">${esc(ch.name||"")}</div>
    </div>`;
  }).join("");
  body.innerHTML=""; body.appendChild(grid);
  grid.querySelectorAll(".fav-card").forEach(card=>card.addEventListener("click",e=>{
    if (e.target.classList.contains("fav-remove")) return;
    const ch=S.favourites.find(f=>f.stream_id==card.dataset.id);
    if (ch) { selectChannel(ch.stream_id); closeTab("favourites"); }
  }));
  grid.querySelectorAll(".fav-remove").forEach(btn=>btn.addEventListener("click",e=>{
    e.stopPropagation();
    S.favourites=S.favourites.filter(f=>f.stream_id!=btn.dataset.id);
    saveFavourites();
    renderFavourites();
  }));
}

// ── Guide ─────────────────────────────────────────────────────────
async function loadGuide() {
  const body=$("guide-body");
  body.innerHTML='<div class="spinner">Loading guide…</div>';
  const now=Date.now()/1000;
  const rows=await Promise.allSettled(S.channels.slice(0,60).map(async ch=>{
    let listings=S.epgCache[ch.stream_id];
    if (!listings) {
      try { const d=await apiGet(`/api/epg/${ch.stream_id}?${creds()}`); listings=d.epg_listings||[]; S.epgCache[ch.stream_id]=listings; }
      catch(_) { listings=[]; }
    }
    return {ch,listings};
  }));
  S.guideData=rows.filter(r=>r.status==="fulfilled").map(r=>r.value).filter(r=>r.listings.length);
  renderGuide(S.guideData);
}

function renderGuide(data) {
  const body=$("guide-body");
  if (!data.length) { body.innerHTML='<div class="empty">No guide data available.</div>'; return; }
  const now=Date.now()/1000;
  const grid=document.createElement("div"); grid.className="guide-grid";
  grid.innerHTML=data.map(({ch,listings})=>{
    const logo=ch.stream_icon
      ?`<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      :`<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    const progs=listings.slice(0,6).map(ep=>{
      const start=parseInt(ep.start_timestamp||0),stop=parseInt(ep.stop_timestamp||0);
      const isNow=start<=now&&now<=stop;
      const time=ep.start?ep.start.slice(11,16):"";
      const title=b64(ep.title||"").trim();
      return `<div class="guide-program${isNow?" now":""}"><div class="gp-time">${esc(time)}</div><div class="gp-title">${esc(title||"—")}</div></div>`;
    }).join("");
    return `<div class="guide-row">
      <div class="guide-ch" data-id="${ch.stream_id}">
        <div class="guide-ch-logo">${logo}</div>
        <span class="guide-ch-name">${esc(ch.name||"")}</span>
        <span class="guide-ch-watch">▶</span>
      </div>
      <div class="guide-programs">${progs}</div>
    </div>`;
  }).join("");
  body.innerHTML=""; body.appendChild(grid);
  grid.querySelectorAll(".guide-ch").forEach(el=>el.addEventListener("click",()=>{
    const ch=data.find(d=>d.ch.stream_id==el.dataset.id)?.ch;
    if (ch) { selectChannel(ch.stream_id); closeTab("guide"); }
  }));
}

function filterGuide(q) {
  q=q.toLowerCase();
  renderGuide(q?S.guideData.filter(d=>(d.ch.name||"").toLowerCase().includes(q)):S.guideData);
}

// ── Tabs ──────────────────────────────────────────────────────────
function openTab(tab) {
  ["favourites","guide"].forEach(t=>$(`tab-${t}`)?.classList.add("hidden"));
  if (tab==="live") return;
  $(`tab-${tab}`)?.classList.remove("hidden");
  if (tab==="favourites") renderFavourites();
  if (tab==="guide")      loadGuide();
}
function closeTab(tab) {
  $(`tab-${tab}`)?.classList.add("hidden");
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.tab==="live"));
}
window.closeTab=closeTab;
