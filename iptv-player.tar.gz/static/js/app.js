"use strict";

// ── State ─────────────────────────────────────────────────────────
const P = { sessionId: null, lastSessionId: null, heartbeat: null };
const S = {
  username: "", password: "",
  categories: [], channels: [], filtered: [],
  currentChannel: null, favourites: [],
  epgCache: {}, guideData: [],
  prefs: { timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC" },
  hlsInstance: null, nativeTimer: null, vjsInstance: null,
};

// ── Utilities ─────────────────────────────────────────────────────
const $    = id => document.getElementById(id);
const esc  = s  => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const mob  = ()  => window.innerWidth <= 700;
const creds = () => `username=${encodeURIComponent(S.username)}&password=${encodeURIComponent(S.password)}`;

function b64(s) {
  if (!s) return s;
  try { return decodeURIComponent(atob(s).split("").map(c => "%" + c.charCodeAt(0).toString(16).padStart(2,"0")).join("")); }
  catch(_) { try { return atob(s); } catch(_) { return s; } }
}

function fmtTime(v) {
  if (!v) return "";
  try {
    const d = typeof v === "number" ? new Date(v*1000)
            : new Date(String(v).replace(" ","T") + (String(v).match(/[Z+]/) ? "" : "Z"));
    return d.toLocaleTimeString([], { hour:"2-digit", minute:"2-digit", timeZone: S.prefs.timezone, hour12: false });
  } catch(_) { return String(v).slice(11,16); }
}

async function apiFetch(url, opts) {
  const r = await fetch(url, opts);
  if (!r.ok) { const e = await r.json().catch(()=>{}); throw new Error((e&&e.error)||`Error ${r.status}`); }
  return r.json();
}

// ── Boot ──────────────────────────────────────────────────────────
window.addEventListener("DOMContentLoaded", () => {
  populateTimezones();
  bindEvents();
  showScreen("login");
});

function showScreen(n) {
  $("login-screen").classList.toggle("active", n === "login");
  $("app-screen").classList.toggle("active",   n === "app");
}
function setProgress(pct, msg, detail) {
  $("progress-bar").style.width = pct + "%";
  if (msg    !== undefined) $("load-msg").textContent    = msg;
  if (detail !== undefined) $("load-detail").textContent = detail || "\u00a0";
}

// ── Events ────────────────────────────────────────────────────────
function bindEvents() {
  $("btn-login").addEventListener("click", doLogin);
  ["inp-user","inp-pass"].forEach(id => $(id).addEventListener("keydown", e => e.key === "Enter" && doLogin()));
  $("btn-logout").addEventListener("click", doLogout);
  document.querySelectorAll(".nav-btn").forEach(b => b.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(x => x.classList.remove("active"));
    b.classList.add("active");
    openTab(b.dataset.tab);
  }));
  $("search-input")?.addEventListener("input",       e => filterChannels(e.target.value));
  $("mobile-search-input")?.addEventListener("input", e => filterChannels(e.target.value));
  $("btn-fav").addEventListener("click", toggleFav);
  $("guide-search").addEventListener("input", e => filterGuide(e.target.value));
  // beforeunload: desktop browsers, works for tab close/refresh
  window.addEventListener("beforeunload", () => stopStream());

  // pagehide: fires on iOS Safari when tab is closed/backgrounded
  // more reliable than beforeunload on mobile
  window.addEventListener("pagehide", () => stopStream());

  // visibilitychange: fires when user switches tabs or app goes to background
  // On mobile this is the most reliable way to detect "user left"
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      // Don't stop immediately — user may be switching apps briefly
      // The server's 25s heartbeat timeout will clean up if they don't return
      // But do stop the heartbeat so server knows we may be gone
      clearInterval(P.heartbeat);
      P.heartbeat = null;
    } else if (document.visibilityState === "visible") {
      // User came back — restart heartbeat if we have an active stream
      if (P.sessionId) startHeartbeat(P.sessionId);
    }
  });
}

// ── Tabs ──────────────────────────────────────────────────────────
const TABS = ["favourites","guide","settings","categories"];

function openTab(tab) {
  TABS.forEach(t => $("tab-"+t)?.classList.add("hidden"));
  if (tab === "live") { if (mob()) setMobileView("channels"); return; }
  $("tab-"+tab)?.classList.remove("hidden");
  if (tab === "favourites") renderFavourites();
  if (tab === "guide")      loadGuide();
  if (tab === "settings")   loadSettingsTab();
  if (tab === "categories") renderMobileCategories();
  if (mob()) setMobileView("channels");
}

function closeTab(tab) {
  $("tab-"+tab)?.classList.add("hidden");
  document.querySelectorAll(".nav-btn").forEach(b  => b.classList.toggle("active", b.dataset.tab  === "live"));
  document.querySelectorAll(".bnav-btn").forEach(b => b.classList.toggle("active", b.dataset.view === "channels"));
}
window.closeTab = closeTab;

// ── Mobile ────────────────────────────────────────────────────────
function setMobileView(v) {
  $("app-body")?.classList.toggle("view-player",   v === "player");
  $("app-body")?.classList.toggle("view-channels", v !== "player");
}

function mobileNav(view) {
  document.querySelectorAll(".bnav-btn").forEach(b => b.classList.toggle("active", b.dataset.view === view));
  TABS.forEach(t => $("tab-"+t)?.classList.add("hidden"));
  if (view === "channels") {
    document.querySelectorAll(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === "live"));
    setMobileView("channels");
  } else if (view === "player") {
    setMobileView("player");
  } else {
    setMobileView("channels");
    $("tab-"+view)?.classList.remove("hidden");
    if (view === "favourites") renderFavourites();
    if (view === "guide")      loadGuide();
    if (view === "settings")   loadSettingsTab();
    if (view === "categories") renderMobileCategories();
  }
}
window.mobileNav = mobileNav;

function renderMobileCategories() {
  const body = $("cat-body"); if (!body) return;
  const items = [{id:"all",name:"All Channels"}, ...S.categories.map(c => ({id:c.category_id,name:c.category_name}))];
  body.innerHTML = items.map(item => `<div class="mob-cat-item" data-cat="${esc(String(item.id))}">${esc(item.name)}</div>`).join("");
  body.onclick = e => {
    const el = e.target.closest(".mob-cat-item"); if (!el) return;
    const id = el.dataset.cat;
    S.filtered = id === "all" ? S.channels : S.channels.filter(ch => String(ch.category_id) === id);
    renderChannels(S.filtered);
    $("search-input") && ($("search-input").value = "");
    $("mobile-search-input") && ($("mobile-search-input").value = "");
    closeTab("categories"); mobileNav("channels");
  };
}

// ── Login ─────────────────────────────────────────────────────────
async function doLogin() {
  const username = $("inp-user").value.trim(), password = $("inp-pass").value.trim();
  const errEl = $("login-error"), btn = $("btn-login");
  if (!username || !password) { errEl.textContent = "Fill in all fields."; errEl.classList.remove("hidden"); return; }
  btn.disabled = true; btn.textContent = "Connecting…";
  errEl.classList.add("hidden");
  $("loading-overlay").classList.remove("hidden");
  setProgress(5, "Authenticating…", "");
  try {
    const auth = await apiFetch("/api/login", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({username,password}) });
    if (!auth.ok) throw new Error(auth.error || "Login failed");
    S.username = username; S.password = password;

    setProgress(15, "Loading preferences…", "");
    const prefs = await fetch(`/api/prefs/${encodeURIComponent(username)}`).then(r=>r.json()).catch(()=>({}));
    S.prefs = { ...S.prefs, ...prefs };
    if (S.prefs.streamSettings)
      fetch("/api/settings", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(S.prefs.streamSettings) }).catch(()=>{});

    setProgress(30, "Fetching categories…", "");
    S.categories = await apiFetch(`/api/xc/get_live_categories?${creds()}`) || [];

    setProgress(60, "Fetching channels…", `${S.categories.length} categories`);
    S.channels = await apiFetch(`/api/xc/get_live_streams?${creds()}`) || [];
    S.filtered = S.channels;

    setProgress(80, "Loading favourites…", "");
    S.favourites = await fetch(`/api/favs/${encodeURIComponent(username)}`).then(r=>r.json()).catch(()=>[]);

    setProgress(100, `Ready — ${S.channels.length} channels`, "");
    await new Promise(r => setTimeout(r, 300));
    $("loading-overlay").classList.add("hidden");
    showScreen("app");
    renderCategories(); renderChannels(S.channels);
    fetchAllEpg();
    if (mob()) setMobileView("channels");
  } catch(err) {
    $("loading-overlay").classList.add("hidden");
    errEl.textContent = err.message; errEl.classList.remove("hidden");
    S.username = ""; S.password = "";
  } finally { btn.disabled = false; btn.textContent = "Connect"; }
}

function doLogout() {
  stopStream();
  Object.assign(S, { username:"", password:"", categories:[], channels:[], filtered:[], currentChannel:null, epgCache:{}, guideData:[], favourites:[] });
  $("inp-user").value = ""; $("inp-pass").value = "";
  $("login-error").classList.add("hidden");
  showScreen("login");
}

// ── Categories ────────────────────────────────────────────────────
function renderCategories() {
  const list = $("category-list"); list.innerHTML = "";
  const all = makeCatEl({ category_id:"all", category_name:"All Channels" });
  all.classList.add("active"); list.appendChild(all);
  S.categories.forEach(c => list.appendChild(makeCatEl(c)));
}
function makeCatEl(cat) {
  const el = document.createElement("div"); el.className = "cat-item";
  el.innerHTML = `<span class="cat-dot"></span>${esc(cat.category_name)}`;
  el.addEventListener("click", () => {
    document.querySelectorAll(".cat-item").forEach(c => c.classList.remove("active"));
    el.classList.add("active");
    S.filtered = cat.category_id === "all" ? S.channels : S.channels.filter(c => String(c.category_id) === String(cat.category_id));
    renderChannels(S.filtered);
    $("search-input") && ($("search-input").value = "");
    $("mobile-search-input") && ($("mobile-search-input").value = "");
  });
  return el;
}

// ── Channels ──────────────────────────────────────────────────────
function renderChannels(list) {
  const el = $("channel-list");
  if (!list.length) { el.innerHTML = '<div class="empty">No channels found</div>'; return; }
  el.innerHTML = list.map(ch => {
    const logo = ch.stream_icon
      ? `<img src="/logo?url=${encodeURIComponent(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    const active = S.currentChannel?.stream_id == ch.stream_id ? " active" : "";
    const epg = S.epgCache[ch.stream_id];
    const now = Date.now()/1000;
    const np  = epg?.find(ep => parseInt(ep.start_timestamp||0) <= now && now <= parseInt(ep.stop_timestamp||0));
    const npt = np ? b64(np.title||"").trim() : "";
    return `<div class="ch-item${active}" data-id="${ch.stream_id}">
      <div class="ch-logo">${logo}</div>
      <div class="ch-info">
        <div class="ch-name">${esc(ch.name||"Channel")}</div>
        <div class="ch-num">#${ch.num||ch.stream_id}${npt?` · <span class="ch-now">${esc(npt)}</span>`:""}</div>
      </div>
      <span class="ch-live"></span>
    </div>`;
  }).join("");
  el.querySelectorAll(".ch-item").forEach(el => el.addEventListener("click", () => {
    selectChannel(el.dataset.id);
    if (mob()) {
      setMobileView("player");
      document.querySelectorAll(".bnav-btn").forEach(b => b.classList.toggle("active", b.dataset.view === "player"));
    }
  }));
}
function filterChannels(q) {
  q = q.toLowerCase();
  S.filtered = q ? S.channels.filter(c => (c.name||"").toLowerCase().includes(q)) : S.channels;
  renderChannels(S.filtered);
  if ($("search-input")?.value !== q)        $("search-input").value = q;
  if ($("mobile-search-input")?.value !== q) $("mobile-search-input").value = q;
}

// ── Player ────────────────────────────────────────────────────────
const _isIOS    = /iPhone|iPad|iPod/i.test(navigator.userAgent);
const _isSafari = _isIOS || (/Safari/i.test(navigator.userAgent) && !/Chrome|CriOS|FxiOS|EdgiOS|android/i.test(navigator.userAgent));

let _vjsPlayer = null;

function getVjsPlayer() {
  if (_vjsPlayer) return _vjsPlayer;
  _vjsPlayer = videojs("video", {
    // ── Core ──────────────────────────────────────────────────────
    controls:    true,
    autoplay:    false,
    preload:     "auto",
    playsinline: true,
    fluid:       false,
    fill:        true,

    // ── VHS (http-streaming) options ──────────────────────────────
    // VHS is Video.js's built-in HLS/DASH engine, successor to videojs-contrib-hls.
    // It handles MSE on all browsers and falls back to native where needed.
    html5: {
      vhs: {
        // Use VHS MSE on all browsers including Safari.
        // Without overrideNative, Safari uses its own HLS player which
        // we cannot control for buffering or error recovery.
        overrideNative: true,

        // Bandwidth estimation — start conservative for IPTV
        bandwidth:                   10e6,   // 10 Mbps initial estimate
        enableLowInitialPlaylist:     true,   // pick lowest quality first, ramp up
        limitRenditionByPlayerDimensions: false, // don't limit by player size

        // Live stream settings
        // allowSeeksWithinUnsafeLiveWindow: allow seeking even if slightly
        // outside what the playlist says is safe — prevents "going back in time"
        // when the live window shrinks
        allowSeeksWithinUnsafeLiveWindow: true,

        // Don't exclude slow playlists — IPTV has only one quality
        playlistExclusionDuration: 0,
        maxPlaylistRetries:        Infinity,

        // Fix timestamp issues common in IPTV
        // useDtsForTimestampOffset: use DTS for better A/V sync on IPTV streams
        // that have PTS/DTS discrepancies
        useDtsForTimestampOffset: true,

        // Cache encryption keys (irrelevant for unencrypted, but saves requests)
        cacheEncryptionKeys: true,
      },
      nativeAudioTracks: false,
      nativeVideoTracks: false,
      nativeTextTracks:  false,
    },
  });
  return _vjsPlayer;
}

function playStream(url, audioOnly, cfg) {
  stopHls();
  cfg = cfg || {};
  const vid = document.getElementById("video");
  vid.style.display = "block";

  const player = getVjsPlayer();

  // Set source — VHS picks it up and handles everything:
  // MSE on Chrome/Firefox/Edge, overrideNative MSE on macOS Safari,
  // native fallback on iOS where MSE is unavailable
  player.src({ src: url, type: "application/x-mpegURL" });

  // Play with autoplay-policy fallback
  const playPromise = player.play();
  if (playPromise && playPromise.then) {
    playPromise.catch(function() {
      // Autoplay blocked — mute and try again (Safari autoplay policy)
      player.muted(true);
      player.play().then(function() {
        setTimeout(function() { player.muted(false); }, 500);
      }).catch(function() {});
    });
  }

  // VHS live stream: seek to live edge once metadata is ready
  player.one("loadedmetadata", function() {
    if (player.liveTracker && player.liveTracker.isLive()) {
      player.liveTracker.seekToLiveEdge();
    }
  });

  // Error handling
  player.off("error");
  player.on("error", function() {
    const err = player.error();
    if (!err) return;
    console.warn("[vjs] error code=" + err.code, err.message);
    // code 2 = network error, code 3 = decode error, code 4 = not supported
    if (err.code === 2) {
      // Network error — retry source after 2s
      setTimeout(function() {
        if (_vjsPlayer) { player.src({ src: url, type: "application/x-mpegURL" }); player.play(); }
      }, 2000);
    }
  });

  S.vjsInstance = player;
}

function stopHls() {
  if (_vjsPlayer) {
    _vjsPlayer.off("error");
    _vjsPlayer.pause();
    _vjsPlayer.reset();
  }
  if (S.nativeTimer) { clearInterval(S.nativeTimer); S.nativeTimer = null; }
  const vid = document.getElementById("video");
  if (vid) vid.style.display = "none";
}

function stopStream() {
  stopHls();
  clearInterval(P.heartbeat); P.heartbeat = null;
  if (P.sessionId) {
    const sid = P.sessionId; P.lastSessionId = sid; P.sessionId = null;
    // sendBeacon works even during page unload (beforeunload/pagehide)
    // regular fetch() is cancelled by the browser when page closes
    const url = `/api/stream/stop/${sid}`;
    if (navigator.sendBeacon) {
      navigator.sendBeacon(url);
    } else {
      fetch(url, { method:"POST", keepalive:true }).catch(()=>{});
    }
  }
  $("epg-strip").innerHTML = "";
}

function startHeartbeat(sid) {
  clearInterval(P.heartbeat);
  P.heartbeat = setInterval(() => {
    if (P.sessionId === sid) fetch(`/api/stream/heartbeat/${sid}`, { method:"POST" }).catch(()=>{});
    else clearInterval(P.heartbeat);
  }, 8000);
}

function userStop() {
  stopStream(); S.currentChannel = null;
  $("now-playing").style.display = "none";
  $("player-placeholder").style.display = "flex";
  $("player-placeholder").innerHTML = '<span class="ph-icon">▶</span><span>Select a channel to watch</span>';
  document.querySelectorAll(".ch-item").forEach(el => el.classList.remove("active"));
}
window.userStop = userStop;

// ── EPG ───────────────────────────────────────────────────────────
async function fetchAllEpg() {
  const BATCH = 20;
  for (let i = 0; i < S.channels.length; i += BATCH) {
    await Promise.allSettled(S.channels.slice(i, i+BATCH).map(async ch => {
      if (S.epgCache[ch.stream_id]) return;
      try {
        const d = await apiFetch(`/api/epg/${ch.stream_id}?${creds()}`);
        S.epgCache[ch.stream_id] = d.epg_listings || [];
        updateChannelEpg(ch.stream_id);
      } catch(_) {}
    }));
    await new Promise(r => setTimeout(r, 200));
  }
}

async function loadEpg(id) {
  if (S.epgCache[id]) { renderEpg(S.epgCache[id]); return; }
  try {
    const d = await apiFetch(`/api/epg/${id}?${creds()}`);
    S.epgCache[id] = d.epg_listings || [];
    renderEpg(S.epgCache[id]);
    updateChannelEpg(id);
  } catch(_) {}
}

function updateChannelEpg(id) {
  const el = document.querySelector(`.ch-item[data-id="${id}"] .ch-num`); if (!el) return;
  const epg = S.epgCache[id]; if (!epg) return;
  const now = Date.now()/1000;
  const np  = epg.find(ep => parseInt(ep.start_timestamp||0) <= now && now <= parseInt(ep.stop_timestamp||0));
  const npt = np ? b64(np.title||"").trim() : "";
  const ch  = S.channels.find(c=>c.stream_id==id) || S.favourites.find(c=>c.stream_id==id);
  el.innerHTML = `#${(ch&&(ch.num||ch.stream_id))||id}${npt?` · <span class="ch-now">${esc(npt)}</span>`:""}`;
}

function renderEpg(listings) {
  const now = Date.now()/1000;
  $("epg-strip").innerHTML = listings.slice(0,8).map(ep => {
    const start=parseInt(ep.start_timestamp||0), stop=parseInt(ep.stop_timestamp||0);
    const isNow = start<=now && now<=stop;
    const t1 = fmtTime(ep.start);
    const t2 = stop ? fmtTime(new Date(stop*1000).toISOString().replace("T"," ").slice(0,19)) : "";
    const range = t2 ? `${t1} – ${t2}` : t1;
    const title = b64(ep.title||"").trim();
    if (isNow) $("np-epg").textContent = `${range}  ${title}`;
    return `<div class="epg-card${isNow?" now":""}"><div class="epg-time">${esc(range)}</div><div class="epg-title">${esc(title||"—")}</div></div>`;
  }).join("");
}

// ── Favourites ────────────────────────────────────────────────────
function updateFavBtn() {
  const ch = S.currentChannel; if (!ch) return;
  const isFav = S.favourites.some(f => f.stream_id == ch.stream_id);
  $("btn-fav").textContent = isFav ? "★" : "☆";
  $("btn-fav").classList.toggle("active", isFav);
}
function toggleFav() {
  const ch = S.currentChannel; if (!ch) return;
  const idx = S.favourites.findIndex(f => f.stream_id == ch.stream_id);
  if (idx === -1) S.favourites.push({ stream_id:ch.stream_id, name:ch.name, stream_icon:ch.stream_icon, num:ch.num, category_id:ch.category_id });
  else S.favourites.splice(idx, 1);
  updateFavBtn();
  fetch(`/api/favs/${encodeURIComponent(S.username)}`, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(S.favourites) });
}
function renderFavourites() {
  const body = $("fav-body");
  if (!S.favourites.length) { body.innerHTML = '<div class="empty">No favourites yet.<br>Press ☆ while watching a channel.</div>'; return; }
  const grid = document.createElement("div"); grid.className = "fav-grid";
  grid.innerHTML = S.favourites.map(ch => {
    const logo = ch.stream_icon
      ? `<img src="/logo?url=${encodeURIComponent(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    return `<div class="fav-card" data-id="${ch.stream_id}"><button class="fav-remove" data-id="${ch.stream_id}">✕</button><div class="ch-logo">${logo}</div><div class="ch-name">${esc(ch.name||"")}</div></div>`;
  }).join("");
  body.innerHTML = ""; body.appendChild(grid);
  grid.querySelectorAll(".fav-card").forEach(card => card.addEventListener("click", e => {
    if (e.target.classList.contains("fav-remove")) return;
    const ch = S.favourites.find(f => f.stream_id == card.dataset.id);
    if (ch) { selectChannel(ch.stream_id); closeTab("favourites"); if(mob()){setMobileView("player");document.querySelectorAll(".bnav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view==="player"));} }
  }));
  grid.querySelectorAll(".fav-remove").forEach(btn => btn.addEventListener("click", e => {
    e.stopPropagation();
    S.favourites = S.favourites.filter(f => f.stream_id != btn.dataset.id);
    fetch(`/api/favs/${encodeURIComponent(S.username)}`, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(S.favourites) });
    renderFavourites();
  }));
}

// ── Guide ─────────────────────────────────────────────────────────
async function loadGuide() {
  const body = $("guide-body");
  if (!S.favourites.length) { body.innerHTML = '<div class="empty">Add channels to favourites to see the guide.</div>'; return; }
  body.innerHTML = '<div class="spinner">Loading guide…</div>';
  const rows = await Promise.allSettled(S.favourites.map(async ch => {
    let listings = S.epgCache[ch.stream_id];
    if (!listings) {
      try { const d = await apiFetch(`/api/epg/${ch.stream_id}?${creds()}`); listings = d.epg_listings||[]; S.epgCache[ch.stream_id] = listings; }
      catch(_) { listings = []; }
    }
    return { ch, listings };
  }));
  S.guideData = rows.filter(r => r.status === "fulfilled").map(r => r.value);
  renderGuide(S.guideData);
}
function renderGuide(data) {
  const body = $("guide-body");
  if (!data.length) { body.innerHTML = '<div class="empty">No guide data for your favourites.</div>'; return; }
  const now = Date.now()/1000;
  const grid = document.createElement("div"); grid.className = "guide-grid";
  grid.innerHTML = data.map(({ch, listings}) => {
    const logo = ch.stream_icon
      ? `<img src="/logo?url=${encodeURIComponent(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    const progs = listings.slice(0,8).map(ep => {
      const start=parseInt(ep.start_timestamp||0), stop=parseInt(ep.stop_timestamp||0);
      const isNow = start<=now && now<=stop;
      const t1 = fmtTime(ep.start);
      const t2 = ep.stop ? fmtTime(ep.stop) : (stop ? fmtTime(new Date(stop*1000).toISOString().replace("T"," ").slice(0,19)) : "");
      const range = t2 ? `${t1} – ${t2}` : t1;
      const title = b64(ep.title||"").trim();
      return `<div class="guide-program${isNow?" now":""}"><div class="gp-time">${esc(range)}</div><div class="gp-title">${esc(title||"—")}</div></div>`;
    }).join("") || '<div class="guide-program"><div class="gp-time">—</div><div class="gp-title">No guide data</div></div>';
    return `<div class="guide-row"><div class="guide-ch" data-id="${ch.stream_id}"><div class="guide-ch-logo">${logo}</div><span class="guide-ch-name">${esc(ch.name||"")}</span><span class="guide-ch-watch">▶</span></div><div class="guide-programs">${progs}</div></div>`;
  }).join("");
  body.innerHTML = ""; body.appendChild(grid);
  grid.querySelectorAll(".guide-ch").forEach(el => el.addEventListener("click", () => {
    const ch = data.find(d => d.ch.stream_id == el.dataset.id)?.ch;
    if (ch) { selectChannel(ch.stream_id); closeTab("guide"); if(mob()){setMobileView("player");document.querySelectorAll(".bnav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view==="player"));} }
  }));
}
function filterGuide(q) {
  q = q.toLowerCase();
  renderGuide(q ? S.guideData.filter(d => (d.ch.name||"").toLowerCase().includes(q)) : S.guideData);
}

// ── Settings ──────────────────────────────────────────────────────
function populateTimezones() {
  const sel = $("pref-timezone");
  ["America/Vancouver","America/Edmonton","America/Regina","America/Winnipeg","America/Toronto",
   "America/Halifax","America/St_Johns","America/Los_Angeles","America/Denver","America/Phoenix",
   "America/Chicago","America/New_York","Pacific/Honolulu","America/Anchorage",
   "Europe/London","Europe/Paris","Europe/Berlin","Europe/Helsinki","Europe/Moscow",
   "Asia/Dubai","Asia/Kolkata","Asia/Singapore","Asia/Tokyo","Australia/Sydney","Pacific/Auckland","UTC"]
  .forEach(z => { const o = document.createElement("option"); o.value=z; o.textContent=z.replace(/_/g," "); sel.appendChild(o); });
}

async function loadSettingsTab() {
  try {
    const r = await apiFetch("/api/login", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({username:S.username,password:S.password}) });
    const exp = r.expiry ? new Date(parseInt(r.expiry)*1000).toLocaleDateString() : "—";
    $("acct-info").innerHTML = `<b>${esc(S.username)}</b><br>Status: ${r.status||"—"}<br>Connections: ${r.connections}<br>Expires: ${exp}`;
  } catch(_) { $("acct-info").textContent = "Could not load account info."; }
  $("pref-timezone").value = S.prefs.timezone || "UTC";
  if (S.prefs.streamSettings) loadStreamSettings(S.prefs.streamSettings);
}

async function savePrefs() {
  S.prefs.timezone = $("pref-timezone").value;
  const msg = $("prefs-msg");
  try {
    await fetch(`/api/prefs/${encodeURIComponent(S.username)}`, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(S.prefs) });
    msg.style.color="var(--green)"; msg.textContent="✓ Saved!"; msg.classList.remove("hidden");
    setTimeout(() => msg.classList.add("hidden"), 2000);
    S.epgCache = {}; $("epg-strip").innerHTML = "";
    if (S.currentChannel) loadEpg(S.currentChannel.stream_id);
  } catch(e) { msg.style.color="var(--red)"; msg.textContent="Error: "+e.message; msg.classList.remove("hidden"); }
}
window.savePrefs = savePrefs;

function switchStab(btn) {
  document.querySelectorAll(".stab-btn").forEach(b  => b.classList.remove("active"));
  document.querySelectorAll(".stab-panel").forEach(p => p.classList.remove("active"));
  btn.classList.add("active");
  $("stab-"+btn.dataset.stab)?.classList.add("active");
  if (btn.dataset.stab === "ffmpeg") loadFfmpegPanel();
  if (btn.dataset.stab === "stream") loadStreamSettings();
}
window.switchStab = switchStab;

// ── Stream Settings ───────────────────────────────────────────────
const STREAM_DEFAULTS = {
  ua:"chrome", segSecs:"2", prebuf:"2", window:"10", idle:"20", stallRestart:"10",
  forwardPad:"3", backPad:"2",
  forceAac:false, audioBr:"192", audioSr:"48000", aresample:true, audioPrebuf:"4",
  safariTranscode:true, safariProfile:"baseline", safariPreset:"ultrafast", safariVbr:"0",
  genpts:true, discardCorrupt:true, ffmpegInput:"", ffmpegExtra:"",
};

function loadStreamSettings(prefs) {
  const a = prefs || S.prefs.streamSettings || {};
  const sv = (id,v) => { const el=$(id); if(el) el.value=String(v); };
  const sc = (id,v) => { const el=$(id); if(el) el.checked=!!v; };
  sv("adv-ua",             a.ua             ?? STREAM_DEFAULTS.ua);
  sv("adv-seg-secs",       a.segSecs        ?? STREAM_DEFAULTS.segSecs);
  sv("adv-prebuf",         a.prebuf         ?? STREAM_DEFAULTS.prebuf);
  sv("adv-window",         a.window         ?? STREAM_DEFAULTS.window);
  sv("adv-idle",           a.idle           ?? STREAM_DEFAULTS.idle);
  sv("adv-stall-restart",  a.stallRestart   ?? STREAM_DEFAULTS.stallRestart);
  sv("adv-forward-pad",    a.forwardPad     ?? STREAM_DEFAULTS.forwardPad);
  sv("adv-back-pad",       a.backPad        ?? STREAM_DEFAULTS.backPad);
  sc("adv-force-aac",      a.forceAac       ?? STREAM_DEFAULTS.forceAac);
  sv("adv-audio-br",       a.audioBr        ?? STREAM_DEFAULTS.audioBr);
  sv("adv-audio-sr",       a.audioSr        ?? STREAM_DEFAULTS.audioSr);
  sc("adv-aresample",      a.aresample      ?? STREAM_DEFAULTS.aresample);
  sv("adv-audio-prebuf",   a.audioPrebuf    ?? STREAM_DEFAULTS.audioPrebuf);
  sc("adv-safari-transcode",a.safariTranscode?? STREAM_DEFAULTS.safariTranscode);
  sv("adv-safari-profile", a.safariProfile  ?? STREAM_DEFAULTS.safariProfile);
  sv("adv-safari-preset",  a.safariPreset   ?? STREAM_DEFAULTS.safariPreset);
  sv("adv-safari-vbr",     a.safariVbr      ?? STREAM_DEFAULTS.safariVbr);
  sc("adv-genpts",         a.genpts         ?? STREAM_DEFAULTS.genpts);
  sc("adv-discard-corrupt",a.discardCorrupt ?? STREAM_DEFAULTS.discardCorrupt);
  sv("adv-ffmpeg-input",   a.ffmpegInput    ?? STREAM_DEFAULTS.ffmpegInput);
  sv("adv-ffmpeg-extra",   a.ffmpegExtra    ?? STREAM_DEFAULTS.ffmpegExtra);
}

function getStreamSettings() {
  const gv = (id,d) => { const el=$(id); return el ? el.value : d; };
  const gc = (id,d) => { const el=$(id); return el ? el.checked : d; };
  return {
    ua:             gv("adv-ua","chrome"),
    segSecs:        gv("adv-seg-secs","2"),     prebuf:      gv("adv-prebuf","2"),
    window:         gv("adv-window","10"),       idle:        gv("adv-idle","20"),
    stallRestart:   gv("adv-stall-restart","10"),
    forwardPad:     gv("adv-forward-pad","3"),  backPad:     gv("adv-back-pad","2"),
    forceAac:       gc("adv-force-aac",false),
    audioBr:        gv("adv-audio-br","192"),   audioSr:     gv("adv-audio-sr","48000"),
    aresample:      gc("adv-aresample",true),   audioPrebuf: gv("adv-audio-prebuf","4"),
    safariTranscode:gc("adv-safari-transcode",true),
    safariProfile:  gv("adv-safari-profile","baseline"),
    safariPreset:   gv("adv-safari-preset","ultrafast"),
    safariVbr:      gv("adv-safari-vbr","0"),
    genpts:         gc("adv-genpts",true),      discardCorrupt:gc("adv-discard-corrupt",true),
    ffmpegInput:    gv("adv-ffmpeg-input",""),  ffmpegExtra: gv("adv-ffmpeg-extra",""),
  };
}

async function applyStreamSettings(settings) {
  S.prefs.streamSettings = settings;
  await Promise.all([
    fetch(`/api/prefs/${encodeURIComponent(S.username)}`, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(S.prefs) }),
    fetch("/api/settings", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(settings) }),
  ]);
}

async function saveStreamSettings() {
  const msg = $("stream-msg");
  try {
    await applyStreamSettings(getStreamSettings());
    msg.style.color="var(--green)"; msg.textContent="✓ Saved and applied!";
    msg.classList.remove("hidden"); setTimeout(()=>msg.classList.add("hidden"),2500);
  } catch(e) { msg.style.color="var(--red)"; msg.textContent="Error: "+e.message; msg.classList.remove("hidden"); }
}
window.saveStreamSettings = saveStreamSettings;

function resetStreamSettings() {
  if (!confirm("Reset all stream settings to defaults?")) return;
  loadStreamSettings(STREAM_DEFAULTS);
  const msg = $("stream-msg");
  applyStreamSettings({...STREAM_DEFAULTS}).then(() => {
    msg.style.color="var(--green)"; msg.textContent="✓ Reset to defaults";
    msg.classList.remove("hidden"); setTimeout(()=>msg.classList.add("hidden"),3000);
  }).catch(e => { msg.style.color="var(--red)"; msg.textContent="Error: "+e.message; msg.classList.remove("hidden"); });
}
window.resetStreamSettings = resetStreamSettings;

// ── FFmpeg command panel ──────────────────────────────────────────
async function loadFfmpegPanel() {
  const preview = $("ffcmd-preview");
  if (preview) {
    try {
      const d = await apiFetch("/api/ffcmd");
      preview.textContent = "ffmpeg \\\n" + d.cmd.slice(1).map(a => "  "+a).join(" \\\n");
    } catch(_) { preview.textContent = "Could not load."; }
  }
  const ta  = $("cmd-editor");
  const tog = $("cmd-enabled");
  if (ta) {
    try {
      const d = await apiFetch("/api/ffcmd/custom");
      ta.value = d.current || d.default || "";
      if (tog) tog.checked = !!d.isCustom;
    } catch(e) { ta.value = "Error: "+e.message; }
  }
}

async function saveCmd() {
  const ta  = $("cmd-editor"), tog = $("cmd-enabled"), msg = $("cmd-msg");
  if (!ta||!msg) return;
  msg.classList.add("hidden");
  try {
    const d = await apiFetch("/api/ffcmd/custom", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({cmd:ta.value,enabled:tog?tog.checked:true}) });
    msg.style.color="var(--green)"; msg.textContent=d.enabled?"✓ Custom command active":"✓ Saved (toggle on to activate)";
    msg.classList.remove("hidden"); setTimeout(()=>msg.classList.add("hidden"),4000);
  } catch(e) { msg.style.color="var(--red)"; msg.textContent="Error: "+e.message; msg.classList.remove("hidden"); }
}
window.saveCmd = saveCmd;

async function resetCmd() {
  const msg = $("cmd-msg");
  if (!confirm("Reset to default ffmpeg command?")) return;
  try {
    const d  = await apiFetch("/api/ffcmd/reset", {method:"POST"});
    const ta = $("cmd-editor"), tog = $("cmd-enabled");
    if (ta) ta.value = d.default||"";
    if (tog) tog.checked = false;
    if (msg) { msg.style.color="var(--green)"; msg.textContent="✓ Reset to default"; msg.classList.remove("hidden"); setTimeout(()=>msg.classList.add("hidden"),3000); }
    await loadFfmpegPanel();
  } catch(e) { if(msg){msg.style.color="var(--red)";msg.textContent="Error: "+e.message;msg.classList.remove("hidden");} }
}
window.resetCmd = resetCmd;

async function loadDefaultInEditor() {
  const ta = $("cmd-editor"); if (!ta) return;
  try { const d = await apiFetch("/api/ffcmd/custom"); ta.value = d.default||""; } catch(_) {}
}
window.loadDefaultInEditor = loadDefaultInEditor;

// ── Stop all ──────────────────────────────────────────────────────
async function stopAllStreams() {
  const msg = $("stopall-msg");
  try {
    // Stop local playback and heartbeat WITHOUT calling /api/stream/stop first
    // — we need the session to still exist on the server so stopall can count it
    stopHls();
    clearInterval(P.heartbeat); P.heartbeat = null;
    P.sessionId = null; P.lastSessionId = null;
    // Reset UI
    S.currentChannel = null;
    $("now-playing").style.display = "none";
    $("player-placeholder").style.display = "flex";
    $("player-placeholder").innerHTML = '<span class="ph-icon">▶</span><span>Select a channel to watch</span>';
    document.querySelectorAll(".ch-item").forEach(el => el.classList.remove("active"));
    $("epg-strip").innerHTML = "";

    // Now kill ALL server sessions in one call — includes the one we just stopped locally
    const d = await apiFetch("/api/stream/stopall", {method:"POST"});
    if (msg) {
      msg.textContent = d.stopped > 0 ? `Stopped ${d.stopped} stream${d.stopped===1?"":"s"}` : "No active streams";
      msg.className = "stopall-msg stopall-ok";
      setTimeout(()=>msg.className="stopall-msg hidden",3000);
    }
  } catch(e) {
    if (msg) { msg.textContent="Error: "+e.message; msg.className="stopall-msg stopall-err"; setTimeout(()=>msg.className="stopall-msg hidden",3000); }
  }
}
window.stopAllStreams = stopAllStreams;
