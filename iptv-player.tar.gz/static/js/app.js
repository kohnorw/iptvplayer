"use strict";

// ── Shaka Player ─────────────────────────────────────────────────
let shakaLoaded = false;
function loadShaka() {
  return new Promise(resolve => {
    if (window.shaka) { shakaLoaded = true; return resolve(); }
    const s = document.createElement("script");
    s.src = "https://cdnjs.cloudflare.com/ajax/libs/shaka-player/4.16.3/shaka-player.compiled.min.js";
    s.onload = () => {
      shaka.polyfill.installAll();
      shakaLoaded = shaka.Player.isBrowserSupported();
      resolve();
    };
    s.onerror = () => resolve();
    document.head.appendChild(s);
  });
}

// ── Session (in-memory only, never persisted) ─────────────────────
const session = { host:"", username:"", password:"" };

const S = {
  categories:[], channels:[], filtered:[],
  currentChannel:null, favourites:[],
  epgCache:{}, guideData:[],
  shakaPlayer:null,
};

const $   = id => document.getElementById(id);
const esc = s  => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const b64 = s  => { try { return atob(s); } catch(_){ return s; } };

// Attach creds to every API request
function authHeaders() {
  return {
    "Content-Type":   "application/json",
    "x-xc-host":      session.host,
    "x-xc-username":  session.username,
    "x-xc-password":  session.password,
  };
}

// ── Boot ──────────────────────────────────────────────────────────
(async () => {
  await loadShaka();
  bindEvents();
  showScreen("login");
})();

function showScreen(name) {
  $("login-screen").classList.toggle("active", name === "login");
  $("app-screen").classList.toggle("active",   name === "app");
}

// ── Loading overlay ───────────────────────────────────────────────
function showOverlay(msg = "Connecting…") {
  $("load-msg").textContent = msg;
  $("progress-bar").style.width = "0%";
  $("load-detail").textContent = "";
  $("loading-overlay").classList.remove("hidden");
}
function hideOverlay() { $("loading-overlay").classList.add("hidden"); }
function setProgress(pct, msg, detail) {
  $("progress-bar").style.width = pct + "%";
  if (msg !== undefined)    $("load-msg").textContent    = msg;
  if (detail !== undefined) $("load-detail").textContent = detail;
}

// ── Events ────────────────────────────────────────────────────────
function bindEvents() {
  $("btn-login").addEventListener("click", doLogin);
  ["inp-host","inp-user","inp-pass"].forEach(id =>
    $(id).addEventListener("keydown", e => e.key === "Enter" && doLogin())
  );
  $("btn-logout").addEventListener("click", doLogout);
  document.querySelectorAll(".nav-btn").forEach(b => b.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(x => x.classList.remove("active"));
    b.classList.add("active");
    openTab(b.dataset.tab);
  }));
  $("search-input").addEventListener("input", e => filterChannels(e.target.value));
  $("btn-fav").addEventListener("click", toggleFav);
  $("guide-search").addEventListener("input", e => filterGuide(e.target.value));
}

// ── Login ─────────────────────────────────────────────────────────
async function doLogin() {
  const host     = $("inp-host").value.trim();
  const username = $("inp-user").value.trim();
  const password = $("inp-pass").value.trim();
  const errEl    = $("login-error"), btn = $("btn-login");

  if (!host || !username || !password) {
    errEl.textContent = "Please fill in all fields.";
    errEl.classList.remove("hidden"); return;
  }

  btn.disabled = true; btn.textContent = "Connecting…";
  errEl.classList.add("hidden");

  try {
    showOverlay("Verifying credentials…");
    setProgress(5);

    const r = await fetch("/api/login", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ host, username, password }),
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || "Login failed");

    // Store in session only — never on disk
    session.host     = d.host;
    session.username = username;
    session.password = password;

    setProgress(15, "Authenticated! Loading channels…", `Connected to ${d.host}`);
    await fetchChannelsSSE();
  } catch(err) {
    hideOverlay();
    errEl.textContent = err.message;
    errEl.classList.remove("hidden");
  } finally {
    btn.disabled = false; btn.textContent = "Connect";
  }
}

function doLogout() {
  // Clear session from memory
  session.host = session.username = session.password = "";
  S.channels = []; S.categories = []; S.filtered = [];
  S.favourites = []; S.epgCache = {}; S.guideData = [];
  stopPlayer();
  $("inp-host").value = ""; $("inp-user").value = ""; $("inp-pass").value = "";
  showScreen("login");
}

// ── SSE channel loader ────────────────────────────────────────────
function fetchChannelsSSE() {
  return new Promise((resolve, reject) => {
    const params = new URLSearchParams({
      host:     session.host,
      username: session.username,
      password: session.password,
    });
    const es = new EventSource(`/api/load-channels?${params}`);

    es.onmessage = e => {
      const msg = JSON.parse(e.data);
      if (msg.type === "progress") {
        setProgress(msg.pct, msg.msg);
      } else if (msg.type === "done") {
        es.close();
        S.categories = msg.categories || [];
        S.channels   = msg.channels   || [];
        S.filtered   = S.channels;
        setProgress(100, `Ready — ${S.channels.length} channels loaded`);
        setTimeout(() => { hideOverlay(); bootApp(); resolve(); }, 400);
      } else if (msg.type === "error") {
        es.close();
        hideOverlay();
        reject(new Error(msg.msg));
      }
    };
    es.onerror = () => { es.close(); hideOverlay(); reject(new Error("Connection lost")); };
  });
}

async function bootApp() {
  showScreen("app");
  // Load favourites for this user
  try {
    S.favourites = await fetch("/api/favourites", { headers: authHeaders() }).then(r => r.json());
  } catch(_) { S.favourites = []; }
  renderCategories();
  renderChannels(S.channels);
}

// ── Categories ────────────────────────────────────────────────────
function renderCategories() {
  const list = $("category-list");
  list.innerHTML = "";
  const all = makeCatEl({ category_id:"all", category_name:"All Channels" });
  all.classList.add("active");
  list.appendChild(all);
  S.categories.forEach(c => list.appendChild(makeCatEl(c)));
}

function makeCatEl(cat) {
  const el = document.createElement("div");
  el.className = "cat-item";
  el.dataset.id = String(cat.category_id);
  el.innerHTML = `<span class="cat-dot"></span>${esc(cat.category_name)}`;
  el.addEventListener("click", () => {
    document.querySelectorAll(".cat-item").forEach(c => c.classList.remove("active"));
    el.classList.add("active");
    const id = el.dataset.id;
    S.filtered = id === "all" ? S.channels : S.channels.filter(c => String(c.category_id) === id);
    // Clear search
    $("search-input").value = "";
    renderChannels(S.filtered);
  });
  return el;
}

// ── Channels ──────────────────────────────────────────────────────
function renderChannels(list) {
  const el = $("channel-list");
  if (!list.length) { el.innerHTML = '<div class="empty">No channels found</div>'; return; }
  el.innerHTML = list.map(ch => {
    const logo = ch.stream_icon
      ? `<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    const active = S.currentChannel?.stream_id == ch.stream_id ? " active" : "";
    return `<div class="ch-item${active}" data-id="${ch.stream_id}">
      <div class="ch-logo">${logo}</div>
      <div class="ch-info">
        <div class="ch-name">${esc(ch.name||"Channel")}</div>
        <div class="ch-num">#${ch.num||ch.stream_id}</div>
      </div>
      <span class="ch-live"></span>
    </div>`;
  }).join("");
  el.querySelectorAll(".ch-item").forEach(el =>
    el.addEventListener("click", () => selectChannel(el.dataset.id))
  );
}

function filterChannels(q) {
  q = q.toLowerCase();
  // Search across all channels regardless of current category
  S.filtered = q ? S.channels.filter(c => (c.name||"").toLowerCase().includes(q)) : S.channels;
  renderChannels(S.filtered);
}

// ── Player ────────────────────────────────────────────────────────
async function selectChannel(id) {
  const ch = S.channels.find(c => c.stream_id == id) || S.favourites.find(c => c.stream_id == id);
  if (!ch) return;
  S.currentChannel = ch;
  document.querySelectorAll(".ch-item").forEach(el => el.classList.toggle("active", el.dataset.id == id));

  // Stream via proxy with creds in query string (server-side routes internally)
  const params = new URLSearchParams({
    host:     session.host,
    username: session.username,
    password: session.password,
    ext:      "m3u8",
  });
  const streamUrl = `/proxy/stream/live/${id}?${params}`;
  playStream(streamUrl, ch);
  loadEpg(id);
}

async function playStream(url, ch) {
  stopPlayer();
  $("player-placeholder").style.display = "none";
  const vid = $("video");
  vid.classList.add("visible");

  if (shakaLoaded && shaka.Player.isBrowserSupported()) {
    const player = new shaka.Player();
    await player.attach(vid);

    player.configure({
      streaming: {
        lowLatencyMode: false,
        rebufferingGoal: 2,
        bufferingGoal: 10,
        retryParameters: { maxAttempts: 4, baseDelay: 1000, backoffFactor: 2 },
      },
      manifest: {
        retryParameters: { maxAttempts: 4, baseDelay: 1000, backoffFactor: 2 },
      },
    });

    player.addEventListener("error", e => {
      console.warn("Shaka error:", e.detail);
    });

    try {
      await player.load(url);
      vid.play().catch(() => {});
    } catch(e) {
      console.error("Shaka load error:", e);
    }
    S.shakaPlayer = player;
  } else {
    // Fallback for browsers with native HLS (Safari)
    vid.src = url;
    vid.play().catch(() => {});
  }

  $("now-playing").style.display = "flex";
  $("np-name").textContent = ch.name || "";
  $("np-epg").textContent  = "Loading programme info…";
  const isFav = S.favourites.some(f => f.stream_id == ch.stream_id);
  $("btn-fav").textContent = isFav ? "★" : "☆";
  $("btn-fav").classList.toggle("active", isFav);
}

function stopPlayer() {
  if (S.shakaPlayer) { S.shakaPlayer.destroy(); S.shakaPlayer = null; }
  const vid = $("video");
  vid.pause(); vid.src = ""; vid.classList.remove("visible");
}

// ── EPG ───────────────────────────────────────────────────────────
async function loadEpg(streamId) {
  $("epg-strip").innerHTML = "";
  if (S.epgCache[streamId]) { renderEpg(S.epgCache[streamId]); return; }
  try {
    const d = await fetch(`/api/epg/${streamId}`, { headers: authHeaders() }).then(r => r.json());
    S.epgCache[streamId] = d.epg_listings || [];
    renderEpg(S.epgCache[streamId]);
  } catch(_) {}
}

function renderEpg(listings) {
  const now = Date.now() / 1000;
  $("epg-strip").innerHTML = listings.slice(0,8).map(ep => {
    const start = parseInt(ep.start_timestamp||0);
    const stop  = parseInt(ep.stop_timestamp||0);
    const isNow = start <= now && now <= stop;
    const time  = ep.start ? ep.start.slice(11,16) : "";
    const title = b64(ep.title||"").trim();
    if (isNow) $("np-epg").textContent = `${time} — ${title}`;
    return `<div class="epg-card${isNow?" now":""}">
      <div class="epg-time">${esc(time)}</div>
      <div class="epg-title">${esc(title||"—")}</div>
    </div>`;
  }).join("");
}

// ── Favourites ────────────────────────────────────────────────────
function toggleFav() {
  const ch = S.currentChannel; if (!ch) return;
  const idx = S.favourites.findIndex(f => f.stream_id == ch.stream_id);
  if (idx === -1) {
    S.favourites.push({ stream_id:ch.stream_id, name:ch.name, stream_icon:ch.stream_icon, num:ch.num, category_id:ch.category_id });
    $("btn-fav").textContent = "★"; $("btn-fav").classList.add("active");
  } else {
    S.favourites.splice(idx, 1);
    $("btn-fav").textContent = "☆"; $("btn-fav").classList.remove("active");
  }
  fetch("/api/favourites", { method:"POST", headers: authHeaders(), body: JSON.stringify(S.favourites) });
}

function renderFavourites() {
  const body = $("fav-body");
  if (!S.favourites.length) {
    body.innerHTML = '<div class="empty">No favourites yet.<br>Press ☆ while watching a channel.</div>'; return;
  }
  const grid = document.createElement("div"); grid.className = "fav-grid";
  grid.innerHTML = S.favourites.map(ch => {
    const logo = ch.stream_icon
      ? `<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    return `<div class="fav-card" data-id="${ch.stream_id}">
      <button class="fav-remove" data-id="${ch.stream_id}" title="Remove">✕</button>
      <div class="ch-logo">${logo}</div>
      <div class="ch-name">${esc(ch.name||"")}</div>
    </div>`;
  }).join("");
  body.innerHTML = ""; body.appendChild(grid);
  grid.querySelectorAll(".fav-card").forEach(card => card.addEventListener("click", e => {
    if (e.target.classList.contains("fav-remove")) return;
    const ch = S.favourites.find(f => f.stream_id == card.dataset.id);
    if (ch) { if (!S.channels.find(c => c.stream_id == ch.stream_id)) S.channels.push(ch); selectChannel(ch.stream_id); closeTab("favourites"); }
  }));
  grid.querySelectorAll(".fav-remove").forEach(btn => btn.addEventListener("click", e => {
    e.stopPropagation();
    S.favourites = S.favourites.filter(f => f.stream_id != btn.dataset.id);
    fetch("/api/favourites", { method:"POST", headers: authHeaders(), body: JSON.stringify(S.favourites) });
    renderFavourites();
  }));
}

// ── Guide ─────────────────────────────────────────────────────────
async function loadGuide() {
  const body = $("guide-body");
  body.innerHTML = '<div class="spinner">Loading guide…</div>';
  const channels = S.filtered.length && S.filtered.length < S.channels.length
    ? S.filtered.slice(0, 60) : S.channels.slice(0, 60);
  const now = Date.now() / 1000;

  const rows = await Promise.allSettled(channels.map(async ch => {
    if (!S.epgCache[ch.stream_id]) {
      try {
        const d = await fetch(`/api/epg/${ch.stream_id}`, { headers: authHeaders() }).then(r => r.json());
        S.epgCache[ch.stream_id] = d.epg_listings || [];
      } catch(_) { S.epgCache[ch.stream_id] = []; }
    }
    return { ch, listings: S.epgCache[ch.stream_id] };
  }));

  S.guideData = rows.filter(r => r.status === "fulfilled").map(r => r.value).filter(r => r.listings.length);
  renderGuide(S.guideData);
}

function renderGuide(data) {
  const body = $("guide-body");
  if (!data.length) { body.innerHTML = '<div class="empty">No guide data available.</div>'; return; }
  const now = Date.now() / 1000;
  const grid = document.createElement("div"); grid.className = "guide-grid";
  grid.innerHTML = data.map(({ ch, listings }) => {
    const logo = ch.stream_icon
      ? `<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    const progs = listings.slice(0,6).map(ep => {
      const isNow = parseInt(ep.start_timestamp||0) <= now && now <= parseInt(ep.stop_timestamp||0);
      const time  = ep.start ? ep.start.slice(11,16) : "";
      const title = b64(ep.title||"").trim();
      return `<div class="guide-program${isNow?" now":""}">
        <div class="gp-time">${esc(time)}</div>
        <div class="gp-title">${esc(title||"—")}</div>
      </div>`;
    }).join("");
    return `<div class="guide-row">
      <div class="guide-ch" data-id="${ch.stream_id}">
        <div class="guide-ch-logo">${logo}</div>
        <span class="guide-ch-name">${esc(ch.name||"")}</span>
        <span style="font-size:11px;color:var(--text3);flex-shrink:0">▶</span>
      </div>
      <div class="guide-programs">${progs}</div>
    </div>`;
  }).join("");
  body.innerHTML = ""; body.appendChild(grid);
  grid.querySelectorAll(".guide-ch").forEach(el => el.addEventListener("click", () => {
    const ch = data.find(d => d.ch.stream_id == el.dataset.id)?.ch;
    if (ch) { if (!S.channels.find(c => c.stream_id == ch.stream_id)) S.channels.push(ch); selectChannel(ch.stream_id); closeTab("guide"); }
  }));
}

function filterGuide(q) {
  q = q.toLowerCase();
  renderGuide(q ? S.guideData.filter(d => (d.ch.name||"").toLowerCase().includes(q)) : S.guideData);
}

// ── Tabs ──────────────────────────────────────────────────────────
function openTab(tab) {
  ["favourites","guide","settings"].forEach(t => $(`tab-${t}`)?.classList.add("hidden"));
  if (tab === "live") return;
  $(`tab-${tab}`)?.classList.remove("hidden");
  if (tab === "favourites") renderFavourites();
  if (tab === "guide")      loadGuide();
  if (tab === "settings")   loadSettingsTab();
}
function closeTab(tab) {
  $(`tab-${tab}`)?.classList.add("hidden");
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === "live"));
}
window.closeTab = closeTab;

// ── Settings ──────────────────────────────────────────────────────
function loadSettingsTab() {
  $("acct-info").innerHTML =
    `Host: <b>${esc(session.host)}</b><br>` +
    `Username: <b>${esc(session.username)}</b><br>` +
    `<span style="color:var(--text3);font-size:11px">Credentials are session-only and not stored.</span>`;
}
window.saveSettings = () => {};
