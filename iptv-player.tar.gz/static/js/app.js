"use strict";

// ── HLS.js loader (from CDN) ──────────────────────────────────────
const HLS_CDN = "https://cdn.jsdelivr.net/npm/hls.js@latest/dist/hls.min.js";
let HLS = null;

function loadHls() {
  return new Promise((resolve) => {
    if (window.Hls) { HLS = window.Hls; resolve(); return; }
    const s = document.createElement("script");
    s.src = HLS_CDN;
    s.onload = () => { HLS = window.Hls; resolve(); };
    s.onerror = () => resolve(); // graceful fail
    document.head.appendChild(s);
  });
}

// ── State ────────────────────────────────────────────────────────
const state = {
  categories: [],
  channels: [],
  filtered: [],
  currentCat: null,
  currentChannel: null,
  favourites: [],  // [{stream_id, name, stream_icon, num}]
  prefs: { autoplay: true, format: "ts" },
  hlsInstance: null,
  epgCache: {},
  guideData: [],
};

// ── DOM refs ─────────────────────────────────────────────────────
const $ = (id) => document.getElementById(id);
const loginScreen = $("login-screen");
const appScreen   = $("app-screen");
const video       = $("video-player");

// ── Boot ─────────────────────────────────────────────────────────
(async () => {
  await loadHls();
  await tryAutoLogin();
  bindEvents();
})();

async function tryAutoLogin() {
  try {
    const r = await fetch("/api/settings");
    const s = await r.json();
    if (s.host && s.username) {
      const test = await fetch("/api/test");
      if (test.ok) { await bootApp(); return; }
    }
  } catch (_) {}
  showScreen("login");
}

async function bootApp() {
  showScreen("app");
  loadPrefs();
  await Promise.all([loadFavourites(), loadCategories()]);
}

// ── Screens ───────────────────────────────────────────────────────
function showScreen(name) {
  loginScreen.classList.toggle("active", name === "login");
  appScreen.classList.toggle("active",   name === "app");
}

// ── Login ─────────────────────────────────────────────────────────
function bindEvents() {
  $("btn-login").addEventListener("click", doLogin);
  ["inp-host","inp-user","inp-pass"].forEach(id =>
    $(id).addEventListener("keydown", e => e.key === "Enter" && doLogin())
  );

  $("btn-logout").addEventListener("click", () => {
    fetch("/api/settings", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({host:"",username:"",password:""}) });
    showScreen("login");
    stopPlayer();
  });

  // Nav tabs
  document.querySelectorAll(".nav-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const tab = btn.dataset.tab;
      document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      openTab(tab);
    });
  });

  // Search
  $("search-input").addEventListener("input", (e) => filterChannels(e.target.value));

  // Fav button
  $("btn-fav").addEventListener("click", toggleFav);

  // Guide search
  $("guide-search").addEventListener("input", (e) => filterGuide(e.target.value));

  // Settings save
  $("pref-autoplay").addEventListener("change", savePrefs);
  $("pref-format").addEventListener("change",    savePrefs);
}

async function doLogin() {
  const host = $("inp-host").value.trim();
  const username = $("inp-user").value.trim();
  const password = $("inp-pass").value.trim();
  const errEl = $("login-error");
  const btn = $("btn-login");

  if (!host || !username || !password) {
    errEl.textContent = "Please fill in all fields.";
    errEl.classList.remove("hidden");
    return;
  }

  btn.disabled = true;
  btn.textContent = "Connecting…";
  errEl.classList.add("hidden");

  try {
    await fetch("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ host, username, password }),
    });

    const test = await fetch("/api/test");
    if (test.ok) {
      await bootApp();
    } else {
      const d = await test.json();
      errEl.textContent = d.error || "Login failed. Check credentials.";
      errEl.classList.remove("hidden");
    }
  } catch (err) {
    errEl.textContent = "Connection error: " + err.message;
    errEl.classList.remove("hidden");
  } finally {
    btn.disabled = false;
    btn.textContent = "Connect";
  }
}

// ── Categories ────────────────────────────────────────────────────
async function loadCategories() {
  const list = $("category-list");
  list.innerHTML = '<div class="loading-spin">Loading…</div>';
  try {
    const r = await fetch("/api/xtream/get_live_categories");
    const data = await r.json();
    state.categories = Array.isArray(data) ? data : [];

    list.innerHTML = "";

    // All channels item
    const all = mkCatItem({ category_id: "all", category_name: "All Channels" });
    all.classList.add("active");
    list.appendChild(all);

    state.categories.forEach(cat => list.appendChild(mkCatItem(cat)));

    // Load all channels initially
    await loadChannels("all");
  } catch (err) {
    list.innerHTML = `<div class="empty-state">Error loading categories</div>`;
  }
}

function mkCatItem(cat) {
  const el = document.createElement("div");
  el.className = "cat-item";
  el.dataset.id = cat.category_id;
  el.innerHTML = `<span class="cat-dot"></span>${escHtml(cat.category_name)}`;
  el.addEventListener("click", async () => {
    document.querySelectorAll(".cat-item").forEach(c => c.classList.remove("active"));
    el.classList.add("active");
    await loadChannels(cat.category_id);
  });
  return el;
}

// ── Channels ──────────────────────────────────────────────────────
async function loadChannels(catId) {
  const list = $("channel-list");
  list.innerHTML = '<div class="loading-spin">Loading…</div>';
  state.currentCat = catId;

  try {
    const url = catId === "all"
      ? "/api/xtream/get_live_streams"
      : `/api/xtream/get_live_streams?category_id=${catId}`;

    const r = await fetch(url);
    const data = await r.json();
    state.channels = Array.isArray(data) ? data : [];
    state.filtered = state.channels;
    renderChannels(state.filtered);
  } catch (_) {
    list.innerHTML = '<div class="empty-state">Failed to load channels</div>';
  }
}

function renderChannels(channels) {
  const list = $("channel-list");
  if (!channels.length) {
    list.innerHTML = '<div class="empty-state">No channels found</div>';
    return;
  }
  list.innerHTML = channels.map(ch => channelCard(ch)).join("");
  list.querySelectorAll(".ch-item").forEach(el => {
    el.addEventListener("click", () => selectChannel(el.dataset.id));
  });
}

function channelCard(ch) {
  const logo = ch.stream_icon
    ? `<img src="${escHtml(ch.stream_icon)}" onerror="this.style.display='none'" />`
    : escHtml((ch.name || "?")[0].toUpperCase());
  const active = state.currentChannel && state.currentChannel.stream_id == ch.stream_id ? " active" : "";
  return `
  <div class="ch-item${active}" data-id="${ch.stream_id}">
    <div class="ch-logo">${logo}</div>
    <div class="ch-info">
      <div class="ch-name">${escHtml(ch.name || "Channel")}</div>
      <div class="ch-num">#${ch.num || ch.stream_id}</div>
    </div>
    <span class="ch-live" title="Live"></span>
  </div>`;
}

function filterChannels(q) {
  q = q.toLowerCase().trim();
  state.filtered = q
    ? state.channels.filter(ch => (ch.name || "").toLowerCase().includes(q))
    : state.channels;
  renderChannels(state.filtered);
}

// ── Player ────────────────────────────────────────────────────────
async function selectChannel(id) {
  const ch = state.channels.find(c => c.stream_id == id)
          || state.favourites.find(c => c.stream_id == id);
  if (!ch) return;

  state.currentChannel = ch;

  // Update active state
  document.querySelectorAll(".ch-item").forEach(el =>
    el.classList.toggle("active", el.dataset.id == id)
  );

  // Build proxied stream URL
  const fmt = state.prefs.format || "ts";
  const streamUrl = `/proxy/stream/live/${id}.${fmt}`;

  playUrl(streamUrl, ch);
  await loadEpg(ch.stream_id);
}

function playUrl(url, ch) {
  stopPlayer();

  $("player-placeholder").style.display = "none";
  video.classList.add("visible");

  if (HLS && HLS.isSupported() && (url.includes(".m3u8") || state.prefs.format === "m3u8")) {
    const hls = new HLS({ enableWorker: false, lowLatencyMode: true });
    hls.loadSource(url);
    hls.attachMedia(video);
    hls.on(HLS.Events.MANIFEST_PARSED, () => video.play().catch(() => {}));
    hls.on(HLS.Events.ERROR, (_, d) => {
      if (d.fatal) showPlayerError("Stream error – trying native…");
    });
    state.hlsInstance = hls;
  } else {
    // Native – browser handles TS or M3U8 natively on some platforms
    video.src = url;
    video.play().catch(() => {});
  }

  // Now playing bar
  const npEl = $("now-playing");
  npEl.style.display = "flex";
  $("np-channel").textContent = ch.name || "Unknown Channel";
  $("np-epg").textContent = "Loading programme info…";

  // Fav button state
  const isFav = state.favourites.some(f => f.stream_id == ch.stream_id);
  const favBtn = $("btn-fav");
  favBtn.textContent = isFav ? "★" : "☆";
  favBtn.classList.toggle("active", isFav);
}

function stopPlayer() {
  if (state.hlsInstance) {
    state.hlsInstance.destroy();
    state.hlsInstance = null;
  }
  video.pause();
  video.src = "";
  video.classList.remove("visible");
}

function showPlayerError(msg) {
  let err = document.querySelector(".player-error");
  if (!err) {
    err = document.createElement("div");
    err.className = "player-error";
    $("player-wrap").appendChild(err);
  }
  err.textContent = msg;
}

// ── EPG ───────────────────────────────────────────────────────────
async function loadEpg(streamId) {
  const strip = $("epg-strip");
  strip.innerHTML = "";

  if (state.epgCache[streamId]) {
    renderEpg(state.epgCache[streamId]);
    return;
  }

  try {
    const r = await fetch(`/api/epg/${streamId}`);
    const data = await r.json();
    const listings = data.epg_listings || [];
    state.epgCache[streamId] = listings;
    renderEpg(listings);
  } catch (_) {}
}

function renderEpg(listings) {
  const strip = $("epg-strip");
  if (!listings.length) { strip.innerHTML = ""; return; }

  const now = Date.now() / 1000;
  strip.innerHTML = listings.slice(0, 8).map(ep => {
    const start = parseInt(ep.start_timestamp || 0);
    const stop  = parseInt(ep.stop_timestamp  || 0);
    const isNow = start <= now && now <= stop;
    const startStr = ep.start ? ep.start.slice(11, 16) : "";
    const title = ep.title ? atob(ep.title).replace(/^\s+|\s+$/g,"") : "—";

    if (isNow && state.currentChannel) {
      $("np-epg").textContent = `${startStr} — ${title}`;
    }

    return `
    <div class="epg-card${isNow ? " now" : ""}">
      <div class="epg-time">${startStr}</div>
      <div class="epg-title">${escHtml(title)}</div>
    </div>`;
  }).join("");
}

// ── Favourites ────────────────────────────────────────────────────
async function loadFavourites() {
  try {
    const r = await fetch("/api/favourites");
    state.favourites = await r.json();
  } catch (_) { state.favourites = []; }
}

function toggleFav() {
  const ch = state.currentChannel;
  if (!ch) return;

  const idx = state.favourites.findIndex(f => f.stream_id == ch.stream_id);
  if (idx === -1) {
    state.favourites.push({ stream_id: ch.stream_id, name: ch.name, stream_icon: ch.stream_icon, num: ch.num });
    $("btn-fav").textContent = "★";
    $("btn-fav").classList.add("active");
  } else {
    state.favourites.splice(idx, 1);
    $("btn-fav").textContent = "☆";
    $("btn-fav").classList.remove("active");
  }
  saveFavourites();
}

async function saveFavourites() {
  await fetch("/api/favourites", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(state.favourites),
  });
}

function renderFavourites() {
  const body = $("fav-body");
  if (!state.favourites.length) {
    body.innerHTML = '<div class="empty-state">No favourites yet.<br>Press ☆ while watching a channel.</div>';
    return;
  }
  const grid = document.createElement("div");
  grid.className = "fav-grid";
  grid.innerHTML = state.favourites.map(ch => {
    const logo = ch.stream_icon
      ? `<img src="${escHtml(ch.stream_icon)}" onerror="this.style.display='none'" />`
      : escHtml((ch.name||"?")[0]);
    return `
    <div class="fav-card" data-id="${ch.stream_id}">
      <button class="fav-remove" data-id="${ch.stream_id}" title="Remove">✕</button>
      <div class="ch-logo">${logo}</div>
      <div class="ch-name">${escHtml(ch.name||"Channel")}</div>
    </div>`;
  }).join("");

  body.innerHTML = "";
  body.appendChild(grid);

  grid.querySelectorAll(".fav-card").forEach(card => {
    card.addEventListener("click", (e) => {
      if (e.target.classList.contains("fav-remove")) return;
      const id = card.dataset.id;
      // Make sure channel is in state.channels for playback
      const ch = state.favourites.find(f => f.stream_id == id);
      if (ch) {
        // Push into channels list temporarily so selectChannel can find it
        if (!state.channels.find(c => c.stream_id == id)) state.channels.push(ch);
        selectChannel(id);
      }
      closeTab("favourites");
    });
  });

  grid.querySelectorAll(".fav-remove").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const id = btn.dataset.id;
      state.favourites = state.favourites.filter(f => f.stream_id != id);
      saveFavourites();
      renderFavourites();
    });
  });
}

// ── Guide ─────────────────────────────────────────────────────────
async function loadGuide() {
  const body = $("guide-body");
  body.innerHTML = '<div class="loading-spin">Loading guide…</div>';

  // Use cached channels or load them
  let channels = state.channels;
  if (!channels.length) {
    try {
      const r = await fetch("/api/xtream/get_live_streams");
      channels = await r.json();
    } catch (_) { channels = []; }
  }

  // Grab EPG for first 30 channels (lightweight)
  const sample = channels.slice(0, 30);
  const now = Date.now() / 1000;

  const rows = await Promise.allSettled(sample.map(async ch => {
    let listings = state.epgCache[ch.stream_id];
    if (!listings) {
      try {
        const r = await fetch(`/api/epg/${ch.stream_id}`);
        const d = await r.json();
        listings = d.epg_listings || [];
        state.epgCache[ch.stream_id] = listings;
      } catch (_) { listings = []; }
    }
    return { ch, listings };
  }));

  state.guideData = rows
    .filter(r => r.status === "fulfilled")
    .map(r => r.value)
    .filter(r => r.listings.length);

  renderGuide(state.guideData);
}

function renderGuide(data) {
  const body = $("guide-body");
  if (!data.length) {
    body.innerHTML = '<div class="empty-state">No guide data available from your provider.</div>';
    return;
  }
  const now = Date.now() / 1000;
  const grid = document.createElement("div");
  grid.className = "guide-grid";

  grid.innerHTML = data.map(({ ch, listings }) => {
    const progs = listings.slice(0, 6).map(ep => {
      const start = parseInt(ep.start_timestamp || 0);
      const stop  = parseInt(ep.stop_timestamp  || 0);
      const isNow = start <= now && now <= stop;
      const startStr = ep.start ? ep.start.slice(11, 16) : "";
      const title = ep.title ? safeDecode(ep.title) : "—";
      return `<div class="guide-program${isNow ? " now" : ""}">
        <div class="gp-time">${escHtml(startStr)}</div>
        <div class="gp-title">${escHtml(title)}</div>
      </div>`;
    }).join("");

    return `
    <div class="guide-row">
      <div class="guide-ch-header" data-id="${ch.stream_id}">
        <span class="guide-ch-name">${escHtml(ch.name||"Channel")}</span>
        <span style="font-size:11px;color:var(--text3)">Watch ▶</span>
      </div>
      <div class="guide-programs">${progs}</div>
    </div>`;
  }).join("");

  body.innerHTML = "";
  body.appendChild(grid);

  grid.querySelectorAll(".guide-ch-header").forEach(el => {
    el.addEventListener("click", () => {
      const id = el.dataset.id;
      if (!state.channels.find(c => c.stream_id == id)) {
        const ch = data.find(d => d.ch.stream_id == id)?.ch;
        if (ch) state.channels.push(ch);
      }
      selectChannel(id);
      closeTab("guide");
    });
  });
}

function filterGuide(q) {
  q = q.toLowerCase();
  const filtered = q ? state.guideData.filter(d => (d.ch.name||"").toLowerCase().includes(q)) : state.guideData;
  renderGuide(filtered);
}

// ── Tabs ──────────────────────────────────────────────────────────
function openTab(tab) {
  // Hide all tab overlays
  ["guide","favourites","settings"].forEach(t => {
    $(`tab-${t}`)?.classList.add("hidden");
  });

  if (tab === "live") return; // No overlay for live tab

  const el = $(`tab-${tab}`);
  if (!el) return;
  el.classList.remove("hidden");

  if (tab === "guide")      { loadGuide(); }
  if (tab === "favourites") { renderFavourites(); }
  if (tab === "settings")   { loadSettingsTab(); }
}

function closeTab(tab) {
  $(`tab-${tab}`)?.classList.add("hidden");
  // Switch nav back to live
  document.querySelectorAll(".nav-btn").forEach(b => {
    b.classList.toggle("active", b.dataset.tab === "live");
  });
}
window.closeTab = closeTab;

// ── Settings tab ──────────────────────────────────────────────────
async function loadSettingsTab() {
  try {
    const [sr, tr] = await Promise.all([fetch("/api/settings"), fetch("/api/test")]);
    const s = await sr.json();

    $("s-host").value = s.host || "";
    $("s-user").value = s.username || "";
    $("s-pass").value = s.password || "";

    if (tr.ok) {
      const info = await tr.json();
      const exp = info.expiry ? new Date(parseInt(info.expiry) * 1000).toLocaleDateString() : "—";
      $("acct-info").innerHTML =
        `Status: <b>${info.status || "—"}</b><br>` +
        `Connections: <b>${info.connections || "—"}</b><br>` +
        `Expires: <b>${exp}</b>`;
    } else {
      $("acct-info").textContent = "Not connected";
    }
  } catch (_) {}
}

async function saveSettings() {
  const host = $("s-host").value.trim();
  const username = $("s-user").value.trim();
  const password = $("s-pass").value.trim();
  const msg = $("settings-msg");

  if (!host || !username || !password) {
    msg.textContent = "All fields required."; msg.classList.remove("hidden"); return;
  }

  try {
    await fetch("/api/settings", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ host, username, password }),
    });
    const test = await fetch("/api/test");
    if (test.ok) {
      msg.style.color = "var(--green)";
      msg.textContent = "✓ Saved! Reloading…";
      msg.classList.remove("hidden");
      setTimeout(() => { closeTab("settings"); loadCategories(); }, 1000);
    } else {
      msg.style.color = "var(--red)";
      msg.textContent = "Invalid credentials.";
      msg.classList.remove("hidden");
    }
  } catch (err) {
    msg.textContent = "Error: " + err.message;
    msg.classList.remove("hidden");
  }
}
window.saveSettings = saveSettings;

// ── Prefs ─────────────────────────────────────────────────────────
function loadPrefs() {
  try {
    const p = JSON.parse(localStorage.getItem("iptv_prefs") || "{}");
    state.prefs = { ...state.prefs, ...p };
  } catch (_) {}
  $("pref-autoplay").checked = state.prefs.autoplay !== false;
  $("pref-format").value = state.prefs.format || "ts";
}

function savePrefs() {
  state.prefs.autoplay = $("pref-autoplay").checked;
  state.prefs.format   = $("pref-format").value;
  localStorage.setItem("iptv_prefs", JSON.stringify(state.prefs));
}

// ── Utils ─────────────────────────────────────────────────────────
function escHtml(str) {
  return String(str||"")
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;");
}

function safeDecode(b64) {
  try { return atob(b64); } catch(_) { return b64; }
}
