"use strict";

// ── State ─────────────────────────────────────────────────────────
const S = {
  host:"", username:"", password:"",
  categories:[], channels:[], filtered:[],
  currentChannel:null, favourites:[], epgCache:{}, guideData:[],
  hlsInstance:null,
};

function loadFavourites()  { try { return JSON.parse(localStorage.getItem("iptv_favs")||"[]"); } catch(_){ return []; } }
function saveFavourites()  { localStorage.setItem("iptv_favs", JSON.stringify(S.favourites)); }

const $   = id => document.getElementById(id);
const esc = s  => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
const b64 = s  => { try { return atob(s); } catch(_){ return s; } };

// ── XC API — direct from browser ─────────────────────────────────
async function xcGet(action, params={}) {
  const u = new URL(`${S.host}/player_api.php`);
  u.searchParams.set("username", S.username);
  u.searchParams.set("password", S.password);
  if (action) u.searchParams.set("action", action);
  for (const [k,v] of Object.entries(params)) u.searchParams.set(k, v);
  const r = await fetch(u.toString());
  const txt = await r.text();
  try { return JSON.parse(txt); }
  catch(_) { throw new Error("Server returned an invalid response. Check your URL and credentials."); }
}

async function discoverAndLogin(rawHost, username, password) {
  const bare = rawHost.trim().replace(/^https?:\/\//i,"").replace(/\/+$/,"");
  const candidates = [
    `https://${bare}`,
    `http://${bare}`,
    `https://${bare}:443`,
    `http://${bare}:3000`,
    `http://${bare}:8080`,
    `http://${bare}:80`,
  ];
  const seen = new Set();
  for (const host of candidates) {
    if (seen.has(host)) continue; seen.add(host);
    try {
      const u = `${host}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`;
      const r = await fetch(u, { signal: AbortSignal.timeout(8000) });
      const d = JSON.parse(await r.text());
      if (d.user_info && d.user_info.auth == 1) {
        const si = d.server_info;
        if (si && si.url) {
          const proto = si.server_protocol || "http";
          const port  = proto === "https" ? si.https_port : si.port;
          return (port && port !== "80" && port !== "443")
            ? `${proto}://${si.url}:${port}`
            : `${proto}://${si.url}`;
        }
        return host;
      }
    } catch(_) {}
  }
  throw new Error("Could not connect. Check your server URL and credentials.");
}

// ── Boot ──────────────────────────────────────────────────────────
window.addEventListener("DOMContentLoaded", () => { bindEvents(); showScreen("login"); });

function showScreen(name) {
  $("login-screen").classList.toggle("active", name === "login");
  $("app-screen").classList.toggle("active",   name === "app");
}

function showLoading() { $("loading-overlay").classList.remove("hidden"); }
function hideLoading() { $("loading-overlay").classList.add("hidden"); }
function setProgress(pct, msg, detail) {
  $("progress-bar").style.width = pct + "%";
  if (msg    !== undefined) $("load-msg").textContent    = msg;
  if (detail !== undefined) $("load-detail").textContent = detail || "\u00a0";
}

// ── Events ────────────────────────────────────────────────────────
function bindEvents() {
  $("btn-login").addEventListener("click", doLogin);
  ["inp-host","inp-user","inp-pass"].forEach(id =>
    $(id).addEventListener("keydown", e => e.key === "Enter" && doLogin())
  );
  $("btn-logout").addEventListener("click", doLogout);
  document.querySelectorAll(".nav-btn").forEach(b => b.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(x => x.classList.remove("active"));
    b.classList.add("active");
    openTab(b.dataset.tab);
  }));
  $("search-input").addEventListener("input", e => filterChannels(e.target.value));
  $("btn-fav").addEventListener("click", toggleFav);
  $("guide-search").addEventListener("input", e => filterGuide(e.target.value));
}

// ── Login ─────────────────────────────────────────────────────────
async function doLogin() {
  const rawHost  = $("inp-host").value.trim();
  const username = $("inp-user").value.trim();
  const password = $("inp-pass").value.trim();
  const errEl = $("login-error"), btn = $("btn-login");

  if (!rawHost || !username || !password) {
    errEl.textContent = "Please fill in all fields.";
    errEl.classList.remove("hidden"); return;
  }

  btn.disabled = true; btn.textContent = "Connecting…";
  errEl.classList.add("hidden");
  showLoading();
  setProgress(5, "Connecting to server…", "");

  try {
    const host = await discoverAndLogin(rawHost, username, password);
    S.host = host; S.username = username; S.password = password;
    S.favourites = loadFavourites();

    setProgress(25, "Fetching categories…", host);
    S.categories = await xcGet("get_live_categories") || [];

    setProgress(50, "Fetching channels…", `${S.categories.length} categories found`);
    S.channels = await xcGet("get_live_streams") || [];
    S.filtered = S.channels;

    setProgress(100, `Ready — ${S.channels.length} channels loaded`, "");
    await new Promise(r => setTimeout(r, 400));

    hideLoading();
    showScreen("app");
    renderCategories();
    renderChannels(S.channels);

  } catch(err) {
    hideLoading();
    errEl.textContent = err.message;
    errEl.classList.remove("hidden");
    S.host = ""; S.username = ""; S.password = "";
  } finally {
    btn.disabled = false; btn.textContent = "Connect";
  }
}

function doLogout() {
  S.host=""; S.username=""; S.password="";
  S.categories=[]; S.channels=[]; S.filtered=[];
  S.currentChannel=null; S.epgCache={}; S.guideData=[];
  stopPlayer();
  showScreen("login");
  ["inp-host","inp-user","inp-pass"].forEach(id => $(id).value = "");
  $("login-error").classList.add("hidden");
}

// ── Categories ────────────────────────────────────────────────────
function renderCategories() {
  const list = $("category-list");
  list.innerHTML = "";
  const all = makeCatEl({ category_id:"all", category_name:"All Channels" });
  all.classList.add("active");
  list.appendChild(all);
  S.categories.forEach(c => list.appendChild(makeCatEl(c)));
}

function makeCatEl(cat) {
  const el = document.createElement("div");
  el.className = "cat-item";
  el.innerHTML = `<span class="cat-dot"></span>${esc(cat.category_name)}`;
  el.addEventListener("click", () => {
    document.querySelectorAll(".cat-item").forEach(c => c.classList.remove("active"));
    el.classList.add("active");
    const filtered = cat.category_id === "all"
      ? S.channels
      : S.channels.filter(c => String(c.category_id) === String(cat.category_id));
    S.filtered = filtered;
    renderChannels(filtered);
    $("search-input").value = "";
  });
  return el;
}

// ── Channels ──────────────────────────────────────────────────────
function renderChannels(list) {
  const el = $("channel-list");
  if (!list.length) { el.innerHTML = '<div class="empty">No channels found</div>'; return; }
  el.innerHTML = list.map(ch => {
    const logo = ch.stream_icon
      ? `<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    const active = S.currentChannel?.stream_id == ch.stream_id ? " active" : "";
    return `<div class="ch-item${active}" data-id="${ch.stream_id}">
      <div class="ch-logo">${logo}</div>
      <div class="ch-info">
        <div class="ch-name">${esc(ch.name||"Channel")}</div>
        <div class="ch-num">#${ch.num||ch.stream_id}</div>
      </div>
      <span class="ch-live"></span>
    </div>`;
  }).join("");
  el.querySelectorAll(".ch-item").forEach(el =>
    el.addEventListener("click", () => selectChannel(el.dataset.id))
  );
}

function filterChannels(q) {
  q = q.toLowerCase();
  S.filtered = q ? S.channels.filter(c => (c.name||"").toLowerCase().includes(q)) : S.channels;
  renderChannels(S.filtered);
}

// ── Player ────────────────────────────────────────────────────────
async function selectChannel(id) {
  const ch = S.channels.find(c => c.stream_id == id) || S.favourites.find(c => c.stream_id == id);
  if (!ch) return;
  S.currentChannel = ch;
  document.querySelectorAll(".ch-item").forEach(el => el.classList.toggle("active", el.dataset.id == id));

  // Build XC stream URL, send to our FFmpeg proxy on Docker
  const xcStreamUrl = `${S.host}/live/${encodeURIComponent(S.username)}/${encodeURIComponent(S.password)}/${ch.stream_id}.ts`;
  const proxyUrl = `/proxy/stream?url=${encodeURIComponent(xcStreamUrl)}`;

  playStream(proxyUrl, ch);
  loadEpg(ch.stream_id);
}

function playStream(url, ch) {
  stopPlayer();
  $("player-placeholder").style.display = "none";
  const vid = $("video");
  vid.style.display = "block";

  // FFmpeg outputs MPEG-TS — HLS.js handles it perfectly in Chrome
  if (Hls.isSupported()) {
    const hls = new Hls({
      enableWorker: true,
      lowLatencyMode: true,
      progressive: true,          // stream from progressive HTTP source (our ffmpeg pipe)
      testBandwidth: false,
    });
    hls.loadSource(url);
    hls.attachMedia(vid);
    hls.on(Hls.Events.MANIFEST_PARSED, () => vid.play().catch(() => {}));
    hls.on(Hls.Events.ERROR, (_, data) => {
      console.warn("HLS error:", data.type, data.details);
      if (data.fatal) {
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR) hls.startLoad();
        else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError();
        else stopPlayer();
      }
    });
    S.hlsInstance = hls;
  } else if (vid.canPlayType("video/mp2t")) {
    // Some browsers can play MPEG-TS natively
    vid.src = url;
    vid.play().catch(() => {});
  } else {
    vid.src = url;
    vid.play().catch(() => {});
  }

  $("now-playing").style.display = "flex";
  $("np-name").textContent = ch.name || "";
  $("np-epg").textContent  = "";
  const isFav = S.favourites.some(f => f.stream_id == ch.stream_id);
  $("btn-fav").textContent = isFav ? "★" : "☆";
  $("btn-fav").classList.toggle("active", isFav);
}

function stopPlayer() {
  if (S.hlsInstance) { S.hlsInstance.destroy(); S.hlsInstance = null; }
  const vid = $("video");
  vid.pause(); vid.src = ""; vid.style.display = "none";
  $("epg-strip").innerHTML = "";
}

// ── EPG ───────────────────────────────────────────────────────────
async function loadEpg(streamId) {
  if (S.epgCache[streamId]) { renderEpg(S.epgCache[streamId]); return; }
  try {
    const d = await xcGet("get_short_epg", { stream_id: streamId, limit: 8 });
    const listings = d.epg_listings || [];
    S.epgCache[streamId] = listings;
    renderEpg(listings);
  } catch(_) {}
}

function renderEpg(listings) {
  const now = Date.now() / 1000;
  $("epg-strip").innerHTML = listings.slice(0,8).map(ep => {
    const start = parseInt(ep.start_timestamp||0);
    const stop  = parseInt(ep.stop_timestamp||0);
    const isNow = start <= now && now <= stop;
    const time  = ep.start ? ep.start.slice(11,16) : "";
    const title = b64(ep.title||"").trim();
    if (isNow && $("np-epg")) $("np-epg").textContent = `${time} — ${title}`;
    return `<div class="epg-card${isNow?" now":""}">
      <div class="epg-time">${esc(time)}</div>
      <div class="epg-title">${esc(title||"—")}</div>
    </div>`;
  }).join("");
}

// ── Favourites ────────────────────────────────────────────────────
function toggleFav() {
  const ch = S.currentChannel; if (!ch) return;
  const idx = S.favourites.findIndex(f => f.stream_id == ch.stream_id);
  if (idx === -1) {
    S.favourites.push({ stream_id:ch.stream_id, name:ch.name, stream_icon:ch.stream_icon, num:ch.num, category_id:ch.category_id });
    $("btn-fav").textContent = "★"; $("btn-fav").classList.add("active");
  } else {
    S.favourites.splice(idx, 1);
    $("btn-fav").textContent = "☆"; $("btn-fav").classList.remove("active");
  }
  saveFavourites();
}

function renderFavourites() {
  const body = $("fav-body");
  if (!S.favourites.length) {
    body.innerHTML = '<div class="empty">No favourites yet.<br>Press ☆ while watching a channel.</div>'; return;
  }
  const grid = document.createElement("div"); grid.className = "fav-grid";
  grid.innerHTML = S.favourites.map(ch => {
    const logo = ch.stream_icon
      ? `<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    return `<div class="fav-card" data-id="${ch.stream_id}">
      <button class="fav-remove" data-id="${ch.stream_id}" title="Remove">✕</button>
      <div class="ch-logo">${logo}</div>
      <div class="ch-name">${esc(ch.name||"")}</div>
    </div>`;
  }).join("");
  body.innerHTML = ""; body.appendChild(grid);
  grid.querySelectorAll(".fav-card").forEach(card => card.addEventListener("click", e => {
    if (e.target.classList.contains("fav-remove")) return;
    const ch = S.favourites.find(f => f.stream_id == card.dataset.id);
    if (ch) { selectChannel(ch.stream_id); closeTab("favourites"); }
  }));
  grid.querySelectorAll(".fav-remove").forEach(btn => btn.addEventListener("click", e => {
    e.stopPropagation();
    S.favourites = S.favourites.filter(f => f.stream_id != btn.dataset.id);
    saveFavourites(); renderFavourites();
  }));
}

// ── Guide ─────────────────────────────────────────────────────────
async function loadGuide() {
  const body = $("guide-body");
  body.innerHTML = '<div class="spinner">Loading guide…</div>';
  const channels = S.channels.slice(0, 60);
  const now = Date.now() / 1000;

  const rows = await Promise.allSettled(channels.map(async ch => {
    let listings = S.epgCache[ch.stream_id];
    if (!listings) {
      try {
        const d = await xcGet("get_short_epg", { stream_id: ch.stream_id, limit: 6 });
        listings = d.epg_listings || []; S.epgCache[ch.stream_id] = listings;
      } catch(_) { listings = []; }
    }
    return { ch, listings };
  }));

  S.guideData = rows.filter(r => r.status==="fulfilled").map(r=>r.value).filter(r=>r.listings.length);
  renderGuide(S.guideData);
}

function renderGuide(data) {
  const body = $("guide-body");
  if (!data.length) { body.innerHTML = '<div class="empty">No guide data available.</div>'; return; }
  const now = Date.now() / 1000;
  const grid = document.createElement("div"); grid.className = "guide-grid";
  grid.innerHTML = data.map(({ ch, listings }) => {
    const logo = ch.stream_icon
      ? `<img src="${esc(ch.stream_icon)}" onerror="this.style.display='none'" loading="lazy"/>`
      : `<span>${esc((ch.name||"?")[0].toUpperCase())}</span>`;
    const progs = listings.slice(0,6).map(ep => {
      const start=parseInt(ep.start_timestamp||0), stop=parseInt(ep.stop_timestamp||0);
      const isNow = start<=now && now<=stop;
      const time  = ep.start ? ep.start.slice(11,16) : "";
      const title = b64(ep.title||"").trim();
      return `<div class="guide-program${isNow?" now":""}">
        <div class="gp-time">${esc(time)}</div>
        <div class="gp-title">${esc(title||"—")}</div>
      </div>`;
    }).join("");
    return `<div class="guide-row">
      <div class="guide-ch" data-id="${ch.stream_id}">
        <div class="guide-ch-logo">${logo}</div>
        <span class="guide-ch-name">${esc(ch.name||"")}</span>
        <span class="guide-ch-watch">▶</span>
      </div>
      <div class="guide-programs">${progs}</div>
    </div>`;
  }).join("");
  body.innerHTML = ""; body.appendChild(grid);
  grid.querySelectorAll(".guide-ch").forEach(el => el.addEventListener("click", () => {
    const ch = data.find(d => d.ch.stream_id == el.dataset.id)?.ch;
    if (ch) { selectChannel(ch.stream_id); closeTab("guide"); }
  }));
}

function filterGuide(q) {
  q = q.toLowerCase();
  renderGuide(q ? S.guideData.filter(d => (d.ch.name||"").toLowerCase().includes(q)) : S.guideData);
}

// ── Tabs ──────────────────────────────────────────────────────────
function openTab(tab) {
  ["favourites","guide"].forEach(t => $(`tab-${t}`)?.classList.add("hidden"));
  if (tab === "live") return;
  $(`tab-${tab}`)?.classList.remove("hidden");
  if (tab === "favourites") renderFavourites();
  if (tab === "guide")      loadGuide();
}
function closeTab(tab) {
  $(`tab-${tab}`)?.classList.add("hidden");
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.tab==="live"));
}
window.closeTab = closeTab;
