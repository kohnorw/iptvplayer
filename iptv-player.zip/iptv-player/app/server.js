"use strict";

const express = require("express");
const fetch = require("node-fetch");
const http = require("http");
const https = require("https");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 8080;

// Persistent data directory
const DATA_DIR = path.join(__dirname, "../data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const SETTINGS_FILE = path.join(DATA_DIR, "settings.json");
const FAVOURITES_FILE = path.join(DATA_DIR, "favourites.json");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "../static")));

// ─── Settings ────────────────────────────────────────────────────────────────

function loadSettings() {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      return JSON.parse(fs.readFileSync(SETTINGS_FILE, "utf8"));
    }
  } catch (_) {}
  return {};
}

function saveSettings(data) {
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(data, null, 2));
}

function loadFavourites() {
  try {
    if (fs.existsSync(FAVOURITES_FILE)) {
      return JSON.parse(fs.readFileSync(FAVOURITES_FILE, "utf8"));
    }
  } catch (_) {}
  return [];
}

function saveFavourites(data) {
  fs.writeFileSync(FAVOURITES_FILE, JSON.stringify(data, null, 2));
}

// ─── Settings API ─────────────────────────────────────────────────────────────

app.get("/api/settings", (req, res) => {
  res.json(loadSettings());
});

app.post("/api/settings", (req, res) => {
  const { host, username, password } = req.body;
  if (!host || !username || !password) {
    return res.status(400).json({ error: "host, username, password required" });
  }
  saveSettings({ host: host.replace(/\/$/, ""), username, password });
  res.json({ ok: true });
});

// ─── Favourites API ───────────────────────────────────────────────────────────

app.get("/api/favourites", (req, res) => {
  res.json(loadFavourites());
});

app.post("/api/favourites", (req, res) => {
  saveFavourites(req.body);
  res.json({ ok: true });
});

// ─── Xtream Codes API proxy ───────────────────────────────────────────────────

function xtreamBase(settings) {
  return `${settings.host}/player_api.php?username=${settings.username}&password=${settings.password}`;
}

app.get("/api/xtream/:action", async (req, res) => {
  const settings = loadSettings();
  if (!settings.host) return res.status(401).json({ error: "Not configured" });

  const { action } = req.params;
  const allowed = [
    "get_live_categories",
    "get_live_streams",
    "get_vod_categories",
    "get_vod_streams",
    "get_series_categories",
    "get_series",
    "get_simple_data_table",
    "get_short_epg",
    "get_epg",
  ];

  if (!allowed.includes(action)) {
    return res.status(403).json({ error: "Action not allowed" });
  }

  let url = `${xtreamBase(settings)}&action=${action}`;

  // Forward optional query params (category_id, stream_id, limit, etc.)
  const extra = { ...req.query };
  delete extra._;
  for (const [k, v] of Object.entries(extra)) {
    url += `&${encodeURIComponent(k)}=${encodeURIComponent(v)}`;
  }

  try {
    const upstream = await fetch(url, { timeout: 15000 });
    if (!upstream.ok) {
      return res.status(upstream.status).json({ error: "Upstream error" });
    }
    const data = await upstream.json();
    res.json(data);
  } catch (err) {
    res.status(502).json({ error: "Failed to reach server: " + err.message });
  }
});

// ─── Stream proxy (true lightweight pass-through) ─────────────────────────────
// We pipe bytes directly — no buffering, no transcoding.

app.get("/proxy/stream/:type/:id", (req, res) => {
  const settings = loadSettings();
  if (!settings.host) return res.status(401).send("Not configured");

  const { type, id } = req.params;
  // id may include extension e.g. "12345.m3u8" or just "12345"
  const dotIdx = id.lastIndexOf(".");
  const streamId = dotIdx > 0 ? id.slice(0, dotIdx) : id;
  const ext = dotIdx > 0 ? id.slice(dotIdx + 1) : "ts";

  // Xtream Codes stream URL format
  const streamUrl = `${settings.host}/${type}/${settings.username}/${settings.password}/${streamId}.${ext}`;

  proxyStream(streamUrl, req, res);
});

// Catch-all stream proxy for direct M3U8 / TS URLs supplied by client
app.get("/proxy/url", (req, res) => {
  const target = req.query.url;
  if (!target) return res.status(400).send("Missing url param");

  // Safety: only proxy to the configured server
  const settings = loadSettings();
  if (settings.host && !target.startsWith(settings.host)) {
    return res.status(403).send("Forbidden");
  }

  proxyStream(target, req, res);
});

function proxyStream(targetUrl, req, res) {
  const parsed = new URL(targetUrl);
  const isHttps = parsed.protocol === "https:";
  const lib = isHttps ? https : http;

  const options = {
    hostname: parsed.hostname,
    port: parsed.port || (isHttps ? 443 : 80),
    path: parsed.pathname + parsed.search,
    method: "GET",
    headers: {
      "User-Agent": "Mozilla/5.0 (compatible; IPTVPlayer/1.0)",
      Range: req.headers.range || "",
    },
  };

  const upstream = lib.request(options, (uRes) => {
    // Pass through status and headers
    const passthroughHeaders = [
      "content-type",
      "content-length",
      "content-range",
      "accept-ranges",
      "cache-control",
    ];
    const headers = {};
    for (const h of passthroughHeaders) {
      if (uRes.headers[h]) headers[h] = uRes.headers[h];
    }
    headers["Access-Control-Allow-Origin"] = "*";

    res.writeHead(uRes.statusCode, headers);
    uRes.pipe(res, { end: true });
  });

  upstream.on("error", (err) => {
    if (!res.headersSent) res.status(502).send("Stream error: " + err.message);
  });

  req.on("close", () => upstream.destroy());
  upstream.end();
}

// ─── EPG proxy ────────────────────────────────────────────────────────────────

app.get("/api/epg/:streamId", async (req, res) => {
  const settings = loadSettings();
  if (!settings.host) return res.status(401).json({ error: "Not configured" });

  const url = `${xtreamBase(settings)}&action=get_short_epg&stream_id=${req.params.streamId}&limit=5`;

  try {
    const upstream = await fetch(url, { timeout: 10000 });
    const data = await upstream.json();
    res.json(data);
  } catch (_) {
    res.json({ epg_listings: [] });
  }
});

// ─── Auth test ────────────────────────────────────────────────────────────────

app.get("/api/test", async (req, res) => {
  const settings = loadSettings();
  if (!settings.host) return res.status(401).json({ error: "Not configured" });

  try {
    const url = `${settings.host}/player_api.php?username=${settings.username}&password=${settings.password}`;
    const upstream = await fetch(url, { timeout: 10000 });
    const data = await upstream.json();

    if (data.user_info) {
      res.json({
        ok: true,
        expiry: data.user_info.exp_date,
        status: data.user_info.status,
        connections: data.user_info.active_cons + "/" + data.user_info.max_connections,
      });
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  } catch (err) {
    res.status(502).json({ error: "Cannot reach server: " + err.message });
  }
});

// ─── SPA fallback ─────────────────────────────────────────────────────────────

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../static/index.html"));
});

// ─── Start ────────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`IPTV Player running on http://localhost:${PORT}`);
});
